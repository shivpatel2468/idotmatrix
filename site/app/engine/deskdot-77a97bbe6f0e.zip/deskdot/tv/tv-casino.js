/* DeskDot TV view — the casino tables (docs/TV_VIEW.md §4, docs/CASINO.md).
 *
 * One bespoke 1920×984 broadcast scene per casino game: roulette, blackjack, baccarat, slots, Texas hold'em,
 * teen patti, andar bahar, big six, 7 up 7 down and housie. Each scene is a table layer redrawn only when something on
 * it changed, over a cached background (felt, printed layout, rail), with the moving parts (wheels, balls, dice,
 * reels, stamps, countdown rings) in small canvases of their own moved by transforms, in the table's theme
 * (status.table_theme → ctx.theme), plus the live panel as a small inset in the right-hand rail. Chips follow the
 * table's chip ladder (status.chips). The lite tier (TV.quality) drops blurred shadows and glows (docs/TV_VIEW.md §6).
 *
 * Only public information is drawn — it is all the TV receives: the public casino status phones get (spot_bets,
 * totals, players, history, the result after the reveal, face-up cards; hole cards only at a showdown).
 *
 * Timing. Countdown fields (ends_in, reveal_in, next_in, turn_in …) are whole seconds left, rounded up, measured when
 * the state was built (ctx.stateAt). `Countdown` intersects the windows of successive states to estimate the real
 * deadline to ~0.2 s, and spin animations run from the estimated lock time (reveal deadline − LOCK − spin seconds),
 * the same clock the panel apps use. The outcome is secret until the result phase, so wheels / balls / dice spin
 * honestly and only settle on the outcome once it is public (a short, natural-looking settle).
 *
 * Plain modern JS, no dependencies. Helpers are exposed as TV.casino for tests (tests/js/tv_casino.test.mjs).
 */
(function () {
  "use strict";

  const TV = typeof window !== "undefined" ? window.TV : undefined;

  // ================================================================================================ constants
  const SW = 1920;
  const SH = 984;
  const RAIL_X = 1540;
  const RAIL_W = SW - RAIL_X;
  const PANEL_PITCH = 9;
  const PANEL_SIZE = 32 * PANEL_PITCH;
  const PANEL_X = RAIL_X + (RAIL_W - PANEL_SIZE) / 2;
  const PANEL_Y = 672;
  const LOCK = 1.0; // casino/table.py LOCK_SECONDS
  const TAU = Math.PI * 2;
  // the TV's own face (tv.js loads tv/tv-sans.woff2; the scene redraws once it has loaded), then the system's
  const FONT = '"DeskDot TV Sans","Segoe UI Variable Display","Segoe UI",system-ui,-apple-system,Roboto,"Helvetica Neue",Arial,sans-serif';
  const MONO = '"Cascadia Mono","SF Mono",Consolas,"Roboto Mono",ui-monospace,Menlo,monospace';
  // engraved titles on the felt and the seat plaques (system serifs only: a TV stick has Noto Serif / Droid Serif)
  const SERIF = '"Didot","Bodoni 72","Bodoni MT","Cormorant Garamond","Playfair Display",Georgia,"Noto Serif","Droid Serif","Times New Roman",serif';
  const fontOf = (o) => (o && o.font === "mono" ? MONO : o && o.font === "serif" ? SERIF : FONT);
  const CLASSIC = {
    felt: "#0d6b45", felt2: "#0a5236", felt3: "#063823", accent: "#ffcc33", accent_hi: "#ffe08a", accent_lo: "#e2a400",
    accent_deep: "#3a2c08", accent_rgb: "255, 204, 51", ink: "#1a1200", wing: "#102a20", wing2: "#0b1c16", wing3: "#0a1512",
  }; // fmt: skip
  const TONE = {
    red: "#d0182f", black: "#26262e", green: "#0e9a4c", white: "#5a5a68", gold: "#c99a00",
    player: "#1f5fe0", banker: "#d0182f", tie: "#0e9a4c", andar: "#e0641a", bahar: "#1f8fe0",
    down: "#1f6fff", seven: "#d9a000", up: "#e0263c",
    b6_1: "#e6b31e", b6_2: "#2a78ff", b6_5: "#12b35a", b6_10: "#a64dff", b6_20: "#ff6a1a", b6_joker: "#ff2f96", b6_logo: "#d9c27a",
  }; // fmt: skip
  const OK = "#3ddc84";
  const BAD = "#ff4d5e";
  const INK1 = "#f3eee2";
  const INK2 = "#c4bfb2";
  const INK3 = "#8b877e";

  /**
   * The room around the table, by the TV's theme (tv.js TV.theme): dark is the night salon (damask walls, mahogany
   * rail, leather gallery); light is a daylight salon — ivory and champagne walls, a white-lacquer rail with gold
   * inlay, ivory seat plaques, deep ink and antique gold for the type (the studio's light casino, casino.css /
   * MATERIALS v2). The felt is the table theme's in both. Everything here lands in the cached layers (background,
   * rail): a theme change redraws them once (scene.restyle), nothing per frame.
   */
  const ROOMS = {
    dark: {
      light: false, ink1: INK1, ink2: INK2, ink3: INK3, shadow: "#000",
      wall: null, damask: 0.05, sheen: "rgba(255,255,255,.05)", vignette: "rgba(0,0,0,.55)", lampFar: "rgba(0,0,0,.5)", lampMid: "rgba(0,0,0,.12)",
      railShadow: ["#000", 0.9],
      rail: ["#c9973a", "#6a4a12", "#e8c264", [[0.86, "#1d0c05"], [0.74, "#3c1a0b"], [0.6, "#5c2812"], [0.46, "#783619"], [0.32, "#8f4520"], [0.18, "#a65629"], [0.07, "#bf6c37"]], "rgba(255,226,186,.55)"],
      gallery: ["#1f1612", "#0b0807"], galleryShadow: 0.7, frame: 0.6, frameIn: 0.22,
      plaque: ["#271c16", "#110b09"], plaqueLine: 0.3, plaqueSheen: "rgba(255,255,255,.035)",
      housing: ["#2b2b33", "#111115"], label: 0.6, histLine: "rgba(255,255,255,.18)",
      odo: { ink: INK1, up: "#7dffc4", down: "#ff8a9a", shadow: "0 2px 0 rgba(0,0,0,.55)" },
    },
    light: {
      light: true, ink1: "#1c1a22", ink2: "#4a4652", ink3: "#6b6673", shadow: "rgba(92,70,40,1)",
      wall: ["#fbf8f1", "#f3ecdf", "#e9dfcc"], damask: 0.09, sheen: "rgba(255,255,255,.55)", vignette: "rgba(120,92,52,.22)", lampFar: "rgba(120,92,52,.16)", lampMid: "rgba(255,250,240,0)",
      railShadow: ["#5c4628", 0.38],
      rail: ["#b8892a", "#8a6412", "#e6c876", [[0.86, "#d8ccb6"], [0.74, "#e6dccb"], [0.6, "#efe8db"], [0.46, "#f6f1e7"], [0.32, "#faf7f0"], [0.18, "#fdfbf6"], [0.07, "#ffffff"]], "rgba(255,255,255,.95)"],
      gallery: ["#fffdf8", "#f1e9da"], galleryShadow: 0.28, frame: 0.85, frameIn: 0.35,
      plaque: ["#ffffff", "#f6f0e4"], plaqueLine: 0.45, plaqueSheen: "rgba(255,255,255,.7)",
      housing: ["#f7f2e8", "#ddd2bd"], label: 0.95, histLine: "rgba(64,48,24,.18)",
      odo: { ink: "#1c1a22", up: "#0f7a4a", down: "#b3263c", shadow: "0 1px 0 rgba(255,255,255,.85)" },
    },
  }; // fmt: skip
  /** The room the page is painted in now (html[data-theme], set by tv.js inside its cross-fade). */
  const roomOf = () => {
    try {
      return document.documentElement.dataset.theme === "light" ? ROOMS.light : ROOMS.dark;
    } catch (e) {
      return ROOMS.dark; // no DOM (tests)
    }
  };
  let P = ROOMS.dark; // the room in use while a scene paints (one scene at a time, set in paint)
  /** A player's colour as text on the room: as is in the dark, deepened on ivory (bright LED colours wash out). */
  const inkOf = (c) => (P.light ? shade(c || P.ink1, 0.55) : c || P.ink1);
  /** Antique-gold engraving for type on the light room (gold leaf's bright top vanishes on ivory). */
  const goldOn = () => (P.light ? "deep" : true);
  /** A colour meant for the dark room, made readable on the ivory one (text drawn on the room or a seat plaque). */
  function roomInk(c, th) {
    if (!P.light) return c;
    if (c == null || c === INK1) return P.ink1;
    if (c === INK2) return P.ink2;
    if (c === INK3) return P.ink3;
    if (c === OK) return "#18794e";
    if (c === BAD) return "#b3263c";
    if (th && (c === th.accent_hi || c === th.accent)) return "#8a6412";
    return /^#[0-9a-f]{3,6}$/i.test(String(c)) ? shade(c, 0.55) : c;
  }

  // ================================================================================================ small helpers
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, k) => a + (b - a) * k;
  const easeOut = (u) => 1 - Math.pow(1 - clamp(u, 0, 1), 3);
  const easeIn = (u) => Math.pow(clamp(u, 0, 1), 2);
  const easeInOut = (u) => ((u = clamp(u, 0, 1)), u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2);
  const wrapPi = (a) => a - TAU * Math.floor((a + Math.PI) / TAU);
  const mod = (a, n) => ((a % n) + n) % n;
  const num = (v, d = 0) => (typeof v === "number" && Number.isFinite(v) ? v : d);
  const arr = (v) => (Array.isArray(v) ? v : []);
  const obj = (v) => (v && typeof v === "object" && !Array.isArray(v) ? v : {});

  /** A stable pseudo-random number in [0, 1) for animation flourishes (never for outcomes). */
  function hash01(s) {
    let h = 2166136261;
    const str = String(s);
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    h ^= h >>> 13;
    h = Math.imul(h, 0x5bd1e995);
    h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  }

  function hexRgb(h) {
    let s = String(h || "").trim().replace("#", "");
    if (s.length === 3) s = s.split("").map((c) => c + c).join("");
    const m = /^[0-9a-f]{6}$/i.test(s) ? parseInt(s, 16) : 0xf0f0f0;
    return [(m >> 16) & 255, (m >> 8) & 255, m & 255];
  }
  const rgba = (h, a) => {
    const [r, g, b] = hexRgb(h);
    return `rgba(${r},${g},${b},${a})`;
  };
  /** k < 1 darkens, k > 1 lightens toward white (1.3 = 30 % of the way). */
  function shade(h, k) {
    const f = (v) => Math.round(clamp(k >= 1 ? v + (255 - v) * (k - 1) : v * k, 0, 255));
    const [r, g, b] = hexRgb(h);
    return `rgb(${f(r)},${f(g)},${f(b)})`;
  }

  function fmt(S, n) {
    const c = S && S.ctx;
    if (c && typeof c.fmt === "function") return c.fmt(n);
    const v = Number(n);
    return Number.isFinite(v) ? Math.round(v).toLocaleString("en-US") : "–";
  }
  const signed = (S, n) => (n > 0 ? "+" : n < 0 ? "−" : "±") + fmt(S, Math.abs(n));

  /**
   * The lite tier (tv.js TV.quality). It draws the same picture as hq — same resolution, glows, particles and
   * animation — and only trims what can't be seen: countdown rings redraw on 1.5 px of arc instead of 1° steps.
   */
  const lite = () => !!(TV && TV.quality === "lite");
  /**
   * A soft glow / shadow (shadowBlur) — only where it is drawn once: sprites (chips, cards, dice, balls) and the
   * cached background. Glows in the redrawn table layer come from glowFx (sprites), never from shadowBlur.
   */
  function glowOn(g, color, blur, oy) {
    g.shadowColor = color;
    g.shadowBlur = blur;
    if (oy) g.shadowOffsetY = oy;
    return true;
  }

  /**
   * A glow from a sprite: exactly what shadowBlur would draw under a shape, rendered once (the shape drawn far off
   * the sprite with its shadow offset back in, so only the glow lands) and cached by `key`; each later draw is one
   * drawImage. (x, y, w, h) bound the shape in the caller's coordinates; `draw(g)` builds and fills / strokes it there
   * with the styles that cast the shadow. The caller then draws the shape itself, crisp, on top — as shadowBlur does.
   * shadowBlur is in device px, so the sprite is made at the context's own scale (chipK) with the same blur.
   */
  const glowCache = new Map();
  function glowFx(g, key, x, y, w, h, color, blur, draw) {
    const k = chipK(g);
    const b = Math.max(0, Math.round(blur));
    if (b <= 0) return;
    const pad = Math.ceil((b * 1.6 + 2) / k);
    const W = Math.ceil(w) + 2 * pad;
    const H = Math.ceil(h) + 2 * pad;
    const full = `${key}|${color}|${b}|${k}|${W}|${H}`;
    let sp = glowCache.get(full);
    if (!sp) {
      if (glowCache.size > 300) glowCache.clear();
      const m = makeCanvas(W, H, k);
      const off = W + 40; // stage px: the shape lands left of the sprite, its shadow back inside it
      m.g.translate(pad - x - off, pad - y);
      m.g.shadowColor = color;
      m.g.shadowBlur = b;
      m.g.shadowOffsetX = off * k;
      draw(m.g);
      sp = m.c;
      glowCache.set(full, sp);
    }
    g.drawImage(sp, x - pad, y - pad, W, H);
  }

  // ================================================================================================ the chip ladder
  // casino/chips.py LADDER / chip_rack / break_into, copied (docs/CASINO.md §5): the TV reads status.chips and falls
  // back to this when an older engine doesn't send it. value, label, chip colour, edge-stripe colour.
  const LADDER = [
    [1, "1", "#f2efe8", "#2b6cd6"], [5, "5", "#d23a3a", "#ffffff"], [25, "25", "#2e9a55", "#ffffff"],
    [100, "100", "#1c1c22", "#e8e8e8"], [500, "500", "#7b3fc4", "#ffffff"], [1000, "1K", "#f2c230", "#5a3d00"],
    [2000, "2K", "#e85d9f", "#ffffff"], [5000, "5K", "#c9772b", "#ffffff"], [10000, "10K", "#2f6fd6", "#ffffff"],
    [25000, "25K", "#18a39a", "#ffffff"], [50000, "50K", "#9a2f4d", "#ffd36b"], [100000, "100K", "#c9a227", "#1c1c22"],
    [250000, "250K", "#5b2a86", "#ffd36b"], [500000, "500K", "#0f3d2e", "#ffd36b"], [1000000, "1M", "#111111", "#ffd36b"],
  ]; // fmt: skip
  const RACK_MAX = 7;

  /** A chip amount with K / M (casino/chips.py short): 1000 → 1K, 2500 → 2.5K, 1250 → 1.25K, 750 → 750. */
  function shortChip(v) {
    v = Math.round(num(Number(v)));
    const a = Math.abs(v);
    for (const [unit, suf] of [[1e6, "M"], [1e3, "K"]]) {
      if (a >= unit) return (v / unit).toFixed(2).replace(/0+$/, "").replace(/\.$/, "") + suf;
    }
    return String(v);
  }
  /** Python's round(): halves go to the even neighbour (chip_rack picks its rack with it). */
  function pyRound(x) {
    const f = Math.floor(x);
    const d = x - f;
    if (Math.abs(d - 0.5) < 1e-9) return f % 2 === 0 ? f : f + 1;
    return Math.round(x);
  }
  const chipOf = (c) => ({ v: c[0], label: c[1], color: c[2], edge: c[3] });

  /** casino/chips.py chip_rack: the chips a table offers, smallest first, at most RACK_MAX. */
  function chipRack(minBet, maxBet) {
    const lo = Math.max(1, Math.floor(num(Number(minBet), 1)));
    const hi = Math.max(lo, Math.floor(num(Number(maxBet), lo)));
    const allowed = LADDER.filter((c) => lo <= c[0] && c[0] <= hi).map(chipOf);
    if (!allowed.length || allowed[0].v !== lo) {
      const above = LADDER.find((c) => c[0] > lo) || LADDER[LADDER.length - 1];
      allowed.unshift({ v: lo, label: shortChip(lo), color: above[2], edge: above[3] });
    }
    const n = allowed.length;
    if (n <= RACK_MAX) return allowed;
    const picks = [...new Set(Array.from({ length: RACK_MAX }, (_, i) => pyRound((i * (n - 1)) / (RACK_MAX - 1))))].sort((a, b) => a - b);
    return picks.map((i) => allowed[i]);
  }

  /** The table's rack: status.chips when the engine sends a valid one, else the same rack computed here. */
  function rackOf(st) {
    const c = arr(st && st.chips).filter((x) => x && typeof x.v === "number" && x.v > 0 && typeof x.color === "string");
    if (c.length) return c.map((x) => ({ v: x.v, label: String(x.label || shortChip(x.v)), color: x.color, edge: x.edge || "#ffffff" }));
    const h = obj(st && st.house);
    return chipRack(num(h.min_bet, 1), num(h.max_bet, 500));
  }

  /** An amount as chip values, largest first: greedy over the ladder (plus the rack's off-ladder table minimum). */
  function breakInto(amount, rack) {
    const vals = [...new Set([...LADDER.map((c) => c[0]), ...arr(rack).map((c) => c.v)])].sort((a, b) => b - a);
    const out = [];
    let left = Math.max(0, Math.round(num(Number(amount))));
    for (const v of vals) {
      while (left >= v && out.length < 64) {
        out.push(v);
        left -= v;
      }
    }
    if (left > 0) out.push(left);
    return out;
  }

  /** {color, edge, label} for a chip value: the rack's own chip, else the ladder's, else coloured like the next up. */
  function chipStyle(v, rack) {
    const r = arr(rack).find((c) => c.v === v);
    if (r) return r;
    const l = LADDER.find((c) => c[0] === v);
    if (l) return chipOf(l);
    const above = LADDER.find((c) => c[0] > v) || LADDER[LADDER.length - 1];
    return { v, label: shortChip(v), color: above[2], edge: above[3] };
  }

  // ================================================================================================ timing
  /**
   * A deadline from whole-second "left" values (ceil, as casino/table.py `_left` builds them) observed at times t:
   * each sample says deadline ∈ (t + left − 1, t + left]. Samples under the same key narrow the window; a sample
   * that contradicts it (the deadline moved) restarts it.
   */
  class Countdown {
    constructor() {
      this.key = null;
      this.lo = -Infinity;
      this.hi = Infinity;
    }
    observe(key, left, t) {
      if (left == null || typeof left !== "number" || !Number.isFinite(left)) {
        this.key = null;
        return;
      }
      if (key !== this.key) {
        this.key = key;
        this.lo = -Infinity;
        this.hi = Infinity;
      }
      const lo = left <= 0 ? -Infinity : t + left - 1;
      const hi = t + left;
      const nlo = Math.max(this.lo, lo);
      const nhi = Math.min(this.hi, hi);
      if (nlo > nhi + 0.05) {
        this.lo = lo;
        this.hi = hi;
      } else {
        this.lo = nlo;
        this.hi = Math.max(nlo, nhi);
      }
    }
    /** the estimated deadline (local seconds) or null */
    get at() {
      if (this.key == null) return null;
      return Number.isFinite(this.lo) ? (this.lo + this.hi) / 2 : this.hi;
    }
    left(t) {
      const a = this.at;
      return a == null ? null : Math.max(0, a - t);
    }
  }

  /** The table's phase clock: when the current phase started and the betting / reveal / next-round deadlines. */
  class PhaseTracker {
    constructor() {
      this.key = null;
      this.phase = "idle";
      this.round = null;
      this.start = 0;
      this.prevPhase = null;
      this.ends = new Countdown();
      this.reveal = new Countdown();
      this.next = new Countdown();
    }
    observe(st, t) {
      const phase = String(st.phase || "idle");
      const key = `${st.round}|${phase}`;
      if (key !== this.key) {
        this.prevPhase = this.key ? this.phase : null;
        this.key = key;
        this.phase = phase;
        this.round = st.round;
        this.start = t;
      }
      this.ends.observe(`${st.round}|${phase}|ends`, st.ends_in, t);
      this.reveal.observe(`${st.round}|reveal`, st.reveal_in, t);
      this.next.observe(`${st.round}|${phase}|next`, st.next_in, t);
    }
    since(t) {
      return Math.max(0, t - this.start);
    }
  }

  /**
   * Seconds left to a round timer: to its `status.clock` anchor on the shared clock (so the TV's countdown hits zero
   * with the panel's, the phones' and the studio's), else the whole-second countdown estimate.
   */
  function leftTo(S, key, cd, t) {
    const a = obj(S.st.clock)[key];
    if (typeof a === "number" && S.ctx && typeof S.ctx.serverNow === "function") return Math.max(0, a - S.T);
    return cd.left(t);
  }

  /** When betting closed for a bet-then-reveal game: reveal deadline − (LOCK + spin), else from the phase start. */
  function lockTime(clk, spin) {
    const r = clk.reveal.at;
    if (r != null) return r - LOCK - spin;
    if (clk.phase === "locked") return clk.start;
    return clk.start - LOCK;
  }

  // ================================================================================================ cards
  const RANKS = { T: "10", J: "J", Q: "Q", K: "K", A: "A" };
  function parseCard(code) {
    const s = String(code || "").toUpperCase();
    if (s.length < 2 || s === "??") return null;
    const suit = s[s.length - 1];
    const r = s.slice(0, -1);
    if (!"SHDC".includes(suit)) return null;
    const rank = RANKS[r] || (r === "10" ? "10" : /^[2-9]$/.test(r) ? r : null);
    if (!rank) return null;
    return { rank, suit, red: suit === "H" || suit === "D" };
  }
  function baccaratValue(code) {
    const c = parseCard(code);
    if (!c) return 0;
    if (c.rank === "A") return 1;
    if (c.rank === "10" || c.rank === "J" || c.rank === "Q" || c.rank === "K") return 0;
    return parseInt(c.rank, 10);
  }
  const baccaratTotal = (codes) => arr(codes).reduce((a, c) => a + baccaratValue(c), 0) % 10;

  // ================================================================================================ roulette maths
  const EU_WHEEL = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14,
    31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26]; // fmt: skip
  const US_WHEEL = [0, 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1, 37, 27, 10, 25, 29, 12, 8,
    19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2]; // fmt: skip
  const REDS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
  const rColor = (n) => (n === 0 || n === 37 ? "green" : REDS.has(n) ? "red" : "black");
  const rLabel = (n) => (n === 37 ? "00" : String(n));
  const rNum = (s) => (s === "00" ? 37 : parseInt(s, 10));
  const EVEN_SPOTS = ["low", "even", "red", "black", "odd", "high"];
  const EVEN_LABEL = { low: "1–18", even: "EVEN", red: "", black: "", odd: "ODD", high: "19–36" };
  const range = (a, b, st = 1) => {
    const o = [];
    for (let v = a; v <= b; v += st) o.push(v);
    return o;
  };

  function splitId(id) {
    const s = String(id);
    const i = s.indexOf(":");
    return i < 0 ? [s, ""] : [s.slice(0, i), s.slice(i + 1)];
  }

  /** The pockets a roulette spot id covers (casino/games/roulette.py spot ids; 37 = 00). */
  function rouletteCovers(id) {
    const [k, r] = splitId(id);
    switch (k) {
      case "n":
        return [rNum(r)];
      case "s":
      case "tr":
        return r.split("-").map(rNum);
      case "c": {
        const a = rNum(r);
        return [a, a + 1, a + 3, a + 4];
      }
      case "st": {
        const a = rNum(r);
        return [a, a + 1, a + 2];
      }
      case "sl": {
        const a = rNum(r);
        return range(a, a + 5);
      }
      case "ff":
        return [0, 1, 2, 3];
      case "tl":
        return [0, 37, 1, 2, 3];
      case "dz":
        return range(12 * +r - 11, 12 * +r);
      case "col":
        return range(+r, 36, 3);
      case "red":
        return range(1, 36).filter((n) => REDS.has(n));
      case "black":
        return range(1, 36).filter((n) => !REDS.has(n));
      case "odd":
        return range(1, 36, 2);
      case "even":
        return range(2, 36, 2);
      case "low":
        return range(1, 18);
      case "high":
        return range(19, 36);
      default:
        return [];
    }
  }

  /** The printed layout's geometry (numbers run in columns of three: 3 on the top row, 1 at the bottom). */
  function rouletteBoard(american) {
    return { x0: 742, y0: 330, zw: 72, cw: 51, ch: 86, colW: 68, dzH: 64, emH: 64, us: !!american };
  }
  function numCell(n, B) {
    const c = Math.floor((n - 1) / 3);
    const r = 2 - ((n - 1) % 3);
    return { x: B.x0 + B.zw + c * B.cw, y: B.y0 + r * B.ch, c, r };
  }
  function rouletteCenter(n, B) {
    if (n === 0) return [B.x0 + B.zw / 2, B.y0 + (B.us ? 2.25 : 1.5) * B.ch];
    if (n === 37) return [B.x0 + B.zw / 2, B.y0 + 0.75 * B.ch];
    const q = numCell(n, B);
    return [q.x + B.cw / 2, q.y + B.ch / 2];
  }
  /** Where a spot's chips sit on the layout (stage px), or null for an unknown id. */
  function rouletteSpotXY(id, B) {
    const L = B.x0 + B.zw;
    const bottom = B.y0 + 3 * B.ch;
    const [k, r] = splitId(id);
    switch (k) {
      case "n":
        return rouletteCenter(rNum(r), B);
      case "s": {
        const [a, b] = r.split("-").map(rNum);
        if (a === 0 && b === 37) return [B.x0 + B.zw / 2, B.y0 + 1.5 * B.ch];
        if (a === 0 || a === 37) {
          let y = rouletteCenter(b, B)[1];
          if (B.us && b === 2) y += (a === 0 ? 0.25 : -0.25) * B.ch;
          return [L, y];
        }
        if (!(a >= 1 && a <= 36)) return null;
        const q = numCell(a, B);
        return b === a + 1 ? [q.x + B.cw / 2, q.y] : [q.x + B.cw, q.y + B.ch / 2];
      }
      case "tr":
        return { "0-1-2": [L, B.y0 + 2 * B.ch], "0-2-3": [L, B.y0 + B.ch], "0-00-2": [L, B.y0 + 1.5 * B.ch],
          "00-2-3": [L, B.y0 + B.ch] }[r] || null; // fmt: skip
      case "ff":
      case "tl":
        return [L, bottom];
      case "st":
      case "sl":
      case "c": {
        const a = rNum(r);
        if (!(a >= 1 && a <= 36)) return null;
        const q = numCell(a, B);
        if (k === "st") return [q.x + B.cw / 2, bottom];
        if (k === "sl") return [q.x + B.cw, bottom];
        return [q.x + B.cw, q.y];
      }
      case "dz":
        return [L + (4 * (+r - 1) + 2) * B.cw, bottom + B.dzH / 2];
      case "col":
        return [L + 12 * B.cw + B.colW / 2, B.y0 + (3 - +r) * B.ch + B.ch / 2];
      default: {
        const i = EVEN_SPOTS.indexOf(String(id));
        return i >= 0 ? [L + (2 * i + 1) * B.cw, bottom + B.dzH + B.emH / 2] : null;
      }
    }
  }

  // ================================================================================================ big six / sevens / slots data
  const B6_WHEEL = ["joker", "2", "1", "1", "2", "1", "5", "2", "1", "1", "10", "2", "1", "5", "2", "1", "1", "20", "2",
    "1", "1", "5", "2", "1", "10", "2", "1", "logo", "1", "5", "2", "1", "2", "1", "1", "2", "5", "10", "1", "1", "2", "1",
    "1", "2", "20", "5", "1", "2", "1", "1", "2", "10", "5", "1"]; // fmt: skip
  const B6 = [
    { sym: "1", id: "s1", n: 24, pays: 1, col: "#ffc81e" },
    { sym: "2", id: "s2", n: 15, pays: 2, col: "#2878ff" },
    { sym: "5", id: "s5", n: 7, pays: 5, col: "#00c85a" },
    { sym: "10", id: "s10", n: 4, pays: 10, col: "#be50ff" },
    { sym: "20", id: "s20", n: 2, pays: 20, col: "#ff5a14" },
    { sym: "joker", id: "joker", n: 1, pays: 40, col: "#ff2896" },
    { sym: "logo", id: "logo", n: 1, pays: 40, col: "#ffecaa" },
  ];
  const B6_BY = Object.fromEntries(B6.map((s) => [s.sym, s]));
  const SEVENS = [
    { id: "down", name: "UNDER 7", sub: "2 – 6", col: "#1f6fff", pays: "1 : 1" },
    { id: "seven", name: "LUCKY 7", sub: "exactly 7", col: "#e0a800", pays: "4 : 1" },
    { id: "up", name: "OVER 7", sub: "8 – 12", col: "#e0263c", pays: "1 : 1" },
  ];
  const SLOT_LINES = [[1, 1, 1], [0, 0, 0], [2, 2, 2], [0, 1, 2], [2, 1, 0]];
  const SLOT_STOPS = [1.5, 2.1, 2.7];
  const LINE_COLORS = ["#ffcc33", "#ff3f78", "#33d1ff", "#7dff5a", "#ff7419"];

  /** The panel's reel position (apps/casino_slots.py reel_pos): a float strip index for the middle row. */
  function reelPos(stop, n, t, i) {
    const T = SLOT_STOPS[i];
    const travel = 3 * n + 4 * i;
    if (t <= 0) return stop - travel;
    if (t < T) {
      const u = t / T;
      const ease = 1 - Math.pow(1 - u, 3);
      return stop - travel * (1 - ease) + 0.35 * Math.sin(Math.PI * Math.pow(Math.min(1, u), 8));
    }
    const k = t - T;
    return stop + 0.3 * Math.exp(-k * 9) * Math.sin(k * 26);
  }

  const HOUSIE_NAMES = {
    1: "Kelly's eye", 2: "One little duck", 7: "Lucky seven", 8: "Garden gate", 9: "Doctor's orders", 10: "Uncle Ben",
    11: "Legs eleven", 12: "One dozen", 13: "Unlucky for some", 16: "Sweet sixteen", 21: "Key of the door",
    22: "Two little ducks", 26: "Pick and mix", 30: "Dirty Gertie", 31: "Get up and run", 32: "Buckle my shoe",
    33: "All the threes", 39: "Steps", 44: "Droopy drawers", 45: "Halfway there", 50: "Half a century",
    55: "Snakes alive", 66: "Clickety click", 69: "Any way up", 72: "Six dozen", 77: "Sunset strip", 80: "Gandhi's breakfast",
    81: "Stop and run", 85: "Staying alive", 88: "Two fat ladies", 89: "Nearly there", 90: "Top of the shop",
  }; // fmt: skip

  // ================================================================================================ canvas kit
  function makeCanvas(w, h, k) {
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.ceil(w * k));
    c.height = Math.max(1, Math.ceil(h * k));
    const g = c.getContext("2d");
    g.setTransform(k, 0, 0, k, 0, 0);
    return { c, g, w, h, k };
  }
  function rr(g, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    g.beginPath();
    g.moveTo(x + r, y);
    g.lineTo(x + w - r, y);
    g.arcTo(x + w, y, x + w, y + r, r);
    g.lineTo(x + w, y + h - r);
    g.arcTo(x + w, y + h, x + w - r, y + h, r);
    g.lineTo(x + r, y + h);
    g.arcTo(x, y + h, x, y + h - r, r);
    g.lineTo(x, y + r);
    g.arcTo(x, y, x + r, y, r);
    g.closePath();
  }
  function circle(g, x, y, r) {
    g.beginPath();
    g.arc(x, y, Math.max(0, r), 0, TAU);
  }
  /** Text. o: {align, base, weight, font: "mono", shadow, maxW, alpha, glow} */
  function txt(g, s, x, y, size, color, o) {
    o = o || {};
    g.save();
    g.font = `${o.weight || 700} ${size}px ${fontOf(o)}`;
    if (o.spacing && "letterSpacing" in g) g.letterSpacing = `${o.spacing}px`;
    g.textAlign = o.align || "left";
    g.textBaseline = o.base || "alphabetic";
    if (o.alpha != null) g.globalAlpha *= o.alpha;
    const str = String(s);
    const glowing = !!o.glow;
    if (glowing) {
      // the glow (a cached sprite of the text's shadowBlur), then the crisp text over it
      const tw = Math.min(g.measureText(str).width || str.length * size * 0.55, o.maxW || Infinity);
      const align = o.align || "left";
      const x0 = align === "center" ? x - tw / 2 : align === "right" || align === "end" ? x - tw : x;
      const base = o.base || "alphabetic";
      const y0 = base === "middle" ? y - size * 0.6 : base === "top" ? y - size * 0.1 : y - size;
      const font = g.font;
      const ta = g.textAlign;
      const tb = g.textBaseline;
      glowFx(g, `t|${str}|${font}|${ta}|${tb}|${o.maxW || ""}`, x0, y0, tw, size * 1.3, o.glow, o.glowBlur || size * 0.45, (m) => {
        m.font = font;
        m.textAlign = ta;
        m.textBaseline = tb;
        m.fillStyle = "#000";
        if (o.maxW) m.fillText(str, x, y, o.maxW);
        else m.fillText(str, x, y);
      });
    }
    if (o.emboss) {
      // pressed into the felt: a dark lower edge and a light upper one, drawn once (the cached background)
      const a = g.globalAlpha;
      const d = Math.max(1, size * 0.035);
      g.globalAlpha = a * 0.55;
      g.fillStyle = "#000";
      g.fillText(str, x, y + d * 1.4);
      g.globalAlpha = a * 0.22;
      g.fillStyle = "#fff";
      g.fillText(str, x, y - d);
      g.globalAlpha = a;
    } else if (!glowing && o.shadow !== false) {
      // a hard drop shadow: the text once more, offset and dark — no blur (a blurred shadow per text is the
      // costliest thing on a TV stick, and at 3 m it reads the same)
      const dy = Math.max(1, size * 0.05);
      const a = g.globalAlpha;
      g.globalAlpha = a * 0.5;
      g.fillStyle = "#000";
      if (o.maxW) g.fillText(str, x, y + dy, o.maxW);
      else g.fillText(str, x, y + dy);
      g.globalAlpha = a;
    }
    if (o.gold === "deep") {
      // antique gold engraved into ivory (the light room): dark enough to read, still a metal
      const top = (o.base || "alphabetic") === "middle" ? y - size * 0.5 : y - size * 0.8;
      const gr = g.createLinearGradient(0, top, 0, top + size);
      gr.addColorStop(0, "#b8892a");
      gr.addColorStop(0.45, "#7a5410");
      gr.addColorStop(0.7, "#9c7020");
      gr.addColorStop(1, "#5e400c");
      g.fillStyle = gr;
    } else if (o.gold) {
      // gold leaf: a vertical metal gradient over the text's own height
      const top = (o.base || "alphabetic") === "middle" ? y - size * 0.5 : y - size * 0.8;
      const gr = g.createLinearGradient(0, top, 0, top + size);
      gr.addColorStop(0, "#fff4c8");
      gr.addColorStop(0.32, o.gold === true ? "#f0cf6a" : o.gold);
      gr.addColorStop(0.55, "#a8761c");
      gr.addColorStop(0.78, "#e9c25a");
      gr.addColorStop(1, "#7a5410");
      g.fillStyle = gr;
    } else g.fillStyle = color;
    if (o.maxW) g.fillText(str, x, y, o.maxW);
    else g.fillText(str, x, y);
    g.restore();
  }
  function measure(g, s, size, o) {
    g.save();
    g.font = `${(o && o.weight) || 700} ${size}px ${fontOf(o)}`;
    const w = g.measureText(String(s)).width;
    g.restore();
    return num(w, String(s).length * size * 0.55);
  }
  /** A rounded pill with text; returns its width. */
  function pill(g, s, x, y, size, bg, fg, o) {
    o = o || {};
    const padX = size * 0.6;
    const w = measure(g, s, size, o) + padX * 2;
    const h = size * 1.6;
    const x0 = o.align === "center" ? x - w / 2 : o.align === "right" ? x - w : x;
    rr(g, x0, y - h / 2, w, h, h / 2);
    g.fillStyle = bg;
    g.fill();
    if (o.stroke) {
      g.lineWidth = 2;
      g.strokeStyle = o.stroke;
      g.stroke();
    }
    txt(g, s, x0 + w / 2, y + size * 0.36, size, fg, { align: "center", shadow: false, weight: o.weight || 750, font: o.font });
    return w;
  }
  /** A countdown ring: frac of the circle left, the seconds in the middle. */
  function ring(g, x, y, r, frac, color, label, o) {
    o = o || {};
    g.save();
    circle(g, x, y, r);
    g.fillStyle = "rgba(0,0,0,.45)";
    g.fill();
    g.lineWidth = o.width || Math.max(6, r * 0.14);
    g.strokeStyle = "rgba(255,255,255,.10)";
    g.stroke();
    const a1 = -Math.PI / 2 + TAU * clamp(frac, 0, 1);
    if (o.hud) glowOn(g, color, 16); // a countdown's own small canvas: the blur covers a few hundred px
    else {
      // in the table layer: a cached glow sprite of the arc
      const lw = g.lineWidth;
      const fq = Math.round(clamp(frac, 0, 1) * 360);
      glowFx(g, `arc|${r}|${lw}|${fq}`, x - r - lw, y - r - lw, 2 * (r + lw), 2 * (r + lw), color, 16, (m) => {
        m.beginPath();
        m.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + (TAU * fq) / 360);
        m.lineWidth = lw;
        m.lineCap = "round";
        m.strokeStyle = "#000";
        m.stroke();
      });
    }
    g.beginPath();
    g.arc(x, y, r, -Math.PI / 2, a1);
    g.strokeStyle = color;
    g.lineCap = "round";
    g.stroke();
    g.restore();
    if (label != null) txt(g, label, x, y + r * 0.2, r * 0.62, INK1, { align: "center", font: "mono", weight: 700 });
  }

  /**
   * A countdown ring that sweeps smoothly: drawn into a small canvas of its own every animation frame (so the big
   * table layer doesn't have to redraw for it). `left` s were left at local time `t` out of `span`; it turns
   * `low` under `lowBelow` s. Rings drawn with hudRing in a table redraw stay; the others are hidden after it.
   */
  function hudRing(S, id, x, y, r, o) {
    S.hud = S.hud || new Map();
    let h = S.hud.get(id);
    const pad = 14;
    const D = 2 * (r + pad);
    if (!h || h.r !== r || h.k !== S.k) {
      if (h) h.l.c.remove();
      const l = layer(S.root, x - D / 2, y - D / 2, D, D, S.k, false);
      h = { l, r, k: S.k, key: "" };
      S.hud.set(id, h);
    }
    if (h.x !== x || h.y !== y) {
      h.l.c.style.left = `${x - D / 2}px`;
      h.l.c.style.top = `${y - D / 2}px`;
      h.x = x;
      h.y = y;
    }
    Object.assign(h, { seen: S.drawGen, t0: S.t, left: o.left, span: o.span || 1, color: o.color, low: o.low || o.color,
      lowBelow: o.lowBelow || 0, label: o.label !== false, width: o.width }); // fmt: skip
    h.l.c.style.display = "";
  }
  /** Every frame: sweep the rings (redrawing one only when it visibly moved); hide the ones no longer drawn. */
  function hudFrame(S, t) {
    if (!S.hud) return;
    for (const h of S.hud.values()) {
      if (h.seen !== S.drawGen) {
        if (h.l.c.style.display !== "none") h.l.c.style.display = "none";
        continue;
      }
      const left = h.left == null ? null : Math.max(0, h.left - (t - h.t0));
      const frac = left == null ? 1 : clamp(left / h.span, 0, 1);
      const label = h.label && left != null ? Math.ceil(left - 1e-6) : null;
      const color = left != null && left < h.lowBelow ? h.low : h.color;
      // 1° steps (hq); lite steps on ~1.5 device px of arc instead — the same sweep to the eye, fewer redraws
      const steps = lite() ? Math.max(90, Math.min(360, Math.round((TAU * h.r * h.k) / 1.5))) : 360;
      const key = `${Math.round(frac * steps)}|${label}|${color}`;
      if (key === h.key) continue;
      h.key = key;
      const l = h.l;
      l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
      l.g.clearRect(0, 0, l.w, l.h);
      ring(l.g, l.w / 2, l.h / 2, h.r, frac, color, label, { width: h.width, hud: true });
      l.show();
    }
  }

  // suits drawn as paths (no font dependence)
  function suitPath(g, suit, cx, cy, s) {
    g.beginPath();
    if (suit === "D") {
      g.moveTo(cx, cy - s * 0.55);
      g.quadraticCurveTo(cx + s * 0.18, cy - s * 0.2, cx + s * 0.42, cy);
      g.quadraticCurveTo(cx + s * 0.18, cy + s * 0.2, cx, cy + s * 0.55);
      g.quadraticCurveTo(cx - s * 0.18, cy + s * 0.2, cx - s * 0.42, cy);
      g.quadraticCurveTo(cx - s * 0.18, cy - s * 0.2, cx, cy - s * 0.55);
    } else if (suit === "H") {
      g.moveTo(cx, cy + s * 0.5);
      g.bezierCurveTo(cx - s * 0.75, cy - s * 0.05, cx - s * 0.45, cy - s * 0.65, cx, cy - s * 0.28);
      g.bezierCurveTo(cx + s * 0.45, cy - s * 0.65, cx + s * 0.75, cy - s * 0.05, cx, cy + s * 0.5);
    } else if (suit === "S") {
      g.moveTo(cx, cy - s * 0.55);
      g.bezierCurveTo(cx + s * 0.75, cy - s * 0.02, cx + s * 0.45, cy + s * 0.55, cx + s * 0.04, cy + s * 0.2);
      g.lineTo(cx + s * 0.16, cy + s * 0.55);
      g.lineTo(cx - s * 0.16, cy + s * 0.55);
      g.lineTo(cx - s * 0.04, cy + s * 0.2);
      g.bezierCurveTo(cx - s * 0.45, cy + s * 0.55, cx - s * 0.75, cy - s * 0.02, cx, cy - s * 0.55);
    } else {
      const r = s * 0.2;
      g.arc(cx, cy - s * 0.24, r, 0, TAU);
      g.moveTo(cx - s * 0.2 + r, cy + s * 0.06);
      g.arc(cx - s * 0.22, cy + s * 0.06, r, 0, TAU);
      g.moveTo(cx + s * 0.22 + r, cy + s * 0.06);
      g.arc(cx + s * 0.22, cy + s * 0.06, r, 0, TAU);
      g.moveTo(cx + s * 0.05, cy);
      g.lineTo(cx + s * 0.16, cy + s * 0.55);
      g.lineTo(cx - s * 0.16, cy + s * 0.55);
      g.lineTo(cx - s * 0.05, cy);
    }
    g.closePath();
  }

  const cardCache = new Map();
  function cardImage(code, w, h, k, back) {
    const key = `${code}|${w}|${h}|${k}|${back || ""}`;
    let im = cardCache.get(key);
    if (im) return im;
    if (cardCache.size > 400) cardCache.clear();
    const m = makeCanvas(w + 8, h + 8, k);
    const g = m.g;
    g.translate(4, 4);
    const r = w * 0.09;
    g.save();
    g.shadowColor = "rgba(0,0,0,.45)";
    g.shadowBlur = 6;
    g.shadowOffsetY = 2;
    rr(g, 0, 0, w, h, r);
    g.fillStyle = back ? back : "#fbf8f1";
    g.fill();
    g.restore();
    const c = back ? null : parseCard(code);
    if (back) {
      // the back: a theme-coloured lattice inside a white border
      rr(g, w * 0.07, h * 0.05, w * 0.86, h * 0.9, r * 0.6);
      g.fillStyle = shade(back, 0.7);
      g.fill();
      g.save();
      g.clip();
      g.strokeStyle = rgba("#ffffff", 0.22);
      g.lineWidth = Math.max(1, w * 0.02);
      for (let i = -h; i < w + h; i += w * 0.14) {
        g.beginPath();
        g.moveTo(i, 0);
        g.lineTo(i + h, h);
        g.moveTo(i + h, 0);
        g.lineTo(i, h);
        g.stroke();
      }
      g.restore();
      rr(g, w * 0.07, h * 0.05, w * 0.86, h * 0.9, r * 0.6);
      g.lineWidth = Math.max(1.5, w * 0.025);
      g.strokeStyle = "#f6f0e0";
      g.stroke();
      circle(g, w / 2, h / 2, w * 0.16);
      g.fillStyle = "#f6f0e0";
      g.fill();
      circle(g, w / 2, h / 2, w * 0.1);
      g.fillStyle = back;
      g.fill();
    } else if (c) {
      const ink = c.red ? "#d0172c" : "#15151c";
      const rs = w * (c.rank === "10" ? 0.27 : 0.3);
      txt(g, c.rank, w * 0.08, h * 0.04 + rs, rs, ink, { shadow: false, weight: 800, align: "left" });
      g.fillStyle = ink;
      suitPath(g, c.suit, w * 0.17, h * 0.04 + rs * 1.55, w * 0.2);
      g.fill();
      g.save();
      g.translate(w, h);
      g.rotate(Math.PI);
      txt(g, c.rank, w * 0.08, h * 0.04 + rs, rs, ink, { shadow: false, weight: 800 });
      g.fillStyle = ink;
      suitPath(g, c.suit, w * 0.17, h * 0.04 + rs * 1.55, w * 0.2);
      g.fill();
      g.restore();
      if ("JQK".includes(c.rank)) {
        rr(g, w * 0.26, h * 0.2, w * 0.48, h * 0.6, w * 0.05);
        g.fillStyle = c.red ? "#fde6e6" : "#e7e9f3";
        g.fill();
        g.lineWidth = Math.max(1, w * 0.02);
        g.strokeStyle = "#c9a24a";
        g.stroke();
        txt(g, c.rank, w / 2, h * 0.55, w * 0.36, ink, { align: "center", shadow: false, weight: 800 });
        g.fillStyle = "#c9a24a";
        suitPath(g, c.suit, w / 2, h * 0.68, w * 0.16);
        g.fill();
      } else {
        g.fillStyle = ink;
        suitPath(g, c.suit, w / 2, h / 2 + h * 0.04, w * (c.rank === "A" ? 0.62 : 0.44));
        g.fill();
      }
    }
    g.lineWidth = 1;
    rr(g, 0.5, 0.5, w - 1, h - 1, r);
    g.strokeStyle = "rgba(0,0,0,.18)";
    g.stroke();
    im = m.c;
    cardCache.set(key, im);
    return im;
  }

  /**
   * A card centred at (x, y). o: {down, back, rot, flip (0..1: 0 = back, 1 = face), alpha, glow, dim}.
   * `flip` animates a turn: the card narrows, swaps sides, widens again.
   */
  function drawCard(S, g, code, x, y, w, h, o) {
    o = o || {};
    const back = o.back || shade(S.th.accent_deep === CLASSIC.accent_deep ? "#8f1c2c" : S.th.felt3, 1.25);
    let face = !o.down && parseCard(code) != null;
    let sx = 1;
    let sy = 1;
    let shadeK = 0;
    let skew = 0;
    if (o.flip != null && face) {
      // a turn in 3D: the card narrows on its axis, lifts toward the camera (taller), its turning edge leans and
      // darkens, then the face comes round
      const f = clamp(o.flip, 0, 1);
      sx = Math.abs(Math.cos(f * Math.PI));
      sy = 1 + 0.09 * Math.sin(f * Math.PI);
      shadeK = 0.45 * (1 - sx);
      skew = 0.12 * Math.sin(f * TAU);
      if (f < 0.5) face = false;
    }
    const im = face ? cardImage(code, w, h, S.k, null) : cardImage("back", w, h, S.k, back);
    g.save();
    g.translate(x, y);
    if (o.rot) g.rotate(o.rot);
    if (o.alpha != null) g.globalAlpha *= o.alpha;
    if (skew) g.transform(1, skew, 0, 1, 0, 0);
    g.scale(Math.max(0.02, sx), sy);
    if (o.glow) {
      glowFx(g, `card|${w}|${h}`, -w / 2, -h / 2, w, h, o.glow, 28, (m) => {
        rr(m, -w / 2, -h / 2, w, h, w * 0.09);
        m.fillStyle = "#000";
        m.fill();
      });
    }
    g.drawImage(im, -w / 2 - 4, -h / 2 - 4, w + 8, h + 8);
    if (shadeK > 0.01) {
      rr(g, -w / 2, -h / 2, w, h, w * 0.09);
      g.fillStyle = `rgba(0,0,0,${shadeK.toFixed(3)})`;
      g.fill();
    }
    if (o.dim) {
      rr(g, -w / 2, -h / 2, w, h, w * 0.09);
      g.fillStyle = `rgba(0,0,0,${o.dim})`;
      g.fill();
    }
    g.restore();
  }

  /** An empty card spot printed on the felt. */
  function cardSlot(g, x, y, w, h, color) {
    rr(g, x - w / 2, y - h / 2, w, h, w * 0.09);
    g.setLineDash([8, 6]);
    g.lineWidth = 2;
    g.strokeStyle = color;
    g.stroke();
    g.setLineDash([]);
  }

  /** Where an appearing card is: flies from (fx, fy) to its spot while it turns over. */
  function cardFly(S, key, fx, fy, x, y, t, dur) {
    const t0 = S.seen.get(key);
    if (t0 == null) {
      S.seen.set(key, S.firstIngest ? -1e9 : t);
      if (!S.firstIngest) S.animUntil = Math.max(S.animUntil, t + (dur || 0.55));
      return { x: S.firstIngest ? x : fx, y: S.firstIngest ? y : fy, flip: S.firstIngest ? 1 : 0, rot: 0 };
    }
    return flyAge(S, t - t0, fx, fy, x, y, dur);
  }
  /** A card `age` s into its flight (dur s) from (fx, fy) to (x, y), turning over on the way. */
  function flyAge(S, age, fx, fy, x, y, dur) {
    const d = dur || 0.55;
    if (age < d) S.animUntil = Math.max(S.animUntil, S.t + 0.05);
    const u = clamp(age / d, 0, 1);
    const e = easeOut(u);
    return { x: lerp(fx, x, e), y: lerp(fy, y, e) - Math.sin(u * Math.PI) * 40, flip: clamp((u - 0.35) / 0.65, 0, 1), rot: (1 - e) * -0.5 };
  }

  // chips: a casino chip — body and edge inserts in the ladder's colours (casino/chips.py), an inlay that can carry a
  // player's colour and the amount. Pre-rendered once per look as a sprite (drop shadow baked in), then stamped.
  // The chip SET (status.chip_set, docs/CASINO.md §5) changes the material and the motifs to match the table — clay,
  // ceramic, gold-rimmed, neon, jade, pixel, ivory — while the denomination's colour and label stay what they are.
  const CHIP_SETS = ["clay", "ceramic", "gold_rim", "neon", "jade", "pixel", "ivory"];
  // casino/chips.py THEME_CHIP_SET: an engine that doesn't send status.chip_set gets the theme's own set
  const THEME_CHIP_SET = {
    classic: "clay", royal: "ceramic", crimson: "gold_rim", midnight: "neon", strip: "neon", emerald: "clay", burgundy: "ivory",
    noir: "gold_rim", jade: "jade", deco: "gold_rim", marigold: "gold_rim", diwali: "gold_rim", cyber: "neon", arcade: "pixel",
    sakura: "ceramic", arctic: "ceramic", oasis: "ceramic", abyss: "neon", volcano: "neon", galaxy: "neon", riverboat: "ivory",
  }; // fmt: skip
  /** The table's chip set: status.chip_set, else the theme's own, else clay. */
  function chipSetOf(st) {
    const s = String(obj(st).chip_set || "");
    if (CHIP_SETS.includes(s)) return s;
    return THEME_CHIP_SET[String(obj(obj(st).table_theme).id || "")] || "clay";
  }
  let CHIPSET = "clay"; // the set in use while a scene paints (one scene at a time)
  const chipCache = new Map();
  function chipSprite(r, color, edge, inlay, label, k, glow) {
    const set = CHIPSET;
    const key = `${set}|${r}|${color}|${edge}|${inlay || ""}|${label == null ? "" : label}|${k}|${glow || ""}`;
    let c = chipCache.get(key);
    if (c) return c;
    if (chipCache.size > 500) chipCache.clear();
    const pad = Math.ceil(r * 0.6) + (glow ? Math.ceil(r * 0.5) : 0);
    const D = 2 * (r + pad);
    const m = makeCanvas(D, D, k);
    const g = m.g;
    const x = D / 2;
    const y = D / 2;
    if (glow) {
      g.save();
      glowOn(g, glow, r * 0.9);
      circle(g, x, y, r * 1.04);
      g.lineWidth = Math.max(2, r * 0.12);
      g.strokeStyle = glow;
      g.stroke();
      g.restore();
    }
    const neon = set === "neon";
    const ivory = set === "ivory";
    const body = neon ? shade(color, 0.16) : ivory ? "#efe6cf" : color;
    // drop shadow (soft once, here), the body
    g.save();
    glowOn(g, "rgba(0,0,0,.55)", r * 0.35, r * 0.12);
    if (set === "pixel") {
      const u = r / 6;
      g.beginPath();
      for (let j = -6; j < 6; j++) {
        const yy = (j + 0.5) * u;
        const half = Math.round(Math.sqrt(Math.max(0, r * r - yy * yy)) / u) * u;
        g.rect(x - half, y + j * u, 2 * half, u + 0.4);
      }
    } else circle(g, x, y, r);
    g.fillStyle = body;
    g.fill();
    g.restore();
    if (set !== "pixel") {
      const lg = g.createRadialGradient(x - r * 0.4, y - r * 0.45, r * 0.1, x, y, r);
      lg.addColorStop(0, set === "ceramic" ? "rgba(255,255,255,.4)" : "rgba(255,255,255,.22)");
      lg.addColorStop(0.6, "rgba(255,255,255,0)");
      lg.addColorStop(1, "rgba(0,0,0,.25)");
      circle(g, x, y, r);
      g.fillStyle = lg;
      g.fill();
    }
    // the edge: the set's inserts, always in the denomination's own stripe colour
    if (set === "clay") {
      g.lineWidth = r * 0.22;
      g.strokeStyle = edge;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU + 0.26;
        g.beginPath();
        g.arc(x, y, r * 0.86, a, a + 0.42);
        g.stroke();
      }
    } else if (set === "ceramic") {
      g.lineWidth = r * 0.16;
      g.strokeStyle = edge;
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        g.beginPath();
        g.arc(x, y, r * 0.88, a, a + 0.12);
        g.stroke();
      }
      g.lineWidth = Math.max(1, r * 0.05);
      circle(g, x, y, r * 0.74);
      g.strokeStyle = rgba(edge, 0.8);
      g.stroke();
    } else if (set === "gold_rim") {
      const gm = g.createLinearGradient(x - r, y - r, x + r, y + r);
      gm.addColorStop(0, "#fff2c0");
      gm.addColorStop(0.45, "#c9973a");
      gm.addColorStop(0.7, "#7a5410");
      gm.addColorStop(1, "#f0d488");
      g.lineWidth = r * 0.16;
      circle(g, x, y, r * 0.92);
      g.strokeStyle = gm;
      g.stroke();
      g.lineWidth = r * 0.14;
      g.strokeStyle = edge;
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * TAU + 0.4;
        g.beginPath();
        g.arc(x, y, r * 0.74, a, a + 0.6);
        g.stroke();
      }
      g.fillStyle = "#fff2c0";
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU + 0.2;
        circle(g, x + Math.cos(a) * r * 0.92, y + Math.sin(a) * r * 0.92, r * 0.05);
        g.fill();
      }
    } else if (neon) {
      g.save();
      glowOn(g, color, r * 0.5);
      g.lineWidth = r * 0.11;
      circle(g, x, y, r * 0.86);
      g.strokeStyle = shade(color, 1.35);
      g.stroke();
      g.restore();
      g.lineWidth = r * 0.07;
      g.strokeStyle = edge;
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        g.beginPath();
        g.arc(x, y, r * 0.86, a, a + 0.18);
        g.stroke();
      }
    } else if (set === "jade") {
      g.save();
      circle(g, x, y, r);
      g.clip();
      g.lineWidth = r * 0.07;
      for (let i = 0; i < 4; i++) {
        g.beginPath();
        g.moveTo(x - r, y - r * 0.6 + i * r * 0.45);
        g.bezierCurveTo(x - r * 0.3, y - r * 0.9 + i * r * 0.5, x + r * 0.2, y + i * r * 0.2, x + r, y - r * 0.4 + i * r * 0.5);
        g.strokeStyle = i % 2 ? "rgba(255,255,255,.16)" : "rgba(160,255,200,.14)";
        g.stroke();
      }
      g.restore();
      g.lineWidth = r * 0.08;
      circle(g, x, y, r * 0.9);
      g.strokeStyle = "#d9b45a";
      g.stroke();
      g.lineWidth = r * 0.14;
      g.strokeStyle = edge;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU + 0.1;
        g.beginPath();
        g.arc(x, y, r * 0.78, a, a + 0.24);
        g.stroke();
      }
    } else if (set === "pixel") {
      const u = r / 6;
      g.fillStyle = edge;
      for (const [i, j] of [[-1, -6], [0, -6], [-1, 5], [0, 5], [-6, -1], [-6, 0], [5, -1], [5, 0], [-4, -4], [3, -4], [-4, 3], [3, 3]]) g.fillRect(x + i * u, y + j * u, u, u);
    } else if (ivory) {
      g.lineWidth = r * 0.16;
      circle(g, x, y, r * 0.8);
      g.strokeStyle = color;
      g.stroke();
      g.lineWidth = r * 0.2;
      g.strokeStyle = shade(color, 0.7);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU + 0.26;
        g.beginPath();
        g.arc(x, y, r * 0.94, a, a + 0.22);
        g.stroke();
      }
    }
    // the inlay
    const ink = inlay || (neon ? "#0b0b12" : ivory ? "#f6efdc" : shade(color, 0.86));
    if (set === "pixel") {
      const u = r / 6;
      g.fillStyle = ink;
      g.fillRect(x - 3 * u, y - 3 * u, 6 * u, 6 * u);
      g.fillStyle = rgba("#ffffff", 0.18);
      g.fillRect(x - 3 * u, y - 3 * u, 6 * u, u);
    } else {
      circle(g, x, y, r * 0.62);
      g.fillStyle = ink;
      g.fill();
      g.lineWidth = Math.max(1, r * 0.06);
      if (set === "clay") {
        g.setLineDash([r * 0.16, r * 0.12]);
        g.strokeStyle = rgba(edge, 0.75);
        circle(g, x, y, r * 0.55);
        g.stroke();
        g.setLineDash([]);
      } else if (set === "ceramic") {
        g.fillStyle = rgba(edge, 0.85);
        for (let i = 0; i < 16; i++) {
          const a = (i / 16) * TAU;
          circle(g, x + Math.cos(a) * r * 0.54, y + Math.sin(a) * r * 0.54, r * 0.03);
          g.fill();
        }
      } else if (set === "gold_rim" || set === "jade") {
        circle(g, x, y, r * 0.6);
        g.strokeStyle = "#e9c25a";
        g.stroke();
        g.setLineDash([r * 0.05, r * 0.07]);
        circle(g, x, y, r * 0.53);
        g.strokeStyle = rgba("#e9c25a", 0.7);
        g.stroke();
        g.setLineDash([]);
      } else if (neon) {
        g.save();
        glowOn(g, color, r * 0.35);
        circle(g, x, y, r * 0.6);
        g.strokeStyle = shade(color, 1.3);
        g.stroke();
        g.restore();
      } else if (ivory) {
        circle(g, x, y, r * 0.6);
        g.strokeStyle = color;
        g.stroke();
      }
    }
    if (set !== "pixel") {
      circle(g, x, y, r - 0.5);
      g.lineWidth = 1;
      g.strokeStyle = "rgba(0,0,0,.35)";
      g.stroke();
    }
    if (label != null && label !== "") {
      const [rr2, gg, bb] = hexRgb(inlay || (neon ? "#0b0b12" : ivory ? "#f6efdc" : color)); // the inlay is the owner's colour, or the set's own
      const light = rr2 * 0.3 + gg * 0.59 + bb * 0.11 > 150;
      const s = String(label);
      const size = r * (s.length >= 5 ? 0.42 : s.length === 4 ? 0.5 : s.length === 3 ? 0.6 : 0.72);
      const ink2 = neon && !inlay ? shade(color, 1.45) : ivory && !inlay ? shade(color, 0.6) : light ? "#141414" : "#ffffff";
      txt(g, s, x, y + size * 0.36, size, ink2, { align: "center", font: "mono", weight: 800, shadow: false });
    }
    c = { c: m.c, D };
    chipCache.set(key, c);
    return c;
  }

  /** One chip at (x, y). o: {alpha, glow, edge, inlay}. */
  function chip(g, x, y, r, color, label, o) {
    o = o || {};
    const sp = chipSprite(r, color, o.edge || "#ffffff", o.inlay || null, label, chipK(g), o.glow || null);
    const a = g.globalAlpha;
    if (o.alpha != null) g.globalAlpha = a * o.alpha;
    g.drawImage(sp.c, x - sp.D / 2, y - sp.D / 2, sp.D, sp.D);
    g.globalAlpha = a;
  }
  /** The device px per stage px a context draws at (its transform's scale; 1 in tests). */
  function chipK(g) {
    try {
      const m = g.getTransform && g.getTransform();
      const k = m && typeof m.a === "number" ? Math.hypot(m.a, m.b) : 1;
      return Math.round(clamp(k, 0.5, 3) * 4) / 4;
    } catch (e) {
      return 1;
    }
  }

  /**
   * A stack worth `amount`: the amount broken into ladder chips (largest at the bottom), the top chip's inlay in the
   * owner's colour with the total on it. o: {alpha, glow, rack}.
   */
  function stack(S, g, x, y, r, amount, owner, o) {
    o = o || {};
    const parts = breakInto(amount, o.rack || S.rack).slice(0, 8);
    if (!parts.length) return;
    const n = parts.length;
    for (let j = 0; j < n - 1; j++) {
      const cs = chipStyle(parts[j], o.rack || S.rack);
      chip(g, x, y + (n - 1 - j) * r * 0.17, r, cs.color, null, { alpha: o.alpha, edge: cs.edge });
    }
    const top = chipStyle(parts[n - 1], o.rack || S.rack);
    chip(g, x, y, r, top.color, shortChip(amount), { alpha: o.alpha, edge: top.edge, inlay: owner || null, glow: o.glow });
  }

  /**
   * Everyone's chips on one spot: a stack per player (their colour on the inlay), fanned, the amount on each, broken
   * into the ladder's chips. New chips drop in. o: {r, glow, dim, sweepAt (s into the win / lose moment: the stack is
   * swept to `to` and fades — as a flight, a sprite moved by transforms, never a table redraw), to: [x, y]}.
   */
  function spotChips(S, g, spot, entries, x, y, t, o) {
    o = o || {};
    const r = o.r || 22;
    const list = arr(entries);
    const n = list.length;
    list.forEach((e, i) => {
      const key = `${spot}|${e.seat}`;
      const t0 = S.chipT.get(key);
      const u = t0 == null ? 1 : clamp((t - t0) / 0.38, 0, 1);
      let cx = x + (i - (n - 1) / 2) * r * 0.9;
      // drop in with a small bounce (easeOutBack)
      const drop = u < 1 ? 1 - (1 + 2.2 * Math.pow(u - 1, 3) + 1.2 * Math.pow(u - 1, 2)) : 0;
      let cy = y + (i - (n - 1) / 2) * r * 0.25 - drop * 60;
      let alpha = (u < 1 ? 0.3 + 0.7 * Math.min(1, u * 2) : 1) * (o.dim ? 0.3 : 1);
      if (o.sweepAt != null && momentAge(S) != null) {
        flight(S, `sw|${key}`, { amount: num(e.amount), owner: e.color || "#f0f0f0", r, from: [cx, cy], to: o.to || [x, y - 200], at: o.sweepAt, dur: MOMENT.SWEEP, fade: true });
        return;
      }
      if (alpha <= 0.01) return;
      stack(S, g, cx, cy, r, num(e.amount), e.color || "#f0f0f0", { alpha, glow: o.glow });
    });
  }

  /**
   * Chips on the move during the win / lose moment — losing stacks swept to the dealer, payouts pushed to winners —
   * as sprites: each stack drawn once into a small canvas of a pool and moved by transform / opacity on the shared
   * clock (the moment's age), so the big table layer never redraws for them. The table's draw() declares them
   * (`flight`); every frame `flightsFrame` places them.
   */
  function flight(S, key, f) {
    if (S.flights) S.flights.set(key, f);
  }
  const FLIGHT_POOL = 28;
  function flightsFrame(S) {
    const pool = S.flightPool || (S.flightPool = []);
    const a = momentAge(S);
    const used = new Set();
    if (a != null && S.flights) {
      let i = 0;
      for (const [key, f] of S.flights) {
        if (i >= FLIGHT_POOL) break;
        let sp = pool.find((x) => x.key === key && !used.has(x));
        if (!sp) sp = pool.find((x) => !used.has(x) && !S.flights.has(x.key));
        if (!sp) {
          if (pool.length >= FLIGHT_POOL) break;
          const D = 96;
          sp = { l: layer(S.fxBox, 0, 0, D, D + 30, chipLayerK(), true, true), key: null, D };
          sp.l.c.style.display = "none";
          sp.l.cache = { display: "none" };
          pool.push(sp);
        }
        used.add(sp);
        i++;
        if (sp.key !== key || sp.paintKey !== `${f.amount}|${f.owner}|${f.r}|${S.chipSet}`) {
          sp.key = key;
          sp.paintKey = `${f.amount}|${f.owner}|${f.r}|${S.chipSet}`;
          const g = sp.l.g;
          g.setTransform(sp.l.k, 0, 0, sp.l.k, 0, 0);
          g.clearRect(0, 0, sp.D, sp.D + 30);
          stack(S, g, sp.D / 2, sp.D / 2 + 20, f.r, f.amount, f.owner, { glow: f.glow || null });
        }
        const u = clamp((a - f.at) / f.dur, 0, 1);
        const k = easeInOut(u);
        const x = lerp(f.from[0], f.to[0], k);
        const y = lerp(f.from[1], f.to[1], k);
        const op = f.fade ? 1 - u : clamp(u * 4, 0, 1);
        if (op <= 0.01 || (!f.fade && u <= 0)) hideLayer(sp.l);
        else moveLayer(sp.l, `translate(${(x - sp.D / 2).toFixed(1)}px,${(y - sp.D / 2 - 20).toFixed(1)}px) scale(${(f.fade ? 1 - 0.25 * k : 1).toFixed(3)})`, op.toFixed(3));
      }
    }
    for (const sp of pool) if (!used.has(sp)) hideLayer(sp.l);
  }
  const chipLayerK = () => clamp(num(TV && TV.pixelRatio, 1), 1, 1.5);

  /** A player's avatar: the 8×8 art (hello.avatars) in their colour on a dark disc, ringed in their colour. */
  function avatar(S, g, x, y, r, p, o) {
    o = o || {};
    const color = (p && p.color) || "#f0f0f0";
    g.save();
    if (o.alpha != null) g.globalAlpha *= o.alpha;
    circle(g, x, y, r);
    g.fillStyle = P.light ? "#fdfaf3" : "#121218"; // light: an ivory disc (the art turns to ink on it, below)
    g.fill();
    g.lineWidth = Math.max(3, r * 0.12);
    g.strokeStyle = color;
    if (o.glow) {
      const lw = g.lineWidth;
      glowFx(g, `ring|${r}|${lw}`, x - r - lw, y - r - lw, 2 * (r + lw), 2 * (r + lw), color, r * 0.8, (m) => {
        circle(m, x, y, r);
        m.lineWidth = lw;
        m.strokeStyle = "#000";
        m.stroke();
      });
      circle(g, x, y, r);
    }
    g.stroke();
    const art = obj(obj(S.ctx && S.ctx.avatars)[p && p.avatar]).px;
    if (Array.isArray(art) && art.length) {
      const n = art.length;
      const cell = (r * 1.25) / n;
      const pal = P.light
        ? { c: inkOf(color), d: shade(color, 0.35), w: P.ink2, k: "#000000", y: "#9a6a00", r: "#c8203e" }
        : { c: color, d: shade(color, 0.55), w: "#f0f0f0", k: "#000000", y: "#ffc800", r: "#ff3c3c" };
      for (let j = 0; j < n; j++) {
        const row = String(art[j]);
        for (let i = 0; i < row.length; i++) {
          const f = pal[row[i]];
          if (!f || f === "#000000") continue;
          g.fillStyle = f;
          g.fillRect(x - (cell * n) / 2 + i * cell, y - (cell * n) / 2 + j * cell, cell + 0.3, cell + 0.3);
        }
      }
    } else {
      const name = String((p && p.name) || "?");
      txt(g, name.slice(0, 1).toUpperCase(), x, y + r * 0.36, r * 1.0, inkOf(color), { align: "center", weight: 800, shadow: false });
    }
    g.restore();
  }

  // felt grain (a small noise tile, one per page)
  let grainTile = null;
  function grain(g) {
    if (!grainTile) {
      const m = makeCanvas(96, 96, 1);
      let s = 7;
      for (let i = 0; i < 900; i++) {
        s = (s * 16807) % 2147483647;
        const x = s % 96;
        s = (s * 16807) % 2147483647;
        const y = s % 96;
        m.g.fillStyle = i % 3 ? "rgba(255,255,255,.035)" : "rgba(0,0,0,.08)";
        m.g.fillRect(x, y, 1.4, 1.4);
      }
      grainTile = m.c;
    }
    const p = g.createPattern && g.createPattern(grainTile, "repeat");
    return p || "rgba(0,0,0,0)";
  }

  /** Fill the current path with the theme's felt: a deep pile under a soft overhead spot at (cx, cy), grain on top. */
  function feltFill(g, th, cx, cy, rad) {
    const gr = g.createRadialGradient(cx, cy - rad * 0.12, 0, cx, cy, rad);
    gr.addColorStop(0, shade(th.felt, 1.2));
    gr.addColorStop(0.34, shade(th.felt, 1.04));
    gr.addColorStop(0.7, th.felt2 || th.felt);
    gr.addColorStop(1, shade(th.felt3 || th.felt, 0.72));
    g.fillStyle = gr;
    g.fill();
    g.fillStyle = grain(g);
    g.fill();
    return gr;
  }

  /**
   * The ultra-luxury table around the current path — drawn once, in the cached background, so every effect here is
   * free per frame: the felt (feltFill) sinks under the rail in a soft inner shadow with a gold pinstripe printed
   * just inside it, then the padded rail: a lacquered mahogany profile built from layered strokes (dark edges, a
   * warm crown), a brass inlay along both edges, a gloss line and a long contact shadow on the room.
   */
  function luxTable(g, th, cx, cy, rad, railW) {
    const W = railW || 36;
    const gr = feltFill(g, th, cx, cy, rad);
    g.save();
    g.clip();
    // the printed gold pinstripe, 12 px in from the rail (a gold band, then the felt again over all but 2 px of it)
    g.lineJoin = "round";
    g.lineWidth = W + 26;
    g.strokeStyle = rgba(th.accent, 0.62);
    g.stroke();
    g.lineWidth = W + 22;
    g.strokeStyle = gr;
    g.stroke();
    g.strokeStyle = grain(g);
    g.stroke();
    // the felt dips under the rail
    softStroke(g, W, 46, "#000", 0.85, 0, 0, 6);
    g.restore();
    railStroke(g, th, W / 2);
  }

  /**
   * A soft shadow along the current path without shadowBlur: the path stroked a few times, each wider and fainter,
   * offset by (dx, dy) — what a blur would give at a fraction of its cost on a software canvas.
   */
  function softStroke(g, width, spread, color, alpha, dx, dy, steps) {
    const n = steps || 6;
    g.save();
    g.translate(dx || 0, dy || 0);
    g.lineJoin = "round";
    g.strokeStyle = color;
    for (let i = n; i >= 1; i--) {
      g.globalAlpha = alpha / n;
      g.lineWidth = width + (2 * spread * i) / n;
      g.stroke();
    }
    g.restore();
  }

  /** The table's padded rail around the current path: lacquered wood with brass inlay (see luxTable). */
  function railStroke(g, th, width) {
    const W = width * 2;
    const [outer, groove, inlay, profile, gloss] = P.rail; // mahogany in the dark, white lacquer in daylight
    softStroke(g, W, 40, P.railShadow[0], P.railShadow[1], 0, 16, 7);
    g.save();
    g.lineJoin = "round";
    // gold on both edges, then the rail's rounded profile from the edges to the crown
    g.lineWidth = W;
    g.strokeStyle = outer;
    g.stroke();
    g.lineWidth = W - 2;
    g.strokeStyle = groove;
    g.stroke();
    g.lineWidth = W - 4;
    g.strokeStyle = inlay;
    g.stroke();
    for (const [k, c] of profile) {
      g.lineWidth = W * k;
      g.strokeStyle = c;
      g.stroke();
    }
    if (P.light) {
      // white lacquer carries a second, inner gold inlay line along its crown
      g.lineWidth = W * 0.5;
      g.strokeStyle = "rgba(184,137,42,.55)";
      g.stroke();
      g.lineWidth = W * 0.5 - 2;
      g.strokeStyle = profile[3][1];
      g.stroke();
      g.lineWidth = W * 0.3;
      g.strokeStyle = profile[5][1];
      g.stroke();
    }
    // the lacquer: a fine gloss along the crown
    g.lineWidth = Math.max(1.5, W * 0.035);
    g.strokeStyle = gloss;
    g.stroke();
    g.restore();
  }

  /** A faint damask lattice on the salon's walls (cached background). */
  function damask(g, th, x, y, w, h) {
    g.save();
    g.beginPath();
    g.rect(x, y, w, h);
    g.clip();
    const gold = P.light ? "#b8892a" : th.accent;
    g.strokeStyle = rgba(gold, P.damask);
    g.lineWidth = 1.5;
    const s = 64;
    g.beginPath();
    for (let i = -h; i < w + h; i += s) {
      g.moveTo(x + i, y);
      g.lineTo(x + i + h, y + h);
      g.moveTo(x + i + h, y);
      g.lineTo(x + i, y + h);
    }
    g.stroke();
    g.fillStyle = rgba(gold, P.damask * 1.2);
    for (let j = 0; j <= h / s + 1; j++)
      for (let i = 0; i <= w / s + 1; i++) {
        const cx = x + i * s + (j % 2 ? s / 2 : 0);
        const cy = y + j * (s / 2);
        g.beginPath();
        g.moveTo(cx, cy - 5);
        g.lineTo(cx + 3.5, cy);
        g.lineTo(cx, cy + 5);
        g.lineTo(cx - 3.5, cy);
        g.closePath();
        g.fill();
      }
    g.restore();
  }

  /** A box printed on the felt (betting area): soft fill, accent outline, optional colour band. */
  function feltBox(g, th, x, y, w, h, o) {
    o = o || {};
    rr(g, x, y, w, h, o.r == null ? 18 : o.r);
    g.fillStyle = o.fill || "rgba(0,0,0,.16)";
    g.fill();
    g.lineWidth = o.lw || 3;
    g.strokeStyle = o.stroke || rgba(th.accent, 0.7);
    g.stroke();
  }

  /** A glow around a rounded box (winning area). */
  function glowBox(g, x, y, w, h, color, k, r) {
    const rad = r == null ? 18 : r;
    g.save();
    // the glow: a sprite per pulse step (k in 1/32ths — the blur and the line's strength follow it)
    const kq = Math.round(clamp(k, 0, 1) * 32) / 32;
    glowFx(g, `box|${w}|${h}|${rad}|${kq}`, x, y, w, h, color, 40 * kq, (m) => {
      rr(m, x, y, w, h, rad);
      m.lineWidth = 5;
      m.strokeStyle = `rgba(0,0,0,${0.4 + 0.6 * kq})`;
      m.stroke();
      m.fillStyle = `rgba(0,0,0,${0.12 * kq})`;
      m.fill();
    });
    g.lineWidth = 5;
    g.strokeStyle = rgba(color, 0.4 + 0.6 * k);
    rr(g, x, y, w, h, rad);
    g.stroke();
    g.fillStyle = rgba(color, 0.12 * k);
    g.fill();
    g.restore();
  }

  // ================================================================================================ the scene shell
  function seatKey(s) {
    return s === "host" ? 0 : num(Number(s), 99);
  }

  /** Who is at the table, from status.players: online first, then by seat. */
  function tablePlayers(st) {
    return arr(st.players)
      .filter((p) => p && (p.online || num(p.staked) > 0))
      .slice()
      .sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || seatKey(a.seat) - seatKey(b.seat));
  }

  function ingest(S, ctx) {
    S.ctx = ctx;
    const st = obj(ctx.status);
    const t = typeof ctx.stateAt === "number" && ctx.stateAt > 0 ? ctx.stateAt : nowOf(ctx);
    S.st = st;
    S.th = Object.assign({}, CLASSIC, obj(ctx.theme && Object.keys(ctx.theme).length ? ctx.theme : obj(st.table_theme).css));
    S.preview = st.view != null && st.view !== "live";
    S.clk.observe(st, t);
    const sig = sigOf(st);
    if (sig !== S.sig) {
      S.sig = sig;
      S.ver += 1;
    }
    S.players = tablePlayers(st);
    S.rack = rackOf(st); // the table's chips (status.chips, or computed from the limits on an older engine)
    S.bySeat = new Map();
    for (const p of arr(st.players)) if (p) S.bySeat.set(String(p.seat), p);
    // chips that just landed (drop-in animation)
    const sb = obj(st.spot_bets);
    const seenNow = new Set();
    for (const spot of Object.keys(sb)) {
      for (const e of arr(sb[spot])) {
        const key = `${spot}|${e.seat}`;
        seenNow.add(key);
        const prev = S.chipAmt.get(key);
        if (prev == null || num(e.amount) > prev) {
          S.chipT.set(key, S.firstIngest ? -1e9 : t);
          if (!S.firstIngest) S.animUntil = Math.max(S.animUntil, t + 0.45);
        }
        S.chipAmt.set(key, num(e.amount));
      }
    }
    for (const k of [...S.chipAmt.keys()]) if (!seenNow.has(k)) {
      S.chipAmt.delete(k);
      S.chipT.delete(k);
    }
    if (S.round !== st.round) {
      if (S.round != null) S.seen.clear();
      S.round = st.round;
    }
    if (S.def.ingest) S.def.ingest(S, st, t);
    S.chipSet = chipSetOf(st);
    momentIngest(S, t);
    bgWanted(S);
    S.firstIngest = false;
  }

  function nowOf(ctx) {
    try {
      if (ctx && typeof ctx.now === "function") return ctx.now();
    } catch (e) {
      /* fall through */
    }
    return (typeof performance !== "undefined" ? performance.now() : Date.now()) / 1000;
  }

  /** The colour of a seat (status.players, then the lobby / defaults). */
  function seatColor(S, seat) {
    const p = S.bySeat.get(String(seat));
    if (p && p.color) return p.color;
    try {
      if (S.ctx && typeof S.ctx.seatColor === "function" && typeof seat === "number") return S.ctx.seatColor(seat);
    } catch (e) {
      /* ignore */
    }
    return seat === "host" ? "#00c8ff" : "#f0f0f0";
  }
  const playerOf = (S, seat) => S.bySeat.get(String(seat)) || { seat, name: `P${seat}`, color: seatColor(S, seat) };

  function winners(S) {
    const r = obj(S.st.result);
    return arr(r.winners).map((w) => ({ ...w, color: seatColor(S, w.seat), avatar: (playerOf(S, w.seat) || {}).avatar }));
  }

  /**
   * An absolutely placed canvas layer (stage px), backing store × k. Moving layers get their own GPU layer. Draw with
   * `g`, then call `show()`: the layer is a surface (tv.js) — drawn off-screen and handed to the page as a finished
   * bitmap, so the compositor never re-reads it — and after show() its drawing buffer is blank, so every redraw is
   * a full one (each caller clears and draws everything). `size(w, h, k)` resizes it (blank until the next draw).
   */
  function layer(parent, x, y, w, h, k, moving, plain) {
    const c = document.createElement("canvas");
    // big layers only (the table, rail, wheels): they redraw rarely, and copying them every frame is what costs; a
    // small canvas is cheaper to copy than to hand over a fresh bitmap each time it changes (`plain`: never a surface)
    const big = !plain && w * h * k * k >= 200000;
    const sf = big && TV && typeof TV.surface === "function" ? TV.surface : null;
    let s = null;
    const size = (kk) => {
      if (sf) s = sf(c, Math.max(1, Math.ceil(w * kk)), Math.max(1, Math.ceil(h * kk)));
      else {
        c.width = Math.max(1, Math.ceil(w * kk));
        c.height = Math.max(1, Math.ceil(h * kk));
      }
    };
    size(k);
    const st = c.style;
    st.position = "absolute";
    st.left = `${x}px`;
    st.top = `${y}px`;
    st.width = `${w}px`;
    st.height = `${h}px`;
    st.pointerEvents = "none";
    if (moving) {
      st.willChange = "transform, opacity";
      st.transformOrigin = "50% 50%";
    }
    parent.appendChild(c);
    const g = s ? s.g : c.getContext("2d");
    g.setTransform(k, 0, 0, k, 0, 0);
    const show = TV && typeof TV.showSurface === "function" && s ? () => TV.showSurface(s) : () => {};
    const l = { c, g, w, h, k, x, y, show };
    l.size = (kk) => {
      size(kk);
      l.k = kk;
    };
    return l;
  }

  /** A status signature for redraw decisions: countdown seconds and other per-tick values left out. */
  const VOLATILE = new Set(["rev", "reveal_in", "next_in", "ends_in", "age", "t", "call_in", "first_in", "turn_in", "in", "insurance_in", "at"]);
  const sigOf = (st) => JSON.stringify(st, (k, v) => (VOLATILE.has(k) ? (v == null ? null : 1) : v));

  /**
   * The engine's clock on this TV (seconds): local monotonic time + the offset tv.js estimates from server_time,
   * slewed at ≤ 30 % of real time so it never jumps (a jump > 1 s — first sync, a sleep — snaps) and never runs
   * backwards. Every reveal animation is a function of this clock, as the panel's is of the engine's.
   */
  function serverClock(S, tl) {
    const c = S.ctx || {};
    let off = 0;
    try {
      if (typeof c.serverNow === "function" && typeof c.now === "function") off = c.serverNow() - c.now();
    } catch (e) {
      off = 0;
    }
    if (!Number.isFinite(off)) off = 0;
    const k = S.sclk;
    if (k.off == null || Math.abs(off - k.off) > 1) k.off = off;
    else {
      const dt = clamp(tl - k.last, 0, 0.5);
      k.off += clamp(off - k.off, -0.3 * dt, 0.3 * dt);
    }
    k.last = tl;
    let T = tl + k.off;
    if (k.T != null && T < k.T) T = k.T;
    k.T = T;
    return T;
  }

  /** The TV-only reveal of the locked round (ctx.tv.reveal, docs/TV_VIEW.md §3) for `game`, or null. */
  function revealOf(S, game) {
    const rv = obj(obj(S.ctx && S.ctx.tv).reveal);
    return rv.game === game && (rv.outcome || rv.stops) ? rv : null;
  }
  /** Seconds since betting closed, on the engine's clock (frozen while the host pauses). */
  const sinceLockOf = (rv, T) => (rv.paused ? num(rv.since_lock) : T - (num(rv.at) - num(rv.since_lock)));

  // ------------------------------------------------------------------------------------------------ the stamp
  // A rubber stamp slammed onto the winning spot: it drops in at ×1.6, squashes on impact, splashes an ink ring
  // and settles slightly rotated, then stays (ink texture, worn edge) until the round clears. Two pre-rendered
  // layers animated by transform / opacity only (60 fps on a TV stick).
  const STAMP = 150;
  function stampLayers(S, root, name) {
    const k = wheelK();
    const st = layer(root, 0, 0, STAMP, STAMP, k, true);
    const ink = layer(root, 0, 0, STAMP, STAMP, k, true);
    const burst = layer(root, 0, 0, BURST, BURST, Math.min(k, 1), false);
    st.c.style.opacity = "0";
    ink.c.style.opacity = "0";
    burst.c.style.display = "none";
    S.L[name] = { st, ink, burst, key: null };
  }
  /**
   * The result moment: gold sparks burst from the stamp as it hits and fall away (a small canvas of its own, drawn
   * only for those 0.9 s). A pure function of the stamp's age on the shared clock, so every screen bursts together.
   */
  const BURST = 420;
  function burstDraw(S, name, x, y, age, color) {
    const L = S.L[name];
    const b = L.burst;
    if (!b) return;
    const on = age != null && age >= 0 && age < 0.9;
    if (!on) {
      if (L.burstOn) {
        b.c.style.display = "none";
        L.burstOn = false;
      }
      return;
    }
    if (!L.burstOn) {
      b.c.style.display = "";
      L.burstOn = true;
    }
    b.c.style.left = `${(x - BURST / 2).toFixed(1)}px`;
    b.c.style.top = `${(y - BURST / 2).toFixed(1)}px`;
    const g = b.g;
    g.setTransform(b.k, 0, 0, b.k, 0, 0);
    g.clearRect(0, 0, BURST, BURST);
    const n = 26;
    const c = BURST / 2;
    const u = age / 0.9;
    for (let i = 0; i < n; i++) {
      const h = hash01(`${name}${i}`);
      const a = (i / n) * TAU + h * 0.6;
      const v = 120 + 110 * hash01(`${i}${name}v`);
      const d = v * easeOut(u) * 1.25;
      const px = c + Math.cos(a) * d;
      const py = c + Math.sin(a) * d + 90 * u * u; // a little gravity
      const r = (i % 3 === 0 ? 6 : 4) * (1 - u * 0.7);
      g.globalAlpha = 1 - u;
      g.fillStyle = i % 4 === 0 ? "#ffffff" : color;
      circle(g, px, py, r);
      g.fill();
    }
    g.globalAlpha = 1;
    b.show();
  }
  /** Draw the stamp's face (once per text / colour). */
  function stampPaint(S, name, text, color) {
    const L = S.L[name];
    const key = `${text}|${color}`;
    if (L.key === key) return;
    L.key = key;
    const c = STAMP / 2;
    for (const l of [L.st, L.ink]) {
      l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
      l.g.clearRect(0, 0, STAMP, STAMP);
    }
    const g = L.st.g;
    g.save();
    g.globalAlpha = 0.9;
    g.lineWidth = 7;
    g.strokeStyle = color;
    circle(g, c, c, c - 8);
    g.stroke();
    g.lineWidth = 2.5;
    circle(g, c, c, c - 19);
    g.stroke();
    // the stars between the rings
    g.fillStyle = color;
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * TAU;
      circle(g, c + Math.cos(a) * (c - 13.5), c + Math.sin(a) * (c - 13.5), 2);
      g.fill();
    }
    const s = String(text);
    const size = s.length > 3 ? 34 : s.length > 2 ? 44 : 60;
    g.font = `900 ${size}px ${FONT}`;
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(s, c, c + 3);
    // worn ink: knock a speckle of holes out of the print
    g.globalCompositeOperation = "destination-out";
    let r = 1234567;
    for (let i = 0; i < 260; i++) {
      r = (r * 16807) % 2147483647;
      const x = (r % 1000) / 1000;
      r = (r * 16807) % 2147483647;
      const y = (r % 1000) / 1000;
      g.globalAlpha = 0.25 + ((i * 37) % 10) / 20;
      circle(g, x * STAMP, y * STAMP, 0.8 + (i % 3) * 0.7);
      g.fill();
    }
    g.restore();
    const ig = L.ink.g;
    ig.save();
    ig.lineWidth = 5;
    ig.strokeStyle = rgba(color, 0.55);
    circle(ig, c, c, c - 6);
    ig.stroke();
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * TAU + 0.3;
      ig.fillStyle = rgba(color, 0.5);
      circle(ig, c + Math.cos(a) * (c - 4), c + Math.sin(a) * (c - 4), 3 + (i % 3));
      ig.fill();
    }
    ig.restore();
    L.st.show();
    L.ink.show();
  }
  /**
   * Place the stamp: centre (x, y) on the stage, `age` seconds since it hit (< 0: not yet; null: hidden),
   * `size` px across, its resting tilt `rot` (radians).
   */
  function stampMove(S, name, x, y, age, size, rot) {
    const L = S.L[name];
    const st = L.st.c.style;
    const ink = L.ink.c.style;
    if (age == null || age < -0.22) {
      if (st.opacity !== "0") st.opacity = L.op = "0";
      if (ink.opacity !== "0") ink.opacity = "0";
      L.on = false;
      burstDraw(S, name, x, y, null);
      return;
    }
    const base = size / STAMP;
    let sc;
    let sx = 1;
    let sy = 1;
    let op;
    let r;
    if (age < 0) {
      const u = (age + 0.22) / 0.22; // falling: big and faint → full size
      sc = 1.6 - 0.6 * u * u;
      op = u;
      r = rot - 0.35 * (1 - u);
    } else if (age < 0.09) {
      const u = age / 0.09; // impact: squash
      sc = 1;
      sx = 1 + 0.14 * Math.sin(u * Math.PI);
      sy = 1 - 0.16 * Math.sin(u * Math.PI);
      op = 1;
      r = rot;
    } else {
      const u = Math.min(1, (age - 0.09) / 0.35); // settle with a little wobble
      sc = 1 + 0.04 * Math.sin(u * Math.PI * 2) * (1 - u);
      op = 1 - 0.12 * u;
      r = rot + 0.05 * Math.sin(u * Math.PI * 3) * (1 - u);
    }
    const tx = `translate(${(x - STAMP / 2).toFixed(1)}px,${(y - STAMP / 2).toFixed(1)}px)`;
    const tf = `${tx} rotate(${r.toFixed(3)}rad) scale(${(base * sc * sx).toFixed(3)},${(base * sc * sy).toFixed(3)})`;
    const o = op.toFixed(3);
    if (L.tf !== tf) st.transform = L.tf = tf; // resting: no style writes at all
    if (L.op !== o) st.opacity = L.op = o;
    if (age >= 0 && age < 0.6) {
      const u = age / 0.6;
      ink.transform = `${tx} scale(${(base * (0.9 + 0.9 * u)).toFixed(3)})`;
      ink.opacity = (0.9 * (1 - u)).toFixed(3);
    } else if (ink.opacity !== "0") ink.opacity = "0";
    L.on = true;
    burstDraw(S, name, x, y, age, S.th.accent_hi || S.th.accent);
  }

  // ------------------------------------------------------------------------------------------------ the dolly
  // Roulette's win marker, as on a real table. The host picks its style (House settings → status.house.dolly); an
  // unseen dealer's hand lifts it from its rest beside the wheel, glides it over the layout, sets it down on the
  // winning number with a soft click and a firm felt shadow, and takes it home when the next round opens. Sprites
  // drawn once per style (the dolly, its shadow, the click ring), moved by transform / opacity only.
  const DOLLY_W = 100;
  const DOLLY_H = 168;
  const DOLLY_BASE = DOLLY_H - 26; // y of the base's resting point in the sprite
  const DOLLY_REST = [688, 262]; // where it waits between rounds: on the felt between the wheel and the layout
  const DOLLY_AFTER = 0.95; // s after the ball settles that the dolly lands (the result shows 1 s after the settle)
  /** The styles (casino/session.py DOLLIES): materials of the base, the collar and rings, the stem, the finial. */
  const DOLLY_STYLES = {
    classic_gold: { name: "Classic Gold", base: "gold", trim: "gold", stem: "gold", top: "ball:gold" },
    crystal: { name: "Crystal", crystal: true },
    chrome: { name: "Chrome", base: "chrome", trim: "chrome", stem: "chrome", top: "ball:chrome" },
    onyx_gold: { name: "Black Onyx & Gold", base: "onyx", trim: "gold", stem: "onyx", top: "ball:onyx" },
    rose_gold: { name: "Rose Gold", base: "rose", trim: "rose", stem: "rose", top: "ball:rose" },
    diamond: { name: "Diamond-cut", base: "gold", trim: "gold", stem: "gold", top: "gem" },
    marble_brass: { name: "Marble & Brass", base: "marble", trim: "brass", stem: "brass", top: "ball:brass" },
    neon: { name: "Neon Arcade", base: "neon", trim: "neonpink", stem: "neoncyan", top: "ball:neon" },
  }; // end DOLLY_STYLES
  const METALS = {
    gold: ["#5a3a08", "#c99232", "#fff3c4", "#e2b048", "#7a5210"],
    brass: ["#4a3208", "#b58a2c", "#f6e2a0", "#c99a3a", "#5e420e"],
    chrome: ["#3a3e48", "#a9afbd", "#ffffff", "#c6ccd8", "#4a4f5c"],
    rose: ["#6a3528", "#d98e74", "#ffe6da", "#e7a58c", "#7e4232"],
    onyx: ["#020203", "#1c1c22", "#6a6a78", "#25252c", "#050506"],
    marble: ["#a8a49a", "#ece8de", "#ffffff", "#e2ddd0", "#9c978b"],
    neon: ["#0a0614", "#1d1430", "#3a2a5a", "#1d1430", "#0a0614"],
    neonpink: ["#ff2fa0", "#ff7ad0", "#ffe0f4", "#ff7ad0", "#ff2fa0"],
    neoncyan: ["#18d8ff", "#7aefff", "#e6fdff", "#7aefff", "#18d8ff"],
  };
  /** A turned-metal gradient across [x0, x1]: dark edges, a bright highlight left of centre (the lamp). */
  function metal(g, mat, x0, x1) {
    const c = METALS[mat] || METALS.gold;
    const l = g.createLinearGradient(x0, 0, x1, 0);
    l.addColorStop(0, c[0]);
    l.addColorStop(0.22, c[1]);
    l.addColorStop(0.38, c[2]);
    l.addColorStop(0.62, c[3]);
    l.addColorStop(1, c[4]);
    return l;
  }
  function dollyLayers(S, root, name) {
    const k = wheelK();
    const sh = layer(root, 0, 0, DOLLY_W * 1.4, DOLLY_W * 0.5, k, true);
    const ring = layer(root, 0, 0, 120, 60, k, true);
    const d = layer(root, 0, 0, DOLLY_W, DOLLY_H, k, true);
    for (const l of [sh, ring, d]) {
      l.c.style.display = "none";
      l.cache = { display: "none" };
    }
    d.c.style.transformOrigin = `50% ${DOLLY_BASE}px`;
    S.L[name] = { d, sh, ring, painted: null };
  }
  /** Draw the dolly of `style` (once per style), its felt shadow and the click ring. */
  function dollyPaint(S, name, style) {
    const L = S.L[name];
    const id = DOLLY_STYLES[style] ? style : "classic_gold";
    if (L.painted === id) return;
    L.painted = id;
    const W = DOLLY_W;
    // the shadow on the felt: a soft pool and a tight contact core
    const sg = L.sh.g;
    const SWd = W * 1.4;
    const SHd = W * 0.5;
    sg.setTransform(L.sh.k, 0, 0, L.sh.k, 0, 0);
    sg.clearRect(0, 0, SWd, SHd);
    let sr = sg.createRadialGradient(SWd / 2, SHd / 2, 2, SWd / 2, SHd / 2, SWd / 2);
    sr.addColorStop(0, "rgba(0,0,0,0.55)");
    sr.addColorStop(0.55, "rgba(0,0,0,0.2)");
    sr.addColorStop(1, "rgba(0,0,0,0)");
    sg.fillStyle = sr;
    sg.beginPath();
    sg.ellipse(SWd / 2, SHd / 2, SWd / 2, SHd / 2, 0, 0, TAU);
    sg.fill();
    sr = sg.createRadialGradient(SWd / 2, SHd / 2, 1, SWd / 2, SHd / 2, 38);
    sr.addColorStop(0, "rgba(0,0,0,0.7)");
    sr.addColorStop(1, "rgba(0,0,0,0)");
    sg.fillStyle = sr;
    sg.beginPath();
    sg.ellipse(SWd / 2, SHd / 2, 38, 12, 0, 0, TAU);
    sg.fill();
    L.sh.show();
    // the click: a thin gold ring that opens on the felt
    const rg = L.ring.g;
    rg.setTransform(L.ring.k, 0, 0, L.ring.k, 0, 0);
    rg.clearRect(0, 0, 120, 60);
    rg.beginPath();
    rg.ellipse(60, 30, 52, 18, 0, 0, TAU);
    rg.lineWidth = 3;
    rg.strokeStyle = id === "neon" ? "#ff7ad0" : "rgba(255,236,180,.9)";
    rg.stroke();
    L.ring.show();
    const g = L.d.g;
    g.setTransform(L.d.k, 0, 0, L.d.k, 0, 0);
    g.clearRect(0, 0, W, DOLLY_H);
    dollyBody(g, id);
    L.d.show();
  }
  /** The dolly of style `id` itself, standing in a DOLLY_W × DOLLY_H box (its base's rest point at DOLLY_BASE). */
  function dollyBody(g, id) {
    const st = DOLLY_STYLES[id] || DOLLY_STYLES.classic_gold;
    const W = DOLLY_W;
    const cx = W / 2;
    const by = DOLLY_BASE;
    if (st.crystal) return crystalDolly(g, cx, by);
    const glow = (c, b) => {
      if (id === "neon") {
        g.shadowColor = c;
        g.shadowBlur = b;
      }
    };
    // the heavy round base, domed, seen from slightly above
    g.save();
    glow("#ff2fa0", 14);
    g.beginPath();
    g.ellipse(cx, by + 6, 36, 11, 0, 0, Math.PI);
    g.lineTo(cx - 36, by - 2);
    g.bezierCurveTo(cx - 34, by - 14, cx - 14, by - 20, cx, by - 20);
    g.bezierCurveTo(cx + 14, by - 20, cx + 34, by - 14, cx + 36, by - 2);
    g.closePath();
    g.fillStyle = metal(g, st.base, cx - 36, cx + 36);
    g.fill();
    g.restore();
    if (st.base === "marble") {
      // grey veins in the marble
      g.save();
      g.clip();
      g.strokeStyle = "rgba(90,86,80,.45)";
      g.lineWidth = 0.8;
      for (let i = 0; i < 4; i++) {
        g.beginPath();
        g.moveTo(cx - 36 + i * 9, by + 8);
        g.bezierCurveTo(cx - 20 + i * 12, by - 4, cx - 4 + i * 6, by - 2, cx + 10 + i * 8, by - 18);
        g.stroke();
      }
      g.restore();
    }
    // the base's lower bevel and a bead at the rim
    g.beginPath();
    g.ellipse(cx, by + 6, 36, 11, 0, 0, Math.PI);
    g.lineWidth = 2;
    g.strokeStyle = metal(g, st.trim, cx - 36, cx + 36);
    g.stroke();
    // the dome's light: a soft specular on the upper left
    const sp = g.createRadialGradient(cx - 14, by - 12, 1, cx - 14, by - 12, 18);
    sp.addColorStop(0, "rgba(255,255,255,.75)");
    sp.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = sp;
    g.beginPath();
    g.ellipse(cx - 12, by - 10, 16, 6, -0.2, 0, TAU);
    g.fill();
    // the round collar above the base
    const collar = (y, rx, ry, h) => {
      g.save();
      glow("#ff2fa0", 10);
      g.fillStyle = metal(g, st.trim, cx - rx, cx + rx);
      g.beginPath();
      g.ellipse(cx, y + h, rx, ry, 0, 0, Math.PI);
      g.lineTo(cx - rx, y);
      g.ellipse(cx, y, rx, ry, 0, Math.PI, 0, true);
      g.closePath();
      g.fill();
      g.restore();
      g.beginPath();
      g.ellipse(cx, y, rx, ry, 0, 0, TAU);
      g.fillStyle = (METALS[st.trim] || METALS.gold)[2];
      g.globalAlpha = 0.55;
      g.fill();
      g.globalAlpha = 1;
    };
    collar(by - 26, 15, 4.5, 6);
    // the slim turned stem, with two rings
    const top = st.top === "gem" ? by - 92 : by - 100;
    g.save();
    glow("#18d8ff", 12);
    g.beginPath();
    g.moveTo(cx - 5, by - 22);
    g.bezierCurveTo(cx - 3.2, by - 50, cx - 3.2, top + 20, cx - 4.2, top);
    g.lineTo(cx + 4.2, top);
    g.bezierCurveTo(cx + 3.2, top + 20, cx + 3.2, by - 50, cx + 5, by - 22);
    g.closePath();
    g.fillStyle = metal(g, st.stem, cx - 6, cx + 6);
    g.fill();
    g.restore();
    collar(by - 58, 8, 2.6, 4);
    collar(top + 2, 7, 2.2, 3);
    // a glint down the stem
    g.strokeStyle = "rgba(255,255,255,.7)";
    g.lineWidth = 1.2;
    g.beginPath();
    g.moveTo(cx - 2, by - 26);
    g.lineTo(cx - 1.6, top + 4);
    g.stroke();
    if (st.top === "gem") {
      // a brilliant-cut diamond: crown, table, pavilion, facets and a star of light
      const gy = top - 4;
      const gw = 22;
      g.save();
      g.beginPath();
      g.moveTo(cx - gw, gy - 10);
      g.lineTo(cx - gw * 0.55, gy - 22);
      g.lineTo(cx + gw * 0.55, gy - 22);
      g.lineTo(cx + gw, gy - 10);
      g.lineTo(cx, gy + 18);
      g.closePath();
      const dg = g.createLinearGradient(cx - gw, gy - 22, cx + gw, gy + 18);
      dg.addColorStop(0, "#ffffff");
      dg.addColorStop(0.3, "#cfeaff");
      dg.addColorStop(0.55, "#8fb8e8");
      dg.addColorStop(0.8, "#eaf6ff");
      dg.addColorStop(1, "#7aa0d8");
      g.fillStyle = dg;
      g.fill();
      g.strokeStyle = "rgba(255,255,255,.9)";
      g.lineWidth = 1;
      g.stroke();
      g.strokeStyle = "rgba(90,130,190,.55)";
      g.beginPath();
      g.moveTo(cx - gw, gy - 10);
      g.lineTo(cx + gw, gy - 10);
      for (const fx of [-0.55, -0.18, 0.18, 0.55]) {
        g.moveTo(cx + gw * fx, gy - 22);
        g.lineTo(cx + gw * fx * 0.6, gy - 10);
        g.lineTo(cx, gy + 18);
      }
      g.stroke();
      g.restore();
      g.fillStyle = "#ffffff";
      g.beginPath();
      const sx = cx - 8;
      const sy = gy - 16;
      g.moveTo(sx, sy - 9);
      g.lineTo(sx + 1.6, sy - 1.6);
      g.lineTo(sx + 9, sy);
      g.lineTo(sx + 1.6, sy + 1.6);
      g.lineTo(sx, sy + 9);
      g.lineTo(sx - 1.6, sy + 1.6);
      g.lineTo(sx - 9, sy);
      g.lineTo(sx - 1.6, sy - 1.6);
      g.closePath();
      g.fill();
    } else {
      // the ball finial, with a highlight and a little reflected light underneath
      const mat = st.top.split(":")[1];
      const by2 = top - 12;
      g.save();
      glow("#ff7ad0", 16);
      circle(g, cx, by2, 13);
      const c = METALS[mat] || METALS.gold;
      const bg = g.createRadialGradient(cx - 5, by2 - 5, 1, cx, by2, 14);
      bg.addColorStop(0, c[2]);
      bg.addColorStop(0.35, c[1]);
      bg.addColorStop(0.8, c[4]);
      bg.addColorStop(1, c[0]);
      g.fillStyle = bg;
      g.fill();
      g.restore();
      circle(g, cx - 4.5, by2 - 5, 3.2);
      g.fillStyle = "rgba(255,255,255,.9)";
      g.fill();
      g.beginPath();
      g.ellipse(cx + 2, by2 + 8, 7, 2.4, 0, 0, TAU);
      g.fillStyle = "rgba(255,255,255,.18)";
      g.fill();
    }
  }
  /** The crystal pawn on a gold base (the original dolly). */
  function crystalDolly(g, cx, baseY0) {
    const baseY = baseY0 - 8;
    const gold = () => metal(g, "gold", cx - 28, cx + 28);
    g.fillStyle = gold();
    g.beginPath();
    g.ellipse(cx, baseY + 10, 28, 9, 0, 0, Math.PI);
    g.lineTo(cx - 28, baseY);
    g.ellipse(cx, baseY, 28, 9, 0, Math.PI, 0, true);
    g.closePath();
    g.fill();
    g.fillStyle = "#f3d27a";
    g.beginPath();
    g.ellipse(cx, baseY, 28, 9, 0, 0, TAU);
    g.fill();
    g.strokeStyle = "rgba(90,60,10,0.6)";
    g.lineWidth = 1.2;
    g.stroke();
    const glass = g.createLinearGradient(cx - 20, 0, cx + 20, 0);
    glass.addColorStop(0, "rgba(255,255,255,0.55)");
    glass.addColorStop(0.22, "rgba(210,232,255,0.16)");
    glass.addColorStop(0.55, "rgba(190,215,245,0.10)");
    glass.addColorStop(0.8, "rgba(255,255,255,0.32)");
    glass.addColorStop(1, "rgba(150,180,220,0.35)");
    g.fillStyle = glass;
    g.beginPath();
    g.moveTo(cx - 20, baseY + 1);
    g.bezierCurveTo(cx - 20, baseY - 18, cx - 9, baseY - 30, cx - 8, baseY - 52);
    g.bezierCurveTo(cx - 7, baseY - 64, cx - 15, baseY - 70, cx - 15, baseY - 78);
    g.lineTo(cx + 15, baseY - 78);
    g.bezierCurveTo(cx + 15, baseY - 70, cx + 7, baseY - 64, cx + 8, baseY - 52);
    g.bezierCurveTo(cx + 9, baseY - 30, cx + 20, baseY - 18, cx + 20, baseY + 1);
    g.closePath();
    g.fill();
    g.strokeStyle = "rgba(255,255,255,0.75)";
    g.lineWidth = 1.6;
    g.stroke();
    g.fillStyle = gold();
    g.beginPath();
    g.ellipse(cx, baseY - 78, 17, 5, 0, 0, TAU);
    g.fill();
    const head = g.createRadialGradient(cx - 6, baseY - 100, 2, cx, baseY - 94, 18);
    head.addColorStop(0, "rgba(255,255,255,0.95)");
    head.addColorStop(0.35, "rgba(220,236,255,0.45)");
    head.addColorStop(1, "rgba(160,190,230,0.30)");
    g.fillStyle = head;
    g.beginPath();
    g.arc(cx, baseY - 94, 16, 0, TAU);
    g.fill();
    g.strokeStyle = "rgba(255,255,255,0.8)";
    g.stroke();
    g.strokeStyle = "rgba(255,255,255,0.85)";
    g.lineWidth = 2.4;
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(cx - 15, baseY - 8);
    g.quadraticCurveTo(cx - 6, baseY - 30, cx - 4, baseY - 58);
    g.stroke();
  }
  /**
   * The dealer's hand, as a pure function of `age` (s since the dolly touches down; < 0 before): it rests at `from`,
   * is lifted (−1.0 … −0.8 s), glides in an arc to `to` (−0.8 … −0.2 s), is set down (−0.2 … 0 s) and settles with a
   * tiny squash (0 … 0.18 s). Returns {x, y, lift (px above the felt), sy (squash)}; tested in tv_casino.test.mjs.
   */
  function dollyPath(from, to, age) {
    if (age == null || age <= -1.0) return { x: from[0], y: from[1], lift: 0, sy: 1 };
    if (age < -0.8) {
      const u = (age + 1.0) / 0.2;
      return { x: from[0], y: from[1], lift: 42 * easeOut(u), sy: 1 };
    }
    if (age < -0.2) {
      const u = easeInOut((age + 0.8) / 0.6);
      return { x: lerp(from[0], to[0], u), y: lerp(from[1], to[1], u), lift: 42 + 26 * Math.sin(u * Math.PI), sy: 1 };
    }
    if (age < 0) {
      const u = (age + 0.2) / 0.2;
      return { x: to[0], y: to[1], lift: 42 * (1 - u * u), sy: 1 };
    }
    return { x: to[0], y: to[1], lift: 0, sy: age < 0.18 ? 1 - 0.04 * Math.sin((age / 0.18) * Math.PI) : 1 };
  }
  /** Place the dolly (base on (x, y), `lift` px above the felt) and its shadow; the click ring `clickAge` s after it lands. */
  function dollyMove(S, name, p, clickAge) {
    const L = S.L[name];
    if (!p) {
      for (const l of [L.d, L.sh, L.ring]) hideLayer(l);
      return;
    }
    const sc = 1 + p.lift / 420; // nearer the camera while it's up
    moveLayer(L.d, `translate(${(p.x - DOLLY_W / 2).toFixed(1)}px,${(p.y - DOLLY_BASE - p.lift).toFixed(1)}px) scale(${sc.toFixed(3)},${(sc * p.sy).toFixed(3)})`, "1");
    const near = 1 - clamp(p.lift / 70, 0, 1);
    moveLayer(L.sh, `translate(${(p.x - DOLLY_W * 0.7 + p.lift * 0.35).toFixed(1)}px,${(p.y - DOLLY_W * 0.25 + 4 + p.lift * 0.2).toFixed(1)}px) scale(${(0.75 + 0.25 * near).toFixed(3)})`, (0.35 + 0.65 * near).toFixed(3));
    if (clickAge != null && clickAge >= 0 && clickAge < 0.45) {
      const u = clickAge / 0.45;
      moveLayer(L.ring, `translate(${(p.x - 60).toFixed(1)}px,${(p.y - 30).toFixed(1)}px) scale(${(0.4 + 1.1 * easeOut(u)).toFixed(3)})`, (0.9 * (1 - u)).toFixed(3));
    } else hideLayer(L.ring);
  }

  /** Device px per stage px for the table's canvases: the stage's own (≤ 1.5), in both tiers. */
  const tableK = () => clamp(num(TV && TV.pixelRatio, 1), 1, 1.5);

  function makeScene(def) {
    let S = null;
    const scene = {
      id: def.id,
      match: (app) => app === def.app,
      mount(root, ctx) {
        const k = tableK();
        root.style.position = "absolute";
        S = {
          def, root, k, ctx, st: {}, th: Object.assign({}, CLASSIC), clk: new PhaseTracker(), players: [],
          bySeat: new Map(), chipT: new Map(), chipAmt: new Map(), seen: new Map(), fx: {}, L: {}, bg: null,
          round: undefined, firstIngest: true, alive: true, raf: 0, t: 0, T: 0, err: null, sclk: {}, ver: 0,
          sig: "", lastKey: "", railKey: "", animUntil: 0,
        }; // fmt: skip
        S.bgl = layer(root, 0, 0, SW, SH, k, false); // felt, printed layout, rail frame: redrawn on theme / layout
        // the theme's felt motif (css.pattern: CSS gradients) as a static DOM layer clipped to the felt
        S.pat = document.createElement("div");
        Object.assign(S.pat.style, { position: "absolute", left: "0px", top: "0px", width: `${RAIL_X}px`, height: `${SH}px`, pointerEvents: "none" });
        root.appendChild(S.pat);
        if (def.layers) def.layers(S, root); // the moving parts: wheels, balls, dice, reels (transforms only)
        S.top = layer(root, 0, 0, SW, SH, k, false); // chips, cards, text: redrawn only when they change
        S.g = S.top.g;
        if (def.overlays) def.overlays(S, root); // stamps: above the chips, transforms only
        S.rail = layer(root, RAIL_X, 0, RAIL_W, SH, k, false);
        // the seats' credit odometers (DOM reels over the rail)
        S.odoBox = document.createElement("div");
        Object.assign(S.odoBox.style, { position: "absolute", left: "0px", top: "0px", width: "0px", height: "0px", pointerEvents: "none" });
        root.appendChild(S.odoBox);
        S.odos = new Map();
        const pcv = document.createElement("canvas");
        pcv.style.position = "absolute";
        pcv.style.left = `${PANEL_X}px`;
        pcv.style.top = `${PANEL_Y}px`;
        pcv.style.width = `${PANEL_SIZE}px`;
        pcv.style.height = `${PANEL_SIZE}px`;
        pcv.style.borderRadius = "6px";
        pcv.style.display = "none"; // shown with the first panel frame (a DeskDot without a panel has none)
        root.appendChild(pcv);
        S.pcv = pcv;
        S.fxBox = document.createElement("div"); // chips in flight during the moment
        Object.assign(S.fxBox.style, { position: "absolute", left: "0px", top: "0px", width: "0px", height: "0px", pointerEvents: "none" });
        root.appendChild(S.fxBox);
        momentLayers(S, root); // the win / lose moment: above everything on the table and the rail
        if (def.init) def.init(S);
        S.mountT = nowOf(ctx);
        ingest(S, ctx);
        const me = S;
        const step = () => {
          if (!S || !S.alive || S !== me) return false;
          if (!(typeof document !== "undefined" && document.hidden)) {
            try {
              paint(S, nowOf(S.ctx));
            } catch (e) {
              if (!S.err) console.error("DeskDot TV casino scene:", def.id, e);
              S.err = e;
            }
          }
          return true;
        };
        if (TV && typeof TV.every === "function") S.stop = TV.every(step); // the page's one animation loop (tv.js)
        else {
          const raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : (f) => setTimeout(() => f(), 16);
          const loop = () => {
            if (step() !== false) S.raf = raf(loop);
          };
          S.raf = raf(loop);
        }
      },
      update(ctx) {
        if (S) ingest(S, ctx);
      },
      /** The TV's theme or its font changed: redraw the cached layers once, now (tv.js restyle, inside its fade). */
      restyle(ctx) {
        if (!S) return;
        if (ctx) S.ctx = ctx;
        P = roomOf();
        glowCache.clear(); // text glows are keyed by the font string, which didn't change
        bgWanted(S);
        S.lastKey = S.railKey = "";
        for (const o of S.odos.values()) o.restyle();
        try {
          paint(S, nowOf(S.ctx));
        } catch (e) {
          console.error("DeskDot TV casino scene:", def.id, e);
        }
      },
      frame(ctx) {
        if (!S) return;
        S.ctx = ctx;
        if (!S.hasPanel && ctx.panel) {
          // a panel is connected: its live inset takes the bottom of the rail
          S.hasPanel = true;
          S.pcv.style.display = "";
          S.railKey = "";
        }
        if (typeof ctx.drawPanel === "function") ctx.drawPanel(S.pcv, { pitch: PANEL_PITCH, glow: 0.55, round: true });
      },
      resize(ctx) {
        if (!S) return;
        const k = tableK();
        if (Math.abs(k - S.k) < 1e-3) return;
        S.k = k;
        for (const l of [S.bgl, S.top, S.rail]) l.size(k);
        S.bg = null;
        bgWanted(S);
        S.lastKey = S.railKey = "";
        if (S.hud) for (const h of S.hud.values()) h.k = -1; // re-made at the new resolution on the next redraw
        cardCache.clear();
        chipCache.clear();
        if (ctx && ctx.panel) scene.frame(ctx);
      },
      unmount() {
        if (!S) return;
        S.alive = false;
        if (S.root && S.root.style) S.root.style.transform = "";
        if (S.stop) S.stop();
        if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(S.raf);
        S = null;
      },
      // tests
      _state: () => S,
      _paint: (t) => S && paint(S, t),
    };
    return scene;
  }

  function bgWanted(S) {
    const room = roomOf() === ROOMS.light ? "light" : "dark";
    S.bgWant = `${JSON.stringify(S.th)}|${S.k}|${room}|${TV && TV.fontReady ? 1 : 0}|${S.def.bgKey ? S.def.bgKey(S) : ""}`;
  }
  function background(S) {
    if (S.bg === S.bgWant) return; // the key is built on each state (ingest), never per frame
    S.bg = S.bgWant;
    const g = S.bgl.g;
    g.setTransform(S.k, 0, 0, S.k, 0, 0);
    g.clearRect(0, 0, SW, SH);
    const th = S.th;
    const gr = g.createLinearGradient(0, 0, 0, SH);
    const wall = P.wall || [th.wing, th.wing2, th.wing3]; // the night salon takes the table theme's wing tones
    gr.addColorStop(0, wall[0]);
    gr.addColorStop(0.6, wall[1]);
    gr.addColorStop(1, wall[2]);
    g.fillStyle = gr;
    g.fillRect(0, 0, SW, SH);
    if (P.light) {
      // daylight: a soft rose and gold-leaf bloom in the corners (MATERIALS v2 --m-wash-a / -b)
      for (const [x, y, c] of [[0, 0, "rgba(214,56,106,.07)"], [SW, SH, "rgba(184,137,42,.12)"]]) {
        const w = g.createRadialGradient(x, y, 0, x, y, 900);
        w.addColorStop(0, c);
        w.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = w;
        g.fillRect(0, 0, SW, SH);
      }
    }
    // the salon: a damask wall behind the table, darker toward the corners
    damask(g, th, 0, 0, SW, SH);
    const vg = g.createRadialGradient(760, 470, 200, 760, 470, 1150);
    vg.addColorStop(0, P.sheen);
    vg.addColorStop(1, P.vignette);
    g.fillStyle = vg;
    g.fillRect(0, 0, SW, SH);
    S.def.bg(S, g);
    // the overhead lamp: a warm pool on the felt, the room falling off into shadow (a vignette), once
    const sp = g.createRadialGradient(760, 400, 40, 760, 480, 1020);
    sp.addColorStop(0, "rgba(255,236,200,.075)");
    sp.addColorStop(0.42, "rgba(255,236,200,0)");
    sp.addColorStop(0.78, P.lampMid);
    sp.addColorStop(1, P.lampFar);
    g.fillStyle = sp;
    g.fillRect(0, 0, RAIL_X, SH);
    railBackground(S, g);
    S.bgl.show();
    const ps = S.pat.style;
    ps.backgroundImage = th.pattern || "none";
    ps.backgroundSize = th.pattern_size || "auto";
    ps.clipPath = S.def.feltClip ? S.def.feltClip(S) : "inset(18px 16px 18px 18px round 60px)"; // rr(18, 18, RAIL_X - 34, SH - 36, 60)
    if (S.def.layersRedraw) S.def.layersRedraw(S);
  }

  /**
   * One animation frame. The moving parts only get new transforms (def.move — compositor work, no repaint); the
   * table layer is redrawn only when something on it changed (the status signature, a tick of a countdown, a chip
   * or card still in flight), so a spinning wheel holds 60 fps on a TV stick.
   */
  function paint(S, t) {
    S.t = t;
    CHIPSET = S.chipSet || "clay";
    P = roomOf();
    S.T = serverClock(S, t);
    background(S);
    if (S.def.move) S.def.move(S, t);
    // how often the table layer redraws: 30 Hz while chips drop / cards fly, else the scene's own slow rate
    // (countdown rings sweep in their own small canvases — hudRing — so betting needs ~1 Hz), default 4
    const hz = t < S.animUntil ? 30 : S.def.slowHz ? S.def.slowHz(S, t) : 4;
    const tick = hz > 0 ? Math.floor(t * hz) : 0;
    const ma = momentAge(S);
    const key = `${S.ver}|${S.def.key ? S.def.key(S, t) : ""}|${hz}|${tick}|${S.k}|${ma == null ? "" : ma < 0 ? "-" : "m"}`;
    if (key !== S.lastKey) {
      S.lastKey = key;
      S.drawGen = (S.drawGen || 0) + 1;
      const g = S.g;
      g.setTransform(S.k, 0, 0, S.k, 0, 0);
      g.globalAlpha = 1;
      g.globalCompositeOperation = "source-over";
      g.clearRect(0, 0, SW, SH);
      S.flights = new Map();
      S.def.draw(S, g, t);
      if (S.st.paused) paused(S, g, t);
      if (S.preview) previewNote(S, g);
      S.top.show();
    }
    hudFrame(S, t);
    if (S.def.fx) S.def.fx(S, t);
    const shake = momentFrame(S, t);
    flightsFrame(S);
    rootFx(S, shake);
    const turn = S.def.turnSeat ? S.def.turnSeat(S) : null;
    const rk = `${S.ver}|${turn}|${S.k}|${S.hasPanel ? 1 : 0}|${P.light ? 1 : 0}`;
    if (rk !== S.railKey) {
      S.railKey = rk;
      const g = S.rail.g;
      g.setTransform(S.k, 0, 0, S.k, -RAIL_X * S.k, 0);
      g.clearRect(RAIL_X, 0, RAIL_W, SH);
      drawRail(S, g, t);
      S.rail.show();
    }
    odoFrame(S, t);
  }

  /**
   * The scene root's transform: a scene's camera (S.cam = {s, x, y}: zoom `s` about stage point (x, y), e.g. the
   * roulette push-in on the winning pocket) plus the moment's shake. One style write, only when it changes.
   */
  function rootFx(S, shake) {
    const c = S.cam;
    let tf = "";
    if ((c && c.s !== 1) || shake) {
      const s = c ? c.s : 1;
      const tx = (c ? c.x * (1 - s) : 0) + (shake ? shake[0] : 0);
      const ty = (c ? c.y * (1 - s) : 0) + (shake ? shake[1] : 0);
      tf = `translate(${tx.toFixed(1)}px,${ty.toFixed(1)}px) scale(${s.toFixed(4)})`;
    }
    if (tf !== S.rootTf && S.root && S.root.style) {
      S.rootTf = tf;
      S.root.style.transformOrigin = "0 0";
      S.root.style.transform = tf;
    }
  }

  function paused(S, g) {
    g.save();
    g.fillStyle = "rgba(0,0,0,.5)";
    g.fillRect(0, 0, RAIL_X, SH);
    g.restore();
    rr(g, 470, 420, 600, 140, 30);
    g.fillStyle = "rgba(12,12,16,.92)";
    g.fill();
    g.lineWidth = 3;
    g.strokeStyle = S.th.accent;
    g.stroke();
    txt(g, "PAUSED", 770, 500, 72, S.th.accent, { align: "center", weight: 800 });
    txt(g, "The host paused the table", 770, 540, 26, INK2, { align: "center", weight: 600 });
  }

  function previewNote(S, g) {
    pill(g, "STUDIO PREVIEW — the live table shows when the panel's view is “Live table”", 770, 950, 22, "rgba(0,0,0,.7)", INK1, { align: "center", stroke: rgba(S.th.accent, 0.5) });
  }

  // ------------------------------------------------------------------------------------------------ the rail
  function railBackground(S, g) {
    const th = S.th;
    const x = RAIL_X + 2;
    const y = 14;
    const w = RAIL_W - 18;
    const h = SH - 28;
    // a leather-lined gallery in a gold frame (night) / an ivory-lacquered one with gold hairlines (daylight)
    const gold = P.light ? "#b8892a" : th.accent;
    g.save();
    rr(g, x, y, w, h, 24);
    softStroke(g, 0, 30, P.railShadow[0], P.galleryShadow, 0, 12, 5);
    const lg = g.createLinearGradient(0, y, 0, y + h);
    lg.addColorStop(0, P.gallery[0]);
    lg.addColorStop(1, P.gallery[1]);
    g.fillStyle = lg;
    g.fill();
    g.restore();
    rr(g, x, y, w, h, 24);
    if (!P.light) {
      g.fillStyle = grain(g);
      g.fill();
    }
    g.lineWidth = 2;
    g.strokeStyle = rgba(gold, P.frame);
    g.stroke();
    rr(g, x + 7, y + 7, w - 14, h - 14, 18);
    g.lineWidth = 1;
    g.strokeStyle = rgba(gold, P.frameIn);
    g.stroke();
    txt(g, "AT THE TABLE", x + 22, 58, 24, gold, { weight: 700, font: "serif", gold: goldOn(), spacing: 3, shadow: !P.light });
    const rl = g.createLinearGradient(x + 20, 0, x + w - 20, 0);
    rl.addColorStop(0, rgba(gold, 0));
    rl.addColorStop(0.5, rgba(gold, 0.6));
    rl.addColorStop(1, rgba(gold, 0));
    g.fillStyle = rl;
    g.fillRect(x + 20, 68, w - 40, 1.5);
  }
  /** The gallery's labels and the panel's housing (the rail layer: they move when a panel appears). */
  function railFixtures(S, g) {
    const th = S.th;
    const x = RAIL_X + 2;
    const L = railLayout(S);
    const lbl = P.light ? rgba("#8a6412", P.label) : rgba(th.accent_hi || th.accent, P.label);
    txt(g, "CHIPS", x + 22, L.rackY - 30, 16, lbl, { weight: 800, shadow: false, spacing: 3 });
    txt(g, "RECENT", x + 22, L.recentY - 8, 16, lbl, { weight: 800, shadow: false, spacing: 3 });
    if (!L.panel) return;
    // the panel's housing (only while panel frames arrive): gunmetal at night, champagne lacquer in daylight — the
    // panel sits in a dark well at night and a porcelain one in daylight (tv.js draws it as the paper panel then)
    rr(g, PANEL_X - 14, PANEL_Y - 14, PANEL_SIZE + 28, PANEL_SIZE + 28, 16);
    if (P.light) softStroke(g, 0, 18, P.railShadow[0], 0.22, 0, 8, 4);
    const bz = g.createLinearGradient(0, PANEL_Y - 14, 0, PANEL_Y + PANEL_SIZE + 14);
    bz.addColorStop(0, P.housing[0]);
    bz.addColorStop(1, P.housing[1]);
    g.fillStyle = bz;
    g.fill();
    g.lineWidth = 1.5;
    g.strokeStyle = P.light ? "rgba(184,137,42,.7)" : rgba(th.accent, 0.35);
    g.stroke();
    rr(g, PANEL_X - 3, PANEL_Y - 3, PANEL_SIZE + 6, PANEL_SIZE + 6, 6);
    g.fillStyle = P.light ? "#ebe6dc" : "#030304";
    g.fill();
  }

  function railInfoDefault(S, p) {
    const st = S.st;
    const ph = st.phase;
    if (ph === "result") {
      const w = winners(S).find((x) => String(x.seat) === String(p.seat));
      if (w) return { text: `WON ${signed(S, num(w.net))}`, color: P.light ? "#18794e" : OK };
    }
    let on = 0;
    for (const list of Object.values(obj(st.spot_bets))) for (const e of arr(list)) if (String(e.seat) === String(p.seat)) on += num(e.amount);
    if (on > 0) {
      const done = arr(st.done).some((s) => String(s) === String(p.seat));
      return { text: `${done ? "READY · " : ""}BET ${fmt(S, on)}`, color: done ? (P.light ? "#18794e" : OK) : P.light ? "#8a6412" : S.th.accent_hi };
    }
    return { text: p.online ? "" : "AWAY", color: P.ink3 };
  }

  function drawRail(S, g, t) {
    const th = S.th;
    const list = S.players;
    const turn = S.def.turnSeat ? S.def.turnSeat(S) : null;
    const L = railLayout(S);
    railFixtures(S, g);
    txt(g, `${list.length}`, RAIL_X + RAIL_W - 34, 58, 22, P.light ? "#8a6412" : rgba(th.accent_hi || th.accent, 0.7), { align: "right", weight: 800, shadow: false });
    if (!list.length) {
      txt(g, "Nobody yet — scan the code", RAIL_X + 24, 112, 24, P.ink3, { weight: 600, shadow: !P.light });
      txt(g, "at the top to take a seat", RAIL_X + 24, 144, 24, P.ink3, { weight: 600, shadow: !P.light });
    }
    const bets = onTable(S);
    const shown = new Set();
    for (let i = 0; i < L.rows; i++) {
      const p = list[i];
      const r = railSeat(S, p.seat);
      const hot = turn != null && String(turn) === String(p.seat);
      const alpha = p.online ? 1 : 0.45;
      const info = Object.assign({}, (S.def.railInfo || railInfoDefault)(S, p) || {});
      if (!info.text && num(p.net) !== 0) Object.assign(info, { text: `SESSION ${signed(S, num(p.net))}`, color: num(p.net) > 0 ? (P.light ? "#18794e" : rgba(OK, 0.8)) : P.ink3 });
      plaque(S, g, r, p, { hot, alpha, info, bet: S.st.phase === "result" ? 0 : bets.get(String(p.seat)) || 0 });
      shown.add(String(p.seat));
      // the credits: an odometer (DOM reels over the plaque, moved by transforms)
      odoFor(S, p, r.x + r.w - 14, r.y + 8, alpha);
    }
    for (const [seat, o] of S.odos)
      if (!shown.has(seat)) {
        o.remove();
        S.odos.delete(seat);
      }
    if (list.length > L.rows) txt(g, `+ ${list.length - L.rows} more`, RAIL_X + RAIL_W - 34, L.rackY - 30, 16, P.ink3, { align: "right", weight: 700, shadow: false });
    // the table's chip rack (status.chips: only what the limits allow — 1K, 5K… at a high-roller table)
    const rack = arr(S.rack);
    const cr = rack.length > 6 ? 17 : 19;
    const step = Math.min(2 * cr + 8, (RAIL_W - 60) / Math.max(1, rack.length));
    rack.forEach((c, i) => chip(g, RAIL_X + 24 + cr + i * step, L.rackY, cr, c.color, c.label, { edge: c.edge }));
    // the recent results strip
    const hist = arr(S.st.history).filter((h) => h && (!S.st.game || h.game === S.st.game)).slice(-7).reverse();
    let x = RAIL_X + 24;
    const y = L.recentY;
    hist.forEach((h, i) => {
      const lbl = String(h.label == null ? "?" : h.label);
      const w = Math.max(40, measure(g, lbl, 22, { font: "mono" }) + 18);
      if (x + w > RAIL_X + RAIL_W - 24) return;
      rr(g, x, y + 6, w, 40, 10);
      const hg = g.createLinearGradient(0, y + 6, 0, y + 46);
      hg.addColorStop(0, shade(TONE[h.tone] || TONE.white, 1.25));
      hg.addColorStop(1, shade(TONE[h.tone] || TONE.white, 0.8));
      g.fillStyle = hg;
      g.fill();
      g.lineWidth = i === 0 ? 3 : 1;
      g.strokeStyle = i === 0 ? (P.light ? "#b8892a" : th.accent) : P.histLine;
      g.stroke();
      txt(g, lbl, x + w / 2, y + 34, 22, "#fff", { align: "center", font: "mono", weight: 800, alpha: i === 0 ? 1 : 0.8 });
      x += w + 8;
    });
    if (!hist.length) txt(g, "No rounds yet", RAIL_X + 24, y + 34, 20, P.ink3, { weight: 600, shadow: !P.light });
  }
  /** The seat's credits odometer: created on first use, moved with its plaque. */
  function odoFor(S, p, x, y, alpha) {
    const key = String(p.seat);
    let o = S.odos.get(key);
    if (!o) {
      o = new Odo(S.odoBox, { x, y, size: 30, color: P.odo.ink, align: "right", room: true });
      S.odos.set(key, o);
    }
    o.place(x, y);
    const op = String(alpha);
    if (o.el.style.opacity !== op) o.el.style.opacity = op;
    o.credits = num(p.credits);
  }
  /** Every frame: roll the odometers toward their seat's credits (held while that seat's moment plays). */
  function odoFrame(S, t) {
    if (!S.odos) return;
    for (const [seat, o] of S.odos) {
      if (!creditsHeld(S, seat)) {
        const text = fmt(S, o.credits);
        if (text !== o.text) {
          const was = o.value;
          o.value = o.credits;
          o.color(was == null || o.credits === was ? P.odo.ink : o.credits > was ? P.odo.up : P.odo.down);
          o.set(text, t, was == null || o.credits >= was, was == null);
          o.settleAt = t + 1.6;
        }
      }
      o.frame(t);
      if (o.settleAt && t > o.settleAt) {
        o.settleAt = 0;
        o.color(P.odo.ink);
      }
    }
  }

  // ================================================================================================ odometer credits
  /**
   * Credits as a slot-machine counter (docs/TV_VIEW.md §7): every digit is a reel — a DOM column 0…9,0 in a clipped
   * window, moved by transform only — that spins to its new digit with a little overshoot when the value changes,
   * lower digits spinning a turn further (they "count" more), the reels stopping left to right. A second, smeared
   * column fades in while a reel turns fast (motion blur without a blur filter). Separators and K / M stay put. The
   * shown text is whatever fmt / shortChip gives; a change of shape (999 → 1,000) rebuilds the cells, right-aligned.
   */
  const ODO_DIGITS = "0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0";
  const easeOutBack = (u) => {
    u = clamp(u, 0, 1);
    const c = 1.9;
    return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2);
  };
  /** The reel position (digit units, 0 … 10) `u` of the way from digit `a` to `b` with `turns` extra turns. */
  function odoPos(a, b, turns, up, u) {
    const d = up ? mod(b - a, 10) + 10 * turns : -(mod(a - b, 10) + 10 * turns);
    return mod(a + d * easeOutBack(u), 10);
  }
  class Odo {
    constructor(parent, o) {
      this.o = o;
      const el = document.createElement("div");
      const s = el.style;
      s.position = "absolute";
      s.left = `${o.x}px`;
      s.top = `${o.y}px`;
      s.height = `${o.size}px`;
      s.font = `${o.weight || 700} ${o.size * 0.86}px ${o.font === "serif" ? SERIF : MONO}`;
      s.lineHeight = `${o.size}px`;
      s.color = o.color || INK1;
      s.whiteSpace = "nowrap";
      s.pointerEvents = "none";
      s.display = "flex";
      s.transform = o.align === "right" ? "translateX(-100%)" : o.align === "center" ? "translateX(-50%)" : "";
      s.textShadow = o.room ? P.odo.shadow : "0 2px 0 rgba(0,0,0,.55)";
      if (o.letterSpacing) s.letterSpacing = o.letterSpacing;
      parent.appendChild(el);
      this.el = el;
      this.cells = [];
      this.text = null;
      this.anim = null;
    }
    /** The TV's theme changed: the room's ink (an odometer on a seat plaque). */
    restyle() {
      if (!this.o.room) return;
      this.el.style.textShadow = P.odo.shadow;
      this.color(P.odo.ink);
      const text = this.text;
      if (text != null) {
        this.text = null; // rebuilt (the smeared copy's shade follows the room), shown at once
        this.set(text, 0, true, true);
      }
    }
    place(x, y) {
      if (x === this.o.x && y === this.o.y) return;
      this.o.x = x;
      this.o.y = y;
      this.el.style.left = `${x}px`;
      this.el.style.top = `${y}px`;
    }
    color(c) {
      if (c !== this.o.color) this.el.style.color = this.o.color = c;
    }
    /** Show `text` (rolling to it from the shown one unless `instant`); `up` = the value rose. */
    set(text, t, up, instant) {
      text = String(text);
      if (text === this.text) return;
      const old = this.text;
      this.text = text;
      const same = old != null && old.length === text.length && old.replace(/\d/g, "0") === text.replace(/\d/g, "0");
      if (!same) this.build(text, old);
      const n = text.length;
      if (instant || old == null || reducedMotion()) {
        this.cells.forEach((c, i) => c && c.reel && this.show(c, +text[i]));
        this.anim = null;
        return;
      }
      const from = this.cells.map((c) => (c && c.reel ? c.at : 0));
      let k = 0;
      this.anim = {
        t0: t,
        up: !!up,
        cells: this.cells.map((c, i) => {
          if (!c || !c.reel) return null;
          const b = +text[i];
          const a = Math.round(from[i]) % 10;
          const digitsRight = text.slice(i + 1).replace(/\D/g, "").length;
          const changed = a !== b || !same;
          const order = k++;
          return changed ? { a, b, turns: digitsRight === 0 ? 2 : digitsRight === 1 ? 1 : 0, dur: 0.55 + 0.09 * order } : null;
        }),
      };
      void n;
    }
    build(text, old) {
      this.el.textContent = "";
      const prev = this.cells;
      this.cells = [];
      const n = text.length;
      for (let i = 0; i < n; i++) {
        const ch = text[i];
        if (!/\d/.test(ch)) {
          const sp = document.createElement("span");
          sp.textContent = ch;
          this.el.appendChild(sp);
          this.cells.push({ reel: false });
          continue;
        }
        const win = document.createElement("span");
        const ws = win.style;
        ws.position = "relative";
        ws.display = "inline-block";
        ws.overflow = "hidden";
        ws.width = "0.62em";
        ws.height = `${this.o.size}px`;
        ws.textAlign = "center";
        const col = document.createElement("span");
        const blur = document.createElement("span");
        for (const [c, smear] of [[col, false], [blur, true]]) {
          const cs = c.style;
          cs.position = "absolute";
          cs.left = "0";
          cs.right = "0";
          cs.top = "0";
          cs.whiteSpace = "pre";
          c.textContent = ODO_DIGITS;
          if (smear) {
            cs.opacity = "0";
            const sm = this.o.room && P.light ? "rgba(28,26,34,.22)" : "rgba(255,255,255,.28)";
            cs.textShadow = `0 ${-this.o.size * 0.22}px 0 ${sm}, 0 ${this.o.size * 0.22}px 0 ${sm}`;
          }
          win.appendChild(c);
        }
        this.el.appendChild(win);
        // right-aligned: the old digit in the same place from the right, so a growing number keeps its reels
        const j = (old || "").length - (n - i);
        const was = j >= 0 && prev[j] && prev[j].reel ? prev[j].at : 0;
        const cell = { reel: true, col, blur, at: was, y: null, bo: null };
        this.cells.push(cell);
        this.show(cell, was);
      }
    }
    show(c, pos, speed) {
      c.at = pos;
      const y = -(pos * this.o.size);
      const ty = `translateY(${y.toFixed(1)}px)`;
      if (ty !== c.y) {
        c.y = ty;
        c.col.style.transform = ty;
        c.blur.style.transform = ty;
      }
      const bo = clamp(((speed || 0) - 6) / 14, 0, 0.9).toFixed(2);
      if (bo !== c.bo) {
        c.bo = bo;
        c.blur.style.opacity = bo;
        c.col.style.opacity = (1 - 0.5 * +bo).toFixed(2);
      }
    }
    /** Advance the roll; true while it moves. */
    frame(t) {
      const A = this.anim;
      if (!A) return false;
      let moving = false;
      A.cells.forEach((c, i) => {
        const cell = this.cells[i];
        if (!c || !cell) return;
        const u = clamp((t - A.t0) / c.dur, 0, 1);
        const p = odoPos(c.a, c.b, c.turns, A.up, u);
        const u2 = clamp((t - A.t0 + 1 / 60) / c.dur, 0, 1);
        const sp = Math.abs(wrapPi(((odoPos(c.a, c.b, c.turns, A.up, u2) - p) / 10) * TAU)) * (10 / TAU) * 60;
        this.show(cell, u >= 1 ? c.b : p, u >= 1 ? 0 : sp);
        if (u < 1) moving = true;
      });
      if (!moving) this.anim = null;
      return moving;
    }
    remove() {
      if (this.el.remove) this.el.remove();
    }
  }
  const reducedMotion = () => {
    try {
      return typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch (e) {
      return false;
    }
  };

  // ================================================================================================ the seat gallery
  /**
   * The seats, as leather plaques down the right of the table: avatar in a gold bezel, name in the player's colour,
   * credits on an odometer, a live chip stack of what they have on the table, a status line. The panel's inset sits
   * below them only once panel frames arrive (a DeskDot without a panel — a hosting device — gives the seats the
   * whole height).
   */
  function railLayout(S) {
    const panel = !!S.hasPanel;
    const rowH = panel ? 80 : 86;
    const max = panel ? 5 : 8;
    return { panel, y0: 78, rowH, max, rows: Math.min(S.players.length, max), rackY: panel ? 536 : 820, recentY: panel ? 606 : 890 };
  }
  /** A seat's plaque on the stage, or null when it isn't listed: box (x, y, w, h), avatar (ax, ay), stack (sx, sy). */
  function railSeat(S, seat) {
    const L = railLayout(S);
    const i = S.players.findIndex((p) => String(p.seat) === String(seat));
    if (i < 0 || i >= L.rows) return null;
    const x = RAIL_X + 12;
    const y = L.y0 + i * L.rowH;
    const w = RAIL_W - 36;
    const h = L.rowH - 10;
    return { i, x, y, w, h, ax: x + 38, ay: y + h / 2, sx: x + w - 30, sy: y + h - 22 };
  }
  /** The chips a seat has on the table (spot_bets), by seat. */
  function onTable(S) {
    const out = new Map();
    for (const list of Object.values(obj(S.st.spot_bets))) for (const e of arr(list)) out.set(String(e.seat), (out.get(String(e.seat)) || 0) + num(e.amount));
    return out;
  }
  function plaque(S, g, r, p, o) {
    const th = S.th;
    const { x, y, w, h } = r;
    g.save();
    if (o.alpha != null) g.globalAlpha *= o.alpha;
    rr(g, x, y, w, h, 16);
    const lg = g.createLinearGradient(0, y, 0, y + h);
    const gold = P.light ? "#b8892a" : th.accent;
    if (P.light) {
      // an ivory plaque standing off the gallery: a soft warm contact shadow
      g.save();
      softStroke(g, 0, 10, P.railShadow[0], 0.16, 0, 4, 3);
      g.restore();
    }
    lg.addColorStop(0, o.hot ? (P.light ? "#fbf1d6" : shade(th.accent_deep || "#3a2c08", 1.25)) : P.plaque[0]);
    lg.addColorStop(1, o.hot && P.light ? "#f1e0b2" : P.plaque[1]);
    rr(g, x, y, w, h, 16);
    g.fillStyle = lg;
    g.fill();
    if (!P.light) {
      g.fillStyle = grain(g);
      g.fill();
    }
    g.lineWidth = o.hot ? 2.5 : 1.5;
    g.strokeStyle = o.hot ? gold : rgba(gold, P.plaqueLine);
    g.stroke();
    rr(g, x + 2, y + 2, w - 4, h * 0.5, 14);
    g.fillStyle = P.plaqueSheen;
    g.fill();
    // the player's colour: a jewel bar at the left edge
    rr(g, x + 5, y + 12, 4, h - 24, 2);
    g.fillStyle = p.color || INK1;
    g.fill();
    // the avatar in a gold bezel
    const bz = g.createLinearGradient(r.ax - 28, r.ay - 28, r.ax + 28, r.ay + 28);
    bz.addColorStop(0, "#fff0b8");
    bz.addColorStop(0.5, "#a8761c");
    bz.addColorStop(1, "#f0cf6a");
    circle(g, r.ax, r.ay, 28);
    g.fillStyle = bz;
    g.fill();
    g.restore();
    avatar(S, g, r.ax, r.ay, 24, p, { alpha: o.alpha });
    const a = o.alpha == null ? 1 : o.alpha;
    txt(g, String(p.name || `P${p.seat}`), x + 76, y + 30, 24, inkOf(p.color), { weight: 750, maxW: w - 190, alpha: a, shadow: !P.light });
    if (o.info && o.info.text) txt(g, o.info.text, x + 76, y + h - 14, 16, roomInk(o.info.color || INK3, th), { weight: 800, maxW: w - 140, shadow: false, alpha: a, spacing: 0.5 });
    if (o.bet > 0) stack(S, g, r.sx, r.sy, 15, o.bet, p.color, { alpha: a });
  }

  // ================================================================================================ the win / lose moment
  /**
   * When a round settles every screen plays the same moment, from the result phase's anchor on the shared clock
   * (status.clock.phase_at): losing chips are swept to the dealer and "−500" fades over the loser's plaque; a tiered
   * banner slams in (WINNER · BIG WIN · MEGA WIN · JACKPOT by the best payout multiple, or HOUSE WINS) over turning
   * rays with a gold flash and — on big wins — a screen shake; coins fountain from each winner's chips into their
   * plaque, which lights up while "+12,500" counts up with a juicy ease and their credits roll on the odometer.
   * Every part is a pre-rendered sprite moved by transform / opacity (docs/TV_VIEW.md §6, §7). Only results in the
   * public status are shown — winners (net > 0, with stake) and losers — never anything computed here.
   */
  const MOMENT = { SWEEP0: 0.05, SWEEP: 0.8, BANNER: 0.25, SLAM: 0.38, OUT0: 3.3, OUT: 0.45, COIN0: 0.5, FLY: 0.95, STAGGER: 0.12, COUNT: 1.25, SHAKE: 0.55, LOSE0: 0.15, SKIP: 2.6 };
  const TIERS = {
    jackpot: { word: "JACKPOT!", c: ["#fffbe0", "#ffd84a", "#e08a14", "#7a3a00"], glow: "#ffb02e", shake: 16, coins: 18, rays: 1 },
    mega: { word: "MEGA WIN!", c: ["#fff0ff", "#ff7ae0", "#b23cff", "#3a0a5a"], glow: "#ff4fd8", shake: 10, coins: 14, rays: 1 },
    big: { word: "BIG WIN!", c: ["#f0fff8", "#7dffc4", "#18b878", "#053a24"], glow: "#3ddc97", shake: 6, coins: 11, rays: 0.9 },
    win: { word: "WINNER!", c: ["#fffaf0", "#ffe08a", "#d9a032", "#4a2e04"], glow: "#ffcc33", shake: 0, coins: 7, rays: 0.7 },
    house: { word: "HOUSE WINS", c: ["#ffffff", "#d6d9e2", "#7d8291", "#1c1e24"], glow: "#ff4d5e", shake: 0, coins: 0, rays: 0 },
  };
  const TIER_RANK = { house: 0, win: 1, big: 2, mega: 3, jackpot: 4 };
  /**
   * A win's tier by its payout multiple (net ÷ stake): ≥ 30 jackpot (a straight-up roulette number), ≥ 10 mega,
   * ≥ 3 big, else win; "lose" / "push" for net < 0 / = 0. The phone page has the same function (casino.html,
   * "shared win moment"); the test checks they agree.
   */
  function winTier(net, stake) {
    net = num(Number(net));
    stake = num(Number(stake));
    if (!(net > 0)) return net < 0 ? "lose" : "push";
    const m = stake > 0 ? net / stake : 1;
    return m >= 30 ? "jackpot" : m >= 10 ? "mega" : m >= 3 ? "big" : "win";
  }
  /** The "+12,500" ticker `age` s into the moment: 0 before `start`, then easeOutExpo up to exactly `net` after `dur`. */
  function tickerAt(age, net, start, dur) {
    const u = clamp((age - start) / dur, 0, 1);
    if (u >= 1) return net;
    return Math.round(net * (1 - Math.pow(2, -10 * u)) * (1 / (1 - Math.pow(2, -10))));
  }
  /** When winner number `wi`'s coins land in their plaque (moment age). */
  const arriveAt = (wi) => MOMENT.COIN0 + MOMENT.STAGGER * wi + MOMENT.FLY;

  /** The round's moment from the public status, or null (betting, previews, a round nobody played). */
  function momentOf(S) {
    if (S.preview) return null;
    if (S.def.moment) return S.def.moment(S);
    const st = S.st;
    if (st.phase !== "result") return null;
    const r = obj(st.result);
    const stakes = onTable(S);
    const winners = arr(r.winners)
      .filter((w) => w && num(w.net) > 0)
      .map((w) => ({ seat: w.seat, name: w.name, net: num(w.net), stake: num(w.stake) || stakes.get(String(w.seat)) || 0 }));
    const won = new Set(winners.map((w) => String(w.seat)));
    const losers = Array.isArray(r.losers)
      ? r.losers.filter((w) => w && num(w.net) < 0).map((w) => ({ seat: w.seat, name: w.name, net: num(w.net), stake: num(w.stake) }))
      : [...stakes].filter(([seat, a]) => a > 0 && !won.has(seat)).map(([seat, a]) => ({ seat, net: -a, stake: a }));
    if (!winners.length && !losers.length) return null;
    return momentFrom(S, `${st.game || S.def.id}|${r.round}|${st.round}`, obj(st.clock).phase_at, winners, losers);
  }
  function momentFrom(S, key, anchor, winners, losers) {
    winners.forEach((w) => (w.tier = winTier(w.net, w.stake)));
    let tier = "house";
    for (const w of winners) if (TIER_RANK[w.tier] > TIER_RANK[tier]) tier = w.tier;
    const top = winners.slice().sort((a, b) => TIER_RANK[b.tier] - TIER_RANK[a.tier] || b.net - a.net)[0] || null;
    const lost = losers.reduce((a, w) => a - w.net, 0);
    return { key, anchor: typeof anchor === "number" && S.ctx && typeof S.ctx.serverNow === "function" ? anchor : null, winners, losers, tier, top, lost };
  }
  /** Seconds into the current moment on the shared clock, or null. */
  const momentAge = (S) => (S.mo && S.mo.data && S.mo.at != null ? S.T - S.mo.at : null);

  const BAN_W = 1100;
  const BAN_H = 300;
  const RAYS = 760;
  const FLASH_W = 900;
  const FLASH_H = 480;
  const COINS = 30;
  const SPARKS = 14;
  function momentLayers(S, root) {
    const k = tableK();
    const mk = (w, h, kk) => {
      const l = layer(root, 0, 0, w, h, kk, true, true);
      l.c.style.display = "none";
      l.cache = { display: "none" };
      l.c.style.left = "0px";
      l.c.style.top = "0px";
      return l;
    };
    const M = { data: null, at: null, key: null, on: false };
    M.flash = mk(FLASH_W / 4, FLASH_H / 4, 1); // a soft burst: a quarter-size sprite shown 4× (it's all gradient)
    M.flash.c.style.width = `${FLASH_W}px`;
    M.flash.c.style.height = `${FLASH_H}px`;
    M.rays = mk(RAYS / 2, RAYS / 2, 1);
    M.rays.c.style.width = `${RAYS}px`;
    M.rays.c.style.height = `${RAYS}px`;
    M.plaques = [];
    for (let i = 0; i < 8; i++) M.plaques.push({ l: mk(RAIL_W + 20, 120, k), key: null });
    M.coins = [];
    for (let i = 0; i < COINS; i++) M.coins.push(mk(44, 44, Math.min(k, 1.5)));
    M.sparks = [];
    for (let i = 0; i < SPARKS; i++) M.sparks.push(mk(40, 40, 1));
    M.banner = mk(BAN_W, BAN_H, k);
    M.ticker = mk(900, 120, k);
    M.paintKey = {};
    S.mo = M;
    // the sprites that never change: the flash, a coin, a spark
    const fg = M.flash.g;
    const fl = fg.createRadialGradient(FLASH_W / 8, FLASH_H / 8, 2, FLASH_W / 8, FLASH_H / 8, FLASH_W / 8);
    fl.addColorStop(0, "rgba(255,250,225,.95)");
    fl.addColorStop(0.35, "rgba(255,214,120,.45)");
    fl.addColorStop(1, "rgba(255,190,80,0)");
    fg.fillStyle = fl;
    fg.fillRect(0, 0, FLASH_W / 4, FLASH_H / 4);
    M.flash.show();
    for (const c of M.coins) {
      const g = c.g;
      const r = 17;
      g.save();
      g.shadowColor = "rgba(0,0,0,.5)";
      g.shadowBlur = 5;
      g.shadowOffsetY = 2;
      circle(g, 22, 22, r);
      const cg = g.createRadialGradient(16, 14, 2, 22, 22, r);
      cg.addColorStop(0, "#fffbe0");
      cg.addColorStop(0.4, "#ffd54a");
      cg.addColorStop(0.85, "#c98a14");
      cg.addColorStop(1, "#7a4a04");
      g.fillStyle = cg;
      g.fill();
      g.restore();
      circle(g, 22, 22, r * 0.7);
      g.lineWidth = 2;
      g.strokeStyle = "rgba(122,74,4,.7)";
      g.stroke();
      txt(g, "$", 22, 29, 19, "#8a5a06", { align: "center", weight: 900, shadow: false });
      c.show();
    }
    for (const sp of M.sparks) {
      const g = sp.g;
      const gr = g.createRadialGradient(20, 20, 0, 20, 20, 20);
      gr.addColorStop(0, "rgba(255,255,255,1)");
      gr.addColorStop(0.25, "rgba(255,236,170,.8)");
      gr.addColorStop(1, "rgba(255,200,80,0)");
      g.fillStyle = gr;
      g.beginPath();
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        const rr2 = i % 2 ? 5 : 20;
        g.lineTo(20 + Math.cos(a) * rr2, 20 + Math.sin(a) * rr2);
      }
      g.closePath();
      g.fill();
      sp.show();
    }
  }

  /**
   * A tier's banner and rays, painted once per page into cached sprites (stage scale 1: the banner only shows while
   * it moves and scales) — pre-warmed while the table is idle, so the moment's first frame only copies them.
   */
  const bannerCache = new Map();
  function bannerSprites(tier) {
    let sp = bannerCache.get(tier);
    if (sp) return sp;
    const T = TIERS[tier] || TIERS.win;
    const bm = makeCanvas(BAN_W, BAN_H, 1);
    const g = bm.g;
    const cx = BAN_W / 2;
    const cy = BAN_H / 2 + 10;
    // a lacquered ribbon behind the word
    g.save();
    g.beginPath();
    g.moveTo(90, cy - 58);
    g.lineTo(BAN_W - 90, cy - 58);
    g.lineTo(BAN_W - 50, cy);
    g.lineTo(BAN_W - 90, cy + 58);
    g.lineTo(90, cy + 58);
    g.lineTo(50, cy);
    g.closePath();
    softStroke(g, 0, 26, "#000", 0.7, 0, 10, 5);
    const rb = g.createLinearGradient(0, cy - 58, 0, cy + 58);
    rb.addColorStop(0, shade(T.c[3], 1.6));
    rb.addColorStop(0.5, T.c[3]);
    rb.addColorStop(1, shade(T.c[3], 0.6));
    g.fillStyle = rb;
    g.fill();
    g.restore();
    g.lineWidth = 4;
    g.strokeStyle = T.c[1];
    g.stroke();
    // the word: glow, a thick dark outline, a metal fill, a top light
    const size = tier === "house" ? 104 : 132;
    g.save();
    g.font = `italic 900 ${size}px ${FONT}`;
    g.textAlign = "center";
    g.textBaseline = "middle";
    if ("letterSpacing" in g) g.letterSpacing = "2px";
    // the glow: the word's outline stroked wide and faint a few times (no blur: this paints in one frame on a stick)
    g.lineJoin = "round";
    g.strokeStyle = T.glow;
    for (let i = 3; i >= 1; i--) {
      g.globalAlpha = 0.12;
      g.lineWidth = 14 + i * 16;
      g.strokeText(T.word, cx, cy, BAN_W - 120);
    }
    g.globalAlpha = 1;
    g.lineWidth = 16;
    g.strokeStyle = shade(T.c[3], 0.7);
    g.strokeText(T.word, cx, cy, BAN_W - 120);
    g.lineWidth = 6;
    g.strokeStyle = T.c[0];
    g.strokeText(T.word, cx, cy, BAN_W - 120);
    const mg = g.createLinearGradient(0, cy - size / 2, 0, cy + size / 2);
    mg.addColorStop(0, T.c[0]);
    mg.addColorStop(0.45, T.c[1]);
    mg.addColorStop(0.55, T.c[2]);
    mg.addColorStop(1, T.c[1]);
    g.fillStyle = mg;
    g.fillText(T.word, cx, cy, BAN_W - 120);
    g.restore();
    const rm = makeCanvas(RAYS / 2, RAYS / 2, 1);
    const rg = rm.g;
    const c = RAYS / 4;
    const grd = rg.createRadialGradient(c, c, 10, c, c, c);
    grd.addColorStop(0, rgba(T.c[1], 0.75));
    grd.addColorStop(0.5, rgba(T.c[1], 0.25));
    grd.addColorStop(1, rgba(T.c[1], 0));
    rg.fillStyle = grd;
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * TAU;
      rg.beginPath();
      rg.moveTo(c, c);
      rg.arc(c, c, c, a, a + TAU / 36);
      rg.closePath();
      rg.fill();
    }
    sp = { banner: bm.c, rays: rm.c };
    bannerCache.set(tier, sp);
    return sp;
  }
  /** Put a tier's banner and rays into the moment's layers (two copies; nothing is drawn from scratch here). */
  function momentPaint(S, tier) {
    const M = S.mo;
    const key = `${tier}|${S.k}`;
    if (M.paintKey.banner === key) return;
    M.paintKey.banner = key;
    const sp = bannerSprites(tier);
    for (const [l, im, w, h] of [[M.banner, sp.banner, BAN_W, BAN_H], [M.rays, sp.rays, RAYS / 2, RAYS / 2]]) {
      l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
      l.g.clearRect(0, 0, w, h);
      l.g.drawImage(im, 0, 0, w, h);
      l.show();
    }
  }

  /** The hero ticker under the banner: "+12,500 · ANNA" (or "The house takes 500"), redrawn when its text changes. */
  function tickerPaint(S, text, sub, color) {
    const M = S.mo;
    const key = `${text}|${sub}|${color}|${S.k}`;
    if (M.paintKey.ticker === key) return;
    M.paintKey.ticker = key;
    const l = M.ticker;
    const g = l.g;
    g.setTransform(l.k, 0, 0, l.k, 0, 0);
    g.clearRect(0, 0, 900, 120);
    txt(g, text, 450, 70, 74, color, { align: "center", font: "mono", weight: 800 });
    if (sub) txt(g, sub, 450, 108, 26, INK1, { align: "center", weight: 750, maxW: 860 });
    l.show();
  }

  /** A plaque's overlay: the lit frame and its badge (+12,500 / −500), redrawn only when the badge changes. */
  const plaqueGlow = new Map();
  function plaquePaint(S, slot, r, kind, text, color) {
    const l = slot.l;
    const key = `${kind}|${text}|${r.w}|${r.h}|${S.k}`;
    if (slot.key === key) return;
    slot.key = key;
    const g = l.g;
    g.setTransform(l.k, 0, 0, l.k, 0, 0);
    g.clearRect(0, 0, l.w, l.h);
    const ox = 10;
    const oy = (l.h - r.h) / 2;
    if (kind === "win") {
      const gk = `${r.w}|${r.h}|${color}|${l.k}`;
      let sp = plaqueGlow.get(gk);
      if (!sp) {
        sp = makeCanvas(l.w, l.h, l.k);
        sp.g.shadowColor = color;
        sp.g.shadowBlur = 22;
        rr(sp.g, ox, oy, r.w, r.h, 16);
        sp.g.lineWidth = 4;
        sp.g.strokeStyle = color;
        sp.g.stroke();
        sp.g.shadowBlur = 0;
        sp.g.lineWidth = 1.5;
        sp.g.strokeStyle = "#fff6d0";
        sp.g.stroke();
        plaqueGlow.set(gk, sp);
      }
      g.drawImage(sp.c, 0, 0, l.w, l.h);
    }
    if (text) {
      const size = 21;
      const w = measure(g, text, size, { font: "mono", weight: 800 }) + 22;
      const bx = ox + r.w - w - 10; // under the credits, clear of the name
      const by = oy + r.h - 31;
      rr(g, bx, by, w, 27, 13.5);
      g.fillStyle = kind === "win" ? "rgba(6,40,22,.92)" : "rgba(60,8,16,.9)";
      g.fill();
      g.lineWidth = 2;
      g.strokeStyle = color;
      g.stroke();
      txt(g, text, bx + w / 2, by + 21, size, kind === "win" ? "#7dffc4" : "#ff8a9a", { align: "center", font: "mono", weight: 800, shadow: false });
    }
    l.show();
  }

  function setStyle(el, key, v, cache) {
    if (cache[key] !== v) {
      cache[key] = v;
      el.style[key] = v;
    }
  }
  /**
   * Hide a moving sprite: display none, so an idle sprite isn't a composited layer at all (every layer costs the
   * page's commit a little on every frame — dozens of idle coins would cost a TV stick its frame rate).
   */
  function hideLayer(l) {
    if (!l.cache) l.cache = {};
    setStyle(l.c, "display", "none", l.cache);
  }
  function moveLayer(l, tf, op) {
    if (!l.cache) l.cache = {};
    setStyle(l.c, "display", "", l.cache);
    setStyle(l.c, "transform", tf, l.cache);
    setStyle(l.c, "opacity", op, l.cache);
  }

  /** Where a winner's coins start: the scene's own answer (their winning chips), else the middle of the felt. */
  function coinFrom(S, seat, i) {
    const p = S.def.winFrom ? S.def.winFrom(S, seat) : null;
    const h = hash01(`${seat}|${i}`);
    const base = p || [RAIL_X / 2, SH / 2];
    return [base[0] + (h - 0.5) * 40, base[1] + (hash01(`${i}|${seat}`) - 0.5) * 30];
  }

  /**
   * One frame of the moment (all of it a function of its age on the shared clock). Returns the shake offset for
   * the scene root (paint() combines it with a scene's camera).
   */
  function momentFrame(S, t) {
    const M = S.mo;
    if (!M) return null;
    const d = M.data;
    const a = momentAge(S);
    const on = d && a != null && a >= 0;
    if (!on) {
      // idle: pre-paint one tier's banner per frame, a few seconds after the scene mounted
      if (!M.warm && S.t - (S.mountT || 0) > 3 && S.t >= S.animUntil && (S.st.phase === "betting" || S.st.phase === "idle") && S.t - (M.warmT || 0) > 1.5) {
        M.warmT = S.t;
        const next = Object.keys(TIERS).find((k) => !bannerCache.has(k));
        if (next) bannerSprites(next);
        else M.warm = true;
      }
      if (M.on) {
        M.on = false;
        for (const l of [M.flash, M.rays, M.banner, M.ticker, ...M.coins, ...M.sparks, ...M.plaques.map((p) => p.l)]) hideLayer(l);
      }
      return null;
    }
    M.on = true;
    const T = TIERS[d.tier] || TIERS.win;
    const cx = RAIL_X / 2;
    const cy = S.def.bannerY || 430;
    const late = M.skip; // the TV came in late: no replay, just the settled state
    // the banner and its rays, the flash
    momentPaint(S, d.tier);
    const bu = (a - MOMENT.BANNER) / MOMENT.SLAM;
    const out = clamp((a - MOMENT.OUT0) / MOMENT.OUT, 0, 1);
    if (!late && bu >= 0 && out < 1) {
      const sc = bu < 1 ? 1.7 - 0.7 * easeOutBack(bu) : 1 + 0.025 * Math.sin((a - MOMENT.BANNER) * 5);
      const op = (bu < 1 ? clamp(bu * 3, 0, 1) : 1) * (1 - out);
      moveLayer(M.banner, `translate(${cx - BAN_W / 2}px,${cy - BAN_H / 2}px) scale(${(sc * (1 - 0.3 * out)).toFixed(3)}) rotate(${(-0.03 * (1 - clamp(bu, 0, 1))).toFixed(3)}rad)`, op.toFixed(3));
      if (T.rays) moveLayer(M.rays, `translate(${cx - RAYS / 2}px,${cy - RAYS / 2}px) rotate(${(a * 0.35).toFixed(3)}rad) scale(${(0.6 + 0.4 * clamp(bu, 0, 1)).toFixed(3)})`, (T.rays * 0.85 * clamp(bu, 0, 1) * (1 - out)).toFixed(3));
      else hideLayer(M.rays);
      const fu = (a - MOMENT.BANNER) / 0.35;
      if (fu >= 0 && fu < 1 && d.tier !== "house") moveLayer(M.flash, `translate(${cx - FLASH_W / 2}px,${cy - FLASH_H / 2}px) scale(${(0.8 + 0.5 * fu).toFixed(3)})`, (0.7 * (1 - fu)).toFixed(3));
      else hideLayer(M.flash);
    } else {
      hideLayer(M.banner);
      hideLayer(M.rays);
      hideLayer(M.flash);
    }
    // the hero ticker under the banner
    const aq = Math.floor(a * 30) / 30; // the counters step at 30 Hz: half the repaints, the same count to the eye
    if (!late && a >= MOMENT.BANNER + 0.2 && out < 1) {
      if (d.top) tickerPaint(S, `+${fmt(S, tickerAt(aq, d.top.net, MOMENT.BANNER + 0.25, MOMENT.COUNT + 0.4))}`, `${d.top.name || `P${d.top.seat}`}${d.winners.length > 1 ? `  +  ${d.winners.length - 1} more` : ""}`, "#7dffc4");
      else tickerPaint(S, d.lost ? `−${fmt(S, d.lost)}` : "", "The house takes the table", "#ff8a9a");
      const k = easeOut((a - MOMENT.BANNER - 0.2) / 0.3);
      moveLayer(M.ticker, `translate(${cx - 450}px,${(cy + BAN_H / 2 - 20 + (1 - k) * 30).toFixed(1)}px)`, (k * (1 - out)).toFixed(3));
    } else hideLayer(M.ticker);
    // sparkles round the banner
    M.sparks.forEach((sp, i) => {
      const life = 0.7 + 0.5 * hash01(`sl${i}`);
      const t0 = MOMENT.BANNER + 0.15 + hash01(`st${i}`) * 2.4;
      const u = (a - t0) / life;
      if (late || d.tier === "house" || u < 0 || u > 1 || out >= 1) return hideLayer(sp);
      const x = cx + (hash01(`sx${i}`) - 0.5) * BAN_W * 0.95;
      const y = cy + (hash01(`sy${i}`) - 0.5) * BAN_H * 1.1;
      const s = Math.sin(u * Math.PI) * (0.6 + 0.8 * hash01(`ss${i}`));
      moveLayer(sp, `translate(${(x - 20).toFixed(1)}px,${(y - 20).toFixed(1)}px) rotate(${(u * 2).toFixed(2)}rad) scale(${s.toFixed(3)})`, Math.min(1, s * 1.5).toFixed(3));
    });
    // coins: a fountain from each winner's chips into their plaque
    let ci = 0;
    if (!late) {
      d.winners.forEach((w, wi) => {
        const target = railSeat(S, w.seat);
        const to = target ? [target.ax, target.ay] : [RAIL_X + RAIL_W / 2, 60];
        const n = Math.max(4, Math.round((TIERS[w.tier] || TIERS.win).coins / Math.max(1, Math.sqrt(d.winners.length))));
        for (let j = 0; j < n && ci < COINS; j++, ci++) {
          const c = M.coins[ci];
          const t0 = MOMENT.COIN0 + MOMENT.STAGGER * wi + j * 0.045;
          const u = (a - t0) / (MOMENT.FLY - j * 0.012);
          if (u < 0 || u >= 1) {
            hideLayer(c);
            continue;
          }
          const from = coinFrom(S, w.seat, j);
          const h = hash01(`c${w.seat}${j}`);
          const ctrl = [lerp(from[0], to[0], 0.3) + (h - 0.5) * 260, Math.min(from[1], to[1]) - 220 - 200 * hash01(`h${j}${w.seat}`)];
          const e = u * u * (3 - 2 * u);
          const x = (1 - e) * (1 - e) * from[0] + 2 * (1 - e) * e * ctrl[0] + e * e * to[0];
          const y = (1 - e) * (1 - e) * from[1] + 2 * (1 - e) * e * ctrl[1] + e * e * to[1];
          const spin = 0.2 + 0.8 * Math.abs(Math.cos(a * 13 + j));
          const sc = (1 + 0.45 * Math.sin(u * Math.PI)) * (u > 0.9 ? 1 - (u - 0.9) * 6 : 1);
          moveLayer(c, `translate(${(x - 22).toFixed(1)}px,${(y - 22).toFixed(1)}px) scale(${(sc * spin).toFixed(3)},${sc.toFixed(3)})`, clamp(u * 8, 0, 1).toFixed(3));
        }
      });
    }
    for (; ci < COINS; ci++) hideLayer(M.coins[ci]);
    // the plaques: winners light up and count, losers' "−500" floats away
    const used = new Set();
    const lit = 0.75 + 0.25 * Math.sin(a * 5);
    d.winners.forEach((w, wi) => {
      const r = railSeat(S, w.seat);
      if (!r) return;
      used.add(r.i);
      const slot = M.plaques[r.i];
      const arr0 = late ? -9 : arriveAt(wi);
      const v = tickerAt(aq, w.net, arr0, MOMENT.COUNT);
      plaquePaint(S, slot, r, "win", a >= arr0 ? `+${fmt(S, v)}` : "", (TIERS[w.tier] || TIERS.win).glow);
      const pop = !late && a >= arr0 && a < arr0 + 0.3 ? 1 + 0.08 * Math.sin(((a - arr0) / 0.3) * Math.PI) : 1;
      const op = late ? 1 : clamp((a - arr0 + 0.3) / 0.3, 0, 1);
      moveLayer(slot.l, `translate(${r.x - 10}px,${(r.y - (120 - r.h) / 2).toFixed(1)}px) scale(${pop.toFixed(3)})`, (op * lit).toFixed(3));
    });
    d.losers.forEach((w) => {
      const r = railSeat(S, w.seat);
      if (!r || used.has(r.i)) return;
      used.add(r.i);
      const slot = M.plaques[r.i];
      const u = late ? 1 : (a - MOMENT.LOSE0) / 2.2;
      plaquePaint(S, slot, r, "lose", `−${fmt(S, -w.net)}`, BAD);
      if (u < 0 || u >= 1) return hideLayer(slot.l);
      moveLayer(slot.l, `translate(${r.x - 10}px,${(r.y - (120 - r.h) / 2 - 14 * easeOut(u)).toFixed(1)}px)`, (u < 0.15 ? u / 0.15 : 1 - Math.pow((u - 0.15) / 0.85, 2)).toFixed(3));
    });
    M.plaques.forEach((p, i) => {
      if (!used.has(i)) hideLayer(p.l);
    });
    // the shake (big wins)
    const su = (a - MOMENT.BANNER - 0.12) / MOMENT.SHAKE;
    if (!late && T.shake && su >= 0 && su < 1) {
      const amp = T.shake * (1 - su) * (1 - su);
      return [amp * Math.sin(a * 71), amp * 0.7 * Math.cos(a * 53)];
    }
    return null;
  }
  /** A new status: start, keep or end the moment. */
  function momentIngest(S, t) {
    const M = S.mo;
    if (!M) return;
    const d = momentOf(S);
    if (!d) {
      M.data = null;
      M.key = null;
      M.at = null;
      return;
    }
    if (d.key !== M.key) {
      M.key = d.key;
      M.at = d.anchor != null ? d.anchor : S.T - (S.def.momentSince ? S.def.momentSince(S, t) : S.clk.since(t));
      const age = S.T - M.at;
      M.skip = S.firstIngest || age > MOMENT.SKIP; // a TV that tunes in late shows the settled table, no replay
      M.held = new Map();
    } else if (d.anchor != null) M.at = d.anchor;
    M.data = d;
  }
  /** Hold a seat's credits on the odometer until their coins land (winners) or the "−" shows (losers). */
  function creditsHeld(S, seat) {
    const M = S.mo;
    const a = momentAge(S);
    if (!M || !M.data || a == null || M.skip) return false;
    const wi = M.data.winners.findIndex((w) => String(w.seat) === String(seat));
    if (wi >= 0) return a < arriveAt(wi);
    if (M.data.losers.some((w) => String(w.seat) === String(seat))) return a < MOMENT.LOSE0;
    return false;
  }

  // ------------------------------------------------------------------------------------------------ shared headline
  /**
   * The table's headline for the phase: {title, sub, tone, ring:{frac,label}}. Games pass `custom(phase)` for their
   * own words; betting / locked / paused / idle are shared.
   */
  function headline(S, t, custom) {
    const st = S.st;
    const ph = String(st.phase || "idle");
    const th = S.th;
    const c = custom ? custom(ph) : null;
    if (c) return c;
    if (ph === "betting") {
      const left = leftTo(S, "ends_at", S.clk.ends, t);
      const total = Object.values(obj(st.totals)).reduce((a, b) => a + num(b), 0);
      const n = arr(st.bettors).length;
      if (st.ends_in == null || left == null)
        return { title: "PLACE YOUR BETS", sub: "The countdown starts with the first chip", tone: th.accent, pulse: true };
      const span = num(obj(st.house).bet_seconds, 20);
      return {
        title: "PLACE YOUR BETS",
        sub: `${n} ${n === 1 ? "player" : "players"} in · ${fmt(S, total)} on the table`,
        tone: left <= 5 ? BAD : th.accent,
        ring: { frac: left / span, label: Math.ceil(left - 1e-6), color: left <= 5 ? BAD : th.accent, left, span, base: th.accent, low: BAD, lowBelow: 5.0001 },
      };
    }
    if (ph === "locked") return { title: "NO MORE BETS", sub: "Bets are locked", tone: BAD, flash: true };
    if (ph === "result") {
      const next = leftTo(S, "next_at", S.clk.next, t);
      const ws = winners(S);
      return {
        title: String(obj(st.result).label || "RESULT"),
        sub: ws.length ? `${ws.length} ${ws.length === 1 ? "winner" : "winners"}` : "The house wins this one",
        tone: th.accent,
        ring: next != null ? { frac: next / num(obj(st.house).result_seconds, 7), label: Math.ceil(next - 1e-6), color: INK3, left: next, span: num(obj(st.house).result_seconds, 7) } : null,
      };
    }
    if (ph === "idle") return { title: "TABLE CLOSED", sub: "Waiting for the host to open a round", tone: INK3 };
    return { title: ph.toUpperCase(), sub: "", tone: th.accent };
  }

  function drawHeadline(S, g, x, y, w, t, h, o) {
    o = o || {};
    if (!h) return;
    const size = o.size || 60;
    let alpha = 1;
    if (h.pulse) alpha = 0.65 + 0.35 * Math.sin(t * 3.4);
    if (h.flash) alpha = 0.55 + 0.45 * (Math.sin(t * 10) > 0 ? 1 : 0);
    const align = o.align || "left";
    const rx = align === "center" ? x : x + w - (o.ringR || 50);
    const tx = align === "center" ? x : x;
    const onRoom = o.room && P.light; // a headline on the room, not the felt (the poker tables): the room's ink
    const tone = onRoom ? roomInk(h.tone || INK1, S.th) : h.tone || INK1;
    txt(g, h.title, tx, y + size * 0.8, size, tone, { weight: 850, align, alpha, maxW: w - (h.ring && align !== "center" ? 130 : 0), glow: onRoom ? null : rgba(tone, 0.45), shadow: !onRoom });
    if (h.sub) txt(g, h.sub, tx, y + size * 0.8 + 40, 26, onRoom ? P.ink2 : INK2, { shadow: !onRoom, weight: 600, align, maxW: w - (h.ring && align !== "center" ? 130 : 0) });
    if (h.ring && align !== "center") {
      const R = o.ringR || 50;
      if (h.ring.left != null) {
        // the countdown sweeps every frame in its own small canvas (no table redraw for it)
        hudRing(S, "head", rx, y + size * 0.55, R, { left: h.ring.left, span: h.ring.span, color: h.ring.base || h.ring.color || S.th.accent, low: h.ring.low, lowBelow: h.ring.lowBelow });
      } else ring(g, rx, y + size * 0.55, R, h.ring.frac, h.ring.color || S.th.accent, h.ring.label);
    }
  }

  /** The winners card: up to `max` winners with avatar, name and net, or "House wins". */
  function winnersCard(S, g, x, y, w, t, o) {
    o = o || {};
    const ws = winners(S);
    const max = o.max || 4;
    const k = o.instant ? 1 : easeOut((S.clk.since(t) - (o.delay || 0)) / 0.5);
    if (k <= 0) return;
    g.save();
    g.globalAlpha *= k;
    const h = 60 + Math.max(1, Math.min(ws.length, max)) * 54;
    rr(g, x, y, w, h, 20);
    g.fillStyle = "rgba(0,0,0,.55)";
    g.fill();
    g.lineWidth = 2;
    g.strokeStyle = rgba(S.th.accent, 0.6);
    g.stroke();
    txt(g, ws.length ? "WINNERS" : "NO WINNERS", x + 22, y + 38, 22, S.th.accent, { weight: 850, shadow: false });
    if (!ws.length) txt(g, o.empty || "The house takes the table", x + 22, y + 88, 26, INK2, { weight: 650, maxW: w - 44 });
    ws.slice(0, max).forEach((wv, i) => {
      const yy = y + 62 + i * 54;
      avatar(S, g, x + 44, yy + 22, 20, wv);
      txt(g, wv.name || `P${wv.seat}`, x + 76, yy + 32, 28, wv.color, { weight: 750, maxW: w - 250 });
      txt(g, signed(S, num(wv.net)), x + w - 22, yy + 32, 30, OK, { align: "right", font: "mono", weight: 800, glow: rgba(OK, 0.5) });
    });
    if (ws.length > max) txt(g, `+ ${ws.length - max} more`, x + w - 22, y + 38, 20, INK2, { align: "right", weight: 700 });
    g.restore();
  }

  /** Chasing bulbs round a rectangle (result flourish). */
  function bulbs(g, x, y, w, h, t, color, n) {
    const per = 2 * (w + h);
    const count = n || 40;
    for (let i = 0; i < count; i++) {
      let d = (i / count) * per;
      let px;
      let py;
      if (d < w) [px, py] = [x + d, y];
      else if ((d -= w) < h) [px, py] = [x + w, y + d];
      else if ((d -= h) < w) [px, py] = [x + w - d, y + h];
      else [px, py] = [x, y + h - (d - w)];
      const on = (i + Math.floor(t * 10)) % 3 === 0;
      circle(g, px, py, on ? 6 : 4);
      g.fillStyle = on ? color : rgba(color, 0.25);
      g.fill();
    }
  }

  // ================================================================================================ ROULETTE
  const R_CX = 382;
  const R_CY = 548;
  const R_RIM = 340;
  const R_TRACK_OUT = 300;
  const R_HEAD = 262;
  const R_NUM_IN = 222;
  const R_POCK_IN = 184;
  const R_TRACK = 281;
  const R_POCKET = 203;
  function rouletteWheel(S) {
    return obj(S.st.rules).wheel === "american" ? US_WHEEL : EU_WHEEL;
  }

  /** The wheel head (pockets, numbers, cone, turret) centred at (c, c) of `g`: drawn once, spun by CSS. */
  function drawWheelHead(S, g, c) {
    const wheel = rouletteWheel(S);
    g.save();
    g.translate(c, c);
    const N = wheel.length;
    const seg = TAU / N;
    for (let i = 0; i < N; i++) {
      const n = wheel[i];
      const a0 = i * seg - seg / 2 - Math.PI / 2;
      const base = { red: "#c3122c", black: "#17171d", green: "#0b8a43" }[rColor(n)];
      g.beginPath();
      g.arc(0, 0, R_HEAD, a0, a0 + seg);
      g.arc(0, 0, R_NUM_IN, a0 + seg, a0, true);
      g.closePath();
      g.fillStyle = base;
      g.fill();
      g.beginPath();
      g.arc(0, 0, R_NUM_IN, a0, a0 + seg);
      g.arc(0, 0, R_POCK_IN, a0 + seg, a0, true);
      g.closePath();
      const pg = g.createRadialGradient(0, 0, R_POCK_IN, 0, 0, R_NUM_IN);
      pg.addColorStop(0, shade(base, 0.45));
      pg.addColorStop(1, shade(base, 0.8));
      g.fillStyle = pg;
      g.fill();
      g.save();
      g.rotate(i * seg);
      txt(g, rLabel(n), 0, -R_HEAD + 30, 23, "#ffffff", { align: "center", weight: 800, shadow: false });
      g.restore();
    }
    const fret = g.createLinearGradient(-R_HEAD, -R_HEAD, R_HEAD, R_HEAD);
    fret.addColorStop(0, "#fff1c2");
    fret.addColorStop(0.35, "#d9b45a");
    fret.addColorStop(0.65, "#8a6420");
    fret.addColorStop(1, "#f0d488");
    g.strokeStyle = fret;
    for (let i = 0; i < N; i++) {
      const a = i * seg - seg / 2 - Math.PI / 2;
      g.lineWidth = 2.2;
      g.beginPath();
      g.moveTo(Math.cos(a) * R_POCK_IN, Math.sin(a) * R_POCK_IN);
      g.lineTo(Math.cos(a) * R_HEAD, Math.sin(a) * R_HEAD);
      g.stroke();
    }
    for (const r of [R_POCK_IN, R_NUM_IN, R_HEAD]) {
      circle(g, 0, 0, r);
      g.lineWidth = r === R_NUM_IN ? 2 : 3;
      g.stroke();
    }
    // the cone and the turret
    circle(g, 0, 0, R_POCK_IN - 2);
    const cg = g.createRadialGradient(-50, -60, 6, 0, 0, R_POCK_IN);
    cg.addColorStop(0, "#b07a46");
    cg.addColorStop(0.35, "#7a4a24");
    cg.addColorStop(0.75, "#4a2810");
    cg.addColorStop(1, "#1e0f05");
    g.fillStyle = cg;
    g.fill();
    // fine walnut rings on the cone
    for (let r = 40; r < R_POCK_IN - 6; r += 9) {
      circle(g, 0, 0, r);
      g.lineWidth = 1;
      g.strokeStyle = r % 2 ? "rgba(0,0,0,.12)" : "rgba(255,210,160,.05)";
      g.stroke();
    }
    for (const r of [140, 96]) {
      circle(g, 0, 0, r);
      g.lineWidth = 2;
      g.strokeStyle = "rgba(255,220,150,.25)";
      g.stroke();
    }
    const arm = g.createLinearGradient(-8, 0, 8, 0);
    arm.addColorStop(0, "#7a5a14");
    arm.addColorStop(0.45, "#fff2c4");
    arm.addColorStop(1, "#a8801e");
    g.fillStyle = arm;
    g.strokeStyle = "#6a4a10";
    for (let i = 0; i < 4; i++) {
      g.save();
      g.rotate((i * Math.PI) / 2);
      rr(g, -7, -118, 14, 118, 7);
      g.fill();
      circle(g, 0, -118, 15);
      g.fill();
      g.lineWidth = 2;
      g.stroke();
      g.restore();
    }
    circle(g, 0, 0, 34);
    const tg = g.createRadialGradient(-10, -12, 2, 0, 0, 34);
    tg.addColorStop(0, "#fff3c4");
    tg.addColorStop(1, "#b38a2a");
    g.fillStyle = tg;
    g.fill();
    g.restore();
  }

  // The panel's motion (apps/casino_roulette.py), ported 1:1: angles in radians clockwise from 12 o'clock, radii in
  // panel pixels (mapped onto the HD bowl by `panelR`), times in seconds since betting closed (since_lock).
  const RP = { TRACK: 14.5, POCKET: 11.7, BW0: 6.4, BTAU: 3.3, WW0: 2.3, WTAU: 5.5, DRIFT: 0.32 };
  const ballTravel = (t) => RP.BW0 * RP.BTAU * (1 - Math.exp(-t / RP.BTAU));
  const wheelTravel = (t) => RP.WW0 * RP.WTAU * (1 - Math.exp(-t / RP.WTAU)) + RP.DRIFT * t;
  const panelR = (r) => R_POCKET + (r - RP.POCKET) * ((R_TRACK - R_POCKET) / (RP.TRACK - RP.POCKET));

  /** casino_roulette.wheel_step: how far the wheel turns (anticlockwise) in the dt s that end at since_lock. */
  function wheelStep(sinceLock, dt) {
    let out = RP.DRIFT * dt;
    if (sinceLock != null && sinceLock > 0) {
      const s0 = Math.max(0, sinceLock - dt);
      out += RP.WW0 * RP.WTAU * (Math.exp(-s0 / RP.WTAU) - Math.exp(-sinceLock / RP.WTAU));
    }
    return out;
  }

  /** casino_roulette.ball with rot = 0: the ball's angle relative to the wheel, and its radius (panel px). */
  function rouletteBallRel(t, pocket, n, spin, lock) {
    const tSettle = lock + spin - 1.0;
    const tDrop = tSettle - 1.3;
    const target = (pocket * TAU) / n;
    if (t >= tSettle) {
      const u = t - tSettle;
      return { a: target + 0.09 * Math.sin(u * 19) * Math.exp(-u * 4.5), r: RP.POCKET, settled: true };
    }
    const psi0 = target - ballTravel(tSettle) - wheelTravel(tSettle);
    const psi = psi0 + ballTravel(t) + wheelTravel(t);
    let r = RP.TRACK;
    let hop = 0;
    if (t > tDrop) {
      const u = (t - tDrop) / (tSettle - tDrop);
      const ease = u * u * (3 - 2 * u);
      hop = 1.6 * Math.abs(Math.sin(u * 2.6 * Math.PI)) * (1 - u) * (1 - u);
      r = RP.TRACK - (RP.TRACK - RP.POCKET) * ease + hop;
    }
    return { a: psi, r, settled: false, hop };
  }

  /**
   * The wheel's angle on the TV: integrated with the panel's own step (wheelStep) on the engine's clock, and pulled
   * onto the angle the panel reports (tv.wheel: its rot when it last drew, at server time `at`) — the first report
   * snaps, later ones are slewed in over ~0.3 s, so the wheel never jumps and always matches the panel's.
   */
  function rouletteRot(S, T) {
    const fx = S.fx;
    const rv = revealOf(S, "roulette");
    const sl = rv ? sinceLockOf(rv, T) : null;
    if (fx.R == null) {
      fx.R = 0;
      fx.lastT = T;
    }
    const dt = clamp(T - fx.lastT, 0, 0.5);
    fx.lastT = T;
    if (rv && fx.spinRound !== rv.round) {
      // the lock reached us a moment after it happened: the spin the wheel already made is slewed in, not jumped
      fx.spinRound = rv.round;
      const missed = Math.max(0, sl - dt);
      if (missed > 0 && missed < 3) fx.err -= wheelStep(missed, missed) - RP.DRIFT * missed;
    }
    fx.R -= wheelStep(sl, dt);
    const w = obj(obj(S.ctx && S.ctx.tv).wheel);
    if (typeof w.rot === "number" && typeof w.at === "number" && w.at !== fx.anchorAt) {
      fx.anchorAt = w.at;
      const err = w.rot - wheelStep(sl, Math.max(0, T - w.at)) - fx.R; // where the panel's wheel is now, minus ours
      if (!fx.synced || Math.abs(err) > 0.8) {
        fx.R += err;
        fx.err = 0;
        fx.synced = true;
      } else fx.err = err;
    }
    if (fx.err) {
      const c = fx.err * (1 - Math.exp(-dt / 0.3));
      fx.R += c;
      fx.err -= c;
    }
    return fx.R;
  }

  /** The ball: {a, r (HD px), alpha, settled} — launched at the lock on the panel's path; none while betting. */
  function rouletteBallNow(S, T, rot, n) {
    const fx = S.fx;
    const rv = revealOf(S, "roulette");
    const pocket = rv ? obj(rv.outcome).pocket : null;
    if (rv && typeof pocket === "number" && pocket < n) {
      const sl = sinceLockOf(rv, T);
      const b = rouletteBallRel(Math.max(0, sl), pocket, n, num(rv.spin_s, 7.5), num(rv.lock_s, LOCK));
      fx.lastBall = { pocket, T };
      return { a: rot + b.a, r: panelR(b.r), alpha: clamp(sl / 0.25, 0, 1), settled: b.settled, hop: b.hop || 0 };
    }
    if (fx.lastBall && T - fx.lastBall.T < 0.5) {
      // a new round opened: the croupier lifts the ball out (the panel simply stops drawing it)
      return { a: rot + (fx.lastBall.pocket * TAU) / n, r: R_POCKET, alpha: 1 - (T - fx.lastBall.T) / 0.5, settled: true };
    }
    return null;
  }

  const wheelK = () => clamp(num(TV && TV.pixelRatio, 1), 1, 2); // the spinning bitmaps stay crisp (both tiers)

  const roulette = makeScene({
    id: "casino-roulette",
    app: "casino_roulette",
    init(S) {
      S.fx = { R: null, err: 0, synced: false };
    },
    bgKey: (S) => (obj(S.st.rules).wheel === "american" ? "us" : "eu"),
    // the wheel head (pre-rendered once, spun by a CSS rotate), the winning-pocket ring (rides with it), the ball
    layers(S, root) {
      const k = wheelK();
      const D = 2 * R_HEAD + 8;
      S.L.wheel = layer(root, R_CX - D / 2, R_CY - D / 2, D, D, k, true);
      S.L.hit = layer(root, R_CX - D / 2, R_CY - D / 2, D, D, k, true);
      S.L.hit.c.style.opacity = "0";
      // the ball's motion blur: a tapered streak behind it, turned along its path, stronger the faster it runs
      S.L.streak = layer(root, 0, 0, 170, 34, k, true);
      S.L.streak.c.style.display = "none";
      S.L.streak.cache = { display: "none" };
      S.L.streak.c.style.transformOrigin = "153px 17px";
      const sg = S.L.streak.g;
      const sgr = sg.createLinearGradient(0, 0, 160, 0);
      sgr.addColorStop(0, "rgba(255,255,255,0)");
      sgr.addColorStop(0.75, "rgba(235,238,248,.32)");
      sgr.addColorStop(1, "rgba(255,255,255,.7)");
      sg.fillStyle = sgr;
      sg.beginPath();
      sg.moveTo(0, 17);
      sg.quadraticCurveTo(110, 9, 153, 7.5);
      sg.arc(153, 17, 9.5, -Math.PI / 2, Math.PI / 2);
      sg.quadraticCurveTo(110, 25, 0, 17);
      sg.closePath();
      sg.fill();
      S.L.streak.show();
      S.L.ball = layer(root, 0, 0, 34, 34, k, true);
      S.L.ball.c.style.opacity = "0";
      const g = S.L.ball.g;
      g.save();
      g.shadowColor = "rgba(0,0,0,.6)";
      g.shadowBlur = 6;
      g.shadowOffsetY = 3;
      circle(g, 17, 16, 10.5);
      const bg = g.createRadialGradient(13, 12, 1, 17, 16, 11);
      bg.addColorStop(0, "#ffffff");
      bg.addColorStop(1, "#b9bcc6");
      g.fillStyle = bg;
      g.fill();
      g.restore();
      S.L.ball.show();
    },
    layersRedraw(S) {
      const l = S.L.wheel;
      l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
      l.g.clearRect(0, 0, l.w, l.h);
      drawWheelHead(S, l.g, l.w / 2);
      l.show();
      S.fx.hitKey = null;
    },
    move(S) {
      const st = S.st;
      const wheel = rouletteWheel(S);
      const N = wheel.length;
      const T = S.T;
      const rot = rouletteRot(S, T);
      const tr = `rotate(${((rot * 180) / Math.PI).toFixed(3)}deg)`;
      S.L.wheel.c.style.transform = tr;
      S.L.hit.c.style.transform = tr;
      const ball = rouletteBallNow(S, T, rot, N);
      const bs = S.L.ball.c.style;
      const fx = S.fx;
      let bx = null;
      let by = null;
      if (ball && ball.alpha > 0) {
        bx = R_CX + Math.sin(ball.a) * ball.r;
        by = R_CY - Math.cos(ball.a) * ball.r;
        // it hops toward the camera as it bounces over the frets (cosmetic: the position is the panel's)
        const hs = 1 + 0.16 * clamp(num(ball.hop) / 1.6, 0, 1);
        bs.transform = `translate(${(bx - 17).toFixed(2)}px,${(by - 17).toFixed(2)}px)${hs > 1.001 ? ` scale(${hs.toFixed(3)})` : ""}`;
        bs.opacity = ball.alpha.toFixed(3);
      } else if (bs.opacity !== "0") bs.opacity = "0";
      // the streak: speed from the last frame (stage px / s), along the direction of travel
      const pb = fx.bprev;
      let speed = 0;
      let dir = 0;
      if (bx != null && pb && T > pb.T + 1e-4) {
        speed = Math.hypot(bx - pb.x, by - pb.y) / (T - pb.T);
        dir = Math.atan2(by - pb.y, bx - pb.x);
      }
      fx.bprev = bx != null ? { x: bx, y: by, T } : null;
      const so = bx != null && speed < 4000 ? clamp((speed - 160) / 700, 0, 0.85) * ball.alpha : 0;
      if (so > 0.01) moveLayer(S.L.streak, `translate(${(bx - 153).toFixed(1)}px,${(by - 17).toFixed(1)}px) rotate(${dir.toFixed(3)}rad) scale(${clamp(speed / 1100, 0.35, 1.15).toFixed(3)},1)`, so.toFixed(3));
      else hideLayer(S.L.streak);
      // the camera: once the ball settles it pushes in on the pocket, then pans out toward the layout's number as
      // the dealer sets the dolly (a pure function of the shared clock, like everything here)
      const rv = revealOf(S, "roulette");
      S.cam = null;
      if (rv && bx != null) {
        const c = sinceLockOf(rv, T) - (num(rv.lock_s, LOCK) + num(rv.spin_s, 7.5) - 1.0);
        if (c >= 0 && c < 1.3) {
          const zin = easeOut(c / 0.35);
          const zout = easeInOut((c - 0.6) / 0.7);
          const n = rouletteWheel(S)[obj(rv.outcome).pocket];
          const cell = n != null ? rouletteCenter(n, rouletteBoard(N === 38)) : [bx, by];
          S.cam = { s: 1 + 0.14 * zin * (1 - zout), x: lerp(bx, cell[0], zout), y: lerp(by, cell[1], zout) };
        }
      }
      S.def.stamp(S);
      // the winning pocket glows (on the wheel) once the round's result is public
      const pocket = obj(obj(st.result).outcome).pocket;
      const hitKey = st.phase === "result" && typeof pocket === "number" ? `${N}|${pocket}` : null;
      if (hitKey !== S.fx.hitKey) {
        S.fx.hitKey = hitKey;
        const l = S.L.hit;
        l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
        l.g.clearRect(0, 0, l.w, l.h);
        if (hitKey) {
          const seg = TAU / N;
          const a = pocket * seg - Math.PI / 2;
          const c = l.w / 2;
          l.g.save();
          l.g.beginPath();
          l.g.arc(c, c, R_HEAD + 2, a - seg / 2, a + seg / 2);
          l.g.arc(c, c, R_POCK_IN, a + seg / 2, a - seg / 2, true);
          l.g.closePath();
          l.g.lineWidth = 4;
          l.g.strokeStyle = "#ffffff";
          l.g.shadowColor = S.th.accent;
          l.g.shadowBlur = 18;
          l.g.stroke();
          l.g.restore();
        }
        l.show();
        l.c.style.opacity = hitKey ? "1" : "0";
      }
    },
    overlays(S, root) {
      dollyLayers(S, root, "dolly");
    },
    // the dealer lifts the dolly from its rest, glides it over the layout and sets it on the winning number just
    // before the result shows (the ball settles at the panel's t_settle, the dolly lands DOLLY_AFTER later); when
    // the next round opens it goes home the same way. Its style is the house's (status.house.dolly).
    stamp(S) {
      const fx = S.fx;
      dollyPaint(S, "dolly", obj(S.st.house).dolly || "classic_gold");
      const rv = revealOf(S, "roulette");
      const n = rv ? rouletteWheel(S)[obj(rv.outcome).pocket] : undefined;
      if (n != null) {
        const tLand = num(rv.lock_s, LOCK) + num(rv.spin_s, 7.5) - 1.0 + DOLLY_AFTER;
        const [x, y] = rouletteCenter(n, rouletteBoard(rouletteWheel(S).length === 38));
        const to = [x, y + 16];
        const age = sinceLockOf(rv, S.T) - tLand;
        const p = dollyPath(DOLLY_REST, to, age);
        fx.dollyAt = [p.x, p.y];
        fx.dollyHome = null;
        return dollyMove(S, "dolly", p, age);
      }
      // home again: the same hand motion back to its rest, on this screen's clock (nothing to sync: it's empty felt)
      if (fx.dollyAt && !fx.dollyHome) fx.dollyHome = { from: fx.dollyAt, T: S.T };
      if (fx.dollyHome) {
        const age = S.T - fx.dollyHome.T - 1.0;
        const p = dollyPath(fx.dollyHome.from, DOLLY_REST, age);
        if (age > 0.3) fx.dollyAt = fx.dollyHome = null;
        return dollyMove(S, "dolly", p, null);
      }
      dollyMove(S, "dolly", { x: DOLLY_REST[0], y: DOLLY_REST[1], lift: 0, sy: 1 }, null);
    },
    winFrom(S, seat) {
      // a winner's coins rise from their own winning chips
      const st = S.st;
      const n = rouletteWheel(S)[obj(obj(st.result).outcome).pocket];
      const B = rouletteBoard(rouletteWheel(S).length === 38);
      let sx = 0;
      let sy = 0;
      let k = 0;
      for (const [spot, list] of Object.entries(obj(st.spot_bets))) {
        if (n == null || !rouletteCovers(spot).includes(n) || !arr(list).some((e) => String(e.seat) === String(seat))) continue;
        const p = rouletteSpotXY(spot, B);
        if (p) {
          sx += p[0];
          sy += p[1];
          k++;
        }
      }
      return k ? [sx / k, sy / k] : null;
    },
    // the table layer only redraws for a countdown tick while betting; never while the wheel is spinning
    slowHz: (S) => (S.st.phase === "betting" && S.st.ends_in != null ? 1 : 0),
    bg(S, g) {
      const th = S.th;
      // the table
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 900, 480, 1100, 36);
      // the bowl: sunk into the table on a long soft shadow, a polished brass ring, a lacquered walnut bowl
      circle(g, R_CX, R_CY, R_RIM + 14);
      softStroke(g, 0, 46, "#000", 0.85, 0, 18, 6);
      g.fillStyle = "#1a0d06";
      g.fill();
      circle(g, R_CX, R_CY, R_RIM + 12);
      const br = g.createLinearGradient(R_CX - R_RIM, R_CY - R_RIM, R_CX + R_RIM, R_CY + R_RIM);
      br.addColorStop(0, "#fff0b8");
      br.addColorStop(0.22, "#c9973a");
      br.addColorStop(0.5, "#6e4a12");
      br.addColorStop(0.74, "#e2b85a");
      br.addColorStop(1, "#5a3a0c");
      g.fillStyle = br;
      g.fill();
      circle(g, R_CX, R_CY, R_RIM);
      const wg = g.createRadialGradient(R_CX - 90, R_CY - 130, 30, R_CX, R_CY, R_RIM);
      wg.addColorStop(0, "#8e5a2e");
      wg.addColorStop(0.55, "#5e3517");
      wg.addColorStop(0.88, "#3a1f0c");
      wg.addColorStop(1, "#1f1006");
      g.fillStyle = wg;
      g.fill();
      // the lacquer's reflection: a soft crescent of the lamp on the bowl's upper left
      g.save();
      circle(g, R_CX, R_CY, R_RIM - 4);
      g.clip();
      const gl = g.createLinearGradient(R_CX - R_RIM, R_CY - R_RIM, R_CX, R_CY);
      gl.addColorStop(0, "rgba(255,240,215,.22)");
      gl.addColorStop(0.45, "rgba(255,240,215,.05)");
      gl.addColorStop(1, "rgba(255,240,215,0)");
      g.beginPath();
      g.arc(R_CX, R_CY, R_RIM - 4, Math.PI * 0.95, Math.PI * 1.75);
      g.arc(R_CX + 26, R_CY + 26, R_RIM - 20, Math.PI * 1.75, Math.PI * 0.95, true);
      g.closePath();
      g.fillStyle = gl;
      g.fill();
      g.restore();
      circle(g, R_CX, R_CY, R_TRACK_OUT + 4);
      g.lineWidth = 6;
      g.strokeStyle = shade(th.accent, 0.8);
      g.stroke();
      circle(g, R_CX, R_CY, R_TRACK_OUT);
      const tg = g.createRadialGradient(R_CX, R_CY, R_HEAD, R_CX, R_CY, R_TRACK_OUT);
      tg.addColorStop(0, "#1a110b");
      tg.addColorStop(0.7, "#3b2616");
      tg.addColorStop(1, "#22150c");
      g.fillStyle = tg;
      g.fill();
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU + 0.2;
        const x = R_CX + Math.sin(a) * 272;
        const y = R_CY - Math.cos(a) * 272;
        g.save();
        g.translate(x, y);
        g.rotate(a);
        g.beginPath();
        g.moveTo(0, -9);
        g.lineTo(6, 0);
        g.lineTo(0, 9);
        g.lineTo(-6, 0);
        g.closePath();
        g.fillStyle = "#d9b45a";
        g.fill();
        g.restore();
      }
      txt(g, "ROULETTE", 62, 100, 52, th.accent, { weight: 700, font: "serif", gold: true, spacing: 5 });
      txt(g, obj(S.st.rules).wheel === "american" ? "AMERICAN · 0 AND 00" : "EUROPEAN · SINGLE ZERO", 64, 136, 20, rgba(th.accent_hi || th.accent, 0.75), { weight: 700, spacing: 3 });
      // the printed layout
      const B = rouletteBoard(obj(S.st.rules).wheel === "american");
      const L = B.x0 + B.zw;
      const gold = th.accent;
      const cellFill = { red: "#a8112a", black: "#18181f", green: "#0b7a3e" };
      const zeros = B.us ? [37, 0] : [0];
      zeros.forEach((n, i) => {
        const h = (3 * B.ch) / zeros.length;
        g.beginPath();
        g.rect(B.x0, B.y0 + i * h, B.zw, h);
        g.fillStyle = cellFill.green;
        g.fill();
        txt(g, rLabel(n), B.x0 + B.zw / 2, B.y0 + i * h + h / 2 + 13, 36, "#fff", { align: "center", weight: 800, emboss: true });
      });
      for (let n = 1; n <= 36; n++) {
        const q = numCell(n, B);
        g.beginPath();
        g.rect(q.x, q.y, B.cw, B.ch);
        const cf = g.createLinearGradient(0, q.y, 0, q.y + B.ch);
        cf.addColorStop(0, shade(cellFill[rColor(n)], 1.18));
        cf.addColorStop(1, shade(cellFill[rColor(n)], 0.78));
        g.fillStyle = cf;
        g.fill();
        txt(g, String(n), q.x + B.cw / 2, q.y + B.ch / 2 + 12, 32, "#fff", { align: "center", weight: 800, emboss: true });
      }
      for (let c = 1; c <= 3; c++) {
        const y = B.y0 + (3 - c) * B.ch;
        txt(g, "2:1", L + 12 * B.cw + B.colW / 2, y + B.ch / 2 + 10, 26, "#fff", { align: "center", weight: 800, emboss: true });
      }
      const bottom = B.y0 + 3 * B.ch;
      ["1st 12", "2nd 12", "3rd 12"].forEach((s, i) => txt(g, s, L + (4 * i + 2) * B.cw, bottom + B.dzH / 2 + 10, 28, "#fff", { align: "center", weight: 700, font: "serif", emboss: true }));
      EVEN_SPOTS.forEach((s, i) => {
        const cx = L + (2 * i + 1) * B.cw;
        const cy = bottom + B.dzH + B.emH / 2;
        if (s === "red" || s === "black") {
          g.beginPath();
          g.moveTo(cx, cy - 22);
          g.lineTo(cx + 34, cy);
          g.lineTo(cx, cy + 22);
          g.lineTo(cx - 34, cy);
          g.closePath();
          g.fillStyle = s === "red" ? "#c3122c" : "#101014";
          g.fill();
          g.lineWidth = 2;
          g.strokeStyle = "#fff";
          g.stroke();
        } else txt(g, EVEN_LABEL[s], cx, cy + 10, 28, "#fff", { align: "center", weight: 700, font: "serif", emboss: true });
      });
      // the grid lines: gold leaf on a dark bed (an inlay, not a print)
      g.strokeStyle = gold;
      g.lineWidth = 2.5;
      g.beginPath();
      g.rect(B.x0, B.y0, B.zw + 12 * B.cw + B.colW, 3 * B.ch);
      for (let c = 0; c <= 12; c++) {
        g.moveTo(L + c * B.cw, B.y0);
        g.lineTo(L + c * B.cw, bottom);
      }
      for (let r = 1; r < 3; r++) {
        g.moveTo(L, B.y0 + r * B.ch);
        g.lineTo(L + 12 * B.cw + B.colW, B.y0 + r * B.ch);
      }
      if (B.us) {
        g.moveTo(B.x0, B.y0 + 1.5 * B.ch);
        g.lineTo(L, B.y0 + 1.5 * B.ch);
      }
      g.rect(L, bottom, 12 * B.cw, B.dzH + B.emH);
      for (let i = 1; i < 3; i++) {
        g.moveTo(L + 4 * i * B.cw, bottom);
        g.lineTo(L + 4 * i * B.cw, bottom + B.dzH);
      }
      g.moveTo(L, bottom + B.dzH);
      g.lineTo(L + 12 * B.cw, bottom + B.dzH);
      for (let i = 1; i < 6; i++) {
        g.moveTo(L + 2 * i * B.cw, bottom + B.dzH);
        g.lineTo(L + 2 * i * B.cw, bottom + B.dzH + B.emH);
      }
      g.save();
      g.lineWidth = 6;
      g.strokeStyle = "rgba(0,0,0,.42)";
      g.stroke();
      g.restore();
      const gline = g.createLinearGradient(0, B.y0, 0, bottom + B.dzH + B.emH);
      gline.addColorStop(0, shade(gold, 1.35));
      gline.addColorStop(0.5, gold);
      gline.addColorStop(1, shade(gold, 0.8));
      g.strokeStyle = gline;
      g.stroke();
      txt(g, "LAST NUMBERS", B.x0, 70, 18, rgba(th.accent_hi || th.accent, 0.7), { weight: 800, shadow: false, spacing: 3 });
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const wheel = rouletteWheel(S);
      const N = wheel.length;
      const seg = TAU / N;
      const B = rouletteBoard(N === 38);
      // the sheen over the wheel (the head spins in its own layer underneath)
      const sheen = g.createRadialGradient(R_CX - 110, R_CY - 140, 10, R_CX, R_CY, R_HEAD);
      sheen.addColorStop(0, "rgba(255,255,255,.16)");
      sheen.addColorStop(0.5, "rgba(255,255,255,.03)");
      sheen.addColorStop(1, "rgba(0,0,0,.18)");
      circle(g, R_CX, R_CY, R_HEAD);
      g.fillStyle = sheen;
      g.fill();
      const resPocket = obj(obj(st.result).outcome).pocket;
      const landed = st.phase === "result" && typeof resPocket === "number" ? resPocket : null;
      const showResult = landed != null;
      // the number, big, on the cone (drawn once: the table layer doesn't redraw while the wheel turns)
      if (showResult) {
        const n = wheel[landed];
        const col = { red: "#d0182f", black: "#1b1b22", green: "#0e9a4c" }[rColor(n)];
        g.save();
        glowFx(g, "disc116", R_CX - 116, R_CY - 116, 232, 232, rgba(th.accent, 0.8), 40, (m) => {
          circle(m, R_CX, R_CY, 116);
          m.fillStyle = "#000";
          m.fill();
        });
        circle(g, R_CX, R_CY, 116);
        g.fillStyle = col;
        g.fill();
        g.lineWidth = 6;
        g.strokeStyle = th.accent;
        g.stroke();
        g.restore();
        txt(g, rLabel(n), R_CX, R_CY + 40, 120, "#fff", { align: "center", weight: 850 });
      }
      // last numbers
      const hist = arr(st.history).filter((h) => h.game === "roulette" && h.outcome).slice(-13).reverse();
      let hx = B.x0 + 30;
      hist.forEach((h, i) => {
        const n = num(obj(h.outcome).number);
        const r = i === 0 ? 30 : 23;
        circle(g, hx, 112, r);
        g.fillStyle = { red: "#c3122c", black: "#1b1b22", green: "#0b8a43" }[rColor(n)];
        g.fill();
        g.lineWidth = i === 0 ? 4 : 2;
        g.strokeStyle = i === 0 ? th.accent : "rgba(255,255,255,.35)";
        g.stroke();
        txt(g, rLabel(n), hx, 112 + r * 0.36, r * 0.95, "#fff", { align: "center", weight: 800, shadow: false });
        hx += r + (i === 0 ? 36 : 30);
      });
      // the headline
      const head = headline(S, t, (ph) => {
        if (ph === "spinning") return { title: "SPINNING…", sub: "No more bets — watch the wheel", tone: th.accent_hi };
                if (ph === "result") {
          const n = wheel[landed];
          const words = n === 0 || n === 37 ? "ZERO" : `${rColor(n).toUpperCase()} · ${n % 2 ? "ODD" : "EVEN"} · ${n <= 18 ? "LOW" : "HIGH"}`;
          const hh = headline(S, t);
          return { ...hh, title: `${rLabel(n)} ${words}`, tone: { red: "#ff5a6e", black: INK1, green: "#3ddc84" }[rColor(n)] };
        }
        return null;
      });
      drawHeadline(S, g, B.x0, 160, 740, t, head, { size: 58 });
      // winning areas
      const win = showResult ? wheel[landed] : null;
      if (win != null) {
        const pulse = 0.6 + 0.4 * Math.sin(t * 6);
        const L = B.x0 + B.zw;
        const bottom = B.y0 + 3 * B.ch;
        if (win === 0 || win === 37) {
          const h = (3 * B.ch) / (B.us ? 2 : 1);
          glowBox(g, B.x0, B.us ? (win === 37 ? B.y0 : B.y0 + h) : B.y0, B.zw, h, "#ffffff", pulse, 4);
        } else {
          const q = numCell(win, B);
          glowBox(g, q.x, q.y, B.cw, B.ch, "#ffffff", pulse, 4);
          const d = Math.ceil(win / 12);
          glowBox(g, L + 4 * (d - 1) * B.cw, bottom, 4 * B.cw, B.dzH, th.accent, pulse * 0.7, 4);
          glowBox(g, L + 12 * B.cw, B.y0 + q.r * B.ch, B.colW, B.ch, th.accent, pulse * 0.7, 4);
          EVEN_SPOTS.forEach((s, i) => {
            if (rouletteCovers(s).includes(win)) glowBox(g, L + 2 * i * B.cw, bottom + B.dzH, 2 * B.cw, B.emH, th.accent, pulse * 0.7, 4);
          });
        }
      }
      // everyone's chips on the layout
      const sb = obj(st.spot_bets);

      const ma = momentAge(S);
      const DEALER = [B.x0 - 20, B.y0 - 70]; // the croupier's side of the layout, by the wheel
      for (const spot of Object.keys(sb)) {
        const p = rouletteSpotXY(spot, B);
        if (!p) continue;
        const covers = rouletteCovers(spot);
        const wins = win != null && covers.includes(win);
        if (win != null && !wins && ma == null) {
          spotChips(S, g, spot, sb[spot], p[0], p[1], t, { r: 21, dim: true });
          continue;
        }
        spotChips(S, g, spot, sb[spot], p[0], p[1], t, { r: 21, glow: wins ? th.accent : null, sweepAt: win != null && !wins ? MOMENT.SWEEP0 : null, to: DEALER });
        if (wins && ma != null) {
          // the payout (stake × the spot's odds: 35, 17, 11, 8, 6 (top line), 5, 2, 1) pushed from the dealer
          const mult = covers.length === 5 ? 6 : 36 / covers.length - 1;
          const list = arr(sb[spot]);
          const nn = list.length;
          list.forEach((e, i) => {
            const px = p[0] + (i - (nn - 1) / 2) * 21 * 0.9 + 24;
            const py = p[1] + (i - (nn - 1) / 2) * 21 * 0.25 - 8;
            flight(S, `pay|${spot}|${e.seat}`, { amount: Math.round(num(e.amount) * mult), owner: e.color || "#f0f0f0", r: 21, from: DEALER, to: [px, py], at: 0.3, dur: 0.55, glow: th.accent });
          });
        }
      }
      // the foot: totals and winners
      const total = Object.values(obj(st.totals)).reduce((a, b) => a + num(b), 0);
      const fy = B.y0 + 3 * B.ch + B.dzH + B.emH + 34;
      txt(g, "ON THE TABLE", B.x0, fy + 22, 20, INK3, { weight: 800, shadow: false });
      txt(g, fmt(S, total), B.x0, fy + 82, 56, INK1, { font: "mono", weight: 750 });
      const house = obj(st.house);
      txt(g, `Limits ${fmt(S, num(house.min_bet, 1))} – ${fmt(S, num(house.max_bet, 500))} · straight up pays 35 to 1`, B.x0, fy + 122, 22, INK2, { weight: 600 });
      if (st.phase === "result" && showResult) winnersCard(S, g, B.x0 + 400, fy - 6, 380, t, { instant: true, max: 3 });
    },
  });

  // ================================================================================================ BIG SIX
  const BX = 470;
  const BY = 500;
  const BR = 410;
  const B6_SEG = TAU / 54;
  const B6_HUB = 170;

  /**
   * The wheel's rotation (radians, clockwise) on the engine's clock — apps/casino_bigsix.py wheel_angle, 1:1:
   * φ(ts) = end − travel·(1 − ts/stop)², ts = since_lock − LOCK, with the round's `end` / `travel` from tv.reveal.
   * During the lock second (the panel shows NO MORE BETS) the TV wheel spins up from where it rested to the
   * panel's start angle with the panel's launch speed (a Hermite ramp), so it never jumps. {phi, ts, stop}
   */
  /** apps/casino_bigsix.py wheel_angle for ts ≥ 0, from the round's end angle and travel. */
  function b6Phi(end, travel, stop, ts) {
    const u = clamp(ts / stop, 0, 1);
    return end - travel * (1 - u) * (1 - u);
  }
  function b6Now(S, T) {
    const fx = S.fx;
    const rv = revealOf(S, "bigsix");
    if (rv) {
      const lock = num(rv.lock_s, LOCK);
      const stop = num(rv.stop_s, 6.4);
      const end = num(rv.end);
      const travel = num(rv.travel);
      const ts = sinceLockOf(rv, T) - lock;
      if (fx.rvRound !== rv.round) {
        fx.rvRound = rv.round;
        fx.from = fx.phi == null || ts > 0 ? end - travel : fx.phi;
      }
      let phi;
      let w; // angular speed (rad/s): the motion blur's weight
      const V = (2 * travel) / stop;
      if (ts >= 0) {
        phi = b6Phi(end, travel, stop, ts);
        w = ts < stop ? V * (1 - ts / stop) : 0;
      } else {
        const s = clamp((ts + lock) / lock, 0, 1);
        let d = mod(end - travel - fx.from, TAU);
        while (d < V * lock * 0.5) d += TAU;
        phi = fx.from + d * (3 * s * s - 2 * s * s * s) + V * lock * (s * s * s - s * s);
        w = Math.abs((d * (6 * s - 6 * s * s) + V * lock * (3 * s * s - 2 * s)) / lock);
      }
      fx.phi = phi;
      return { phi, ts, stop, w, end, travel };
    }
    if (fx.phi == null) {
      const last = arr(S.st.history).filter((h) => h.game === "bigsix").slice(-1)[0];
      const seg = obj(last && last.outcome).segment;
      fx.phi = typeof seg === "number" ? -(seg + 0.5) * B6_SEG : 0;
    }
    return { phi: fx.phi, ts: null, stop: 6.4, w: 0 };
  }

  /**
   * The flapper (the leather clapper at 12 o'clock), in radians: a peg leans it over as it comes (the panel's kick:
   * the last 30 % of each segment before the peg, the same moments as the panel's), it snaps off the peg and
   * rings back with a damped wobble — timed from the moment that peg passed, solved from the wheel's own law —
   * and settles once the wheel has stopped. Pure function of the shared clock.
   */
  const FLAP = { PUSH: 0.34, ZONE: 0.3, RING: 0.2, DECAY: 11, FREQ: 34 };
  function b6Flap(m) {
    if (m.ts == null || m.ts < 0) return 0;
    const tsc = Math.min(m.ts, m.stop);
    const phi = b6Phi(m.end, m.travel, m.stop, tsc);
    const f = (mod(-phi, TAU) / B6_SEG) % 1;
    let bend = f < FLAP.ZONE ? FLAP.PUSH * (1 - f / FLAP.ZONE) : 0;
    // when did the last peg pass? φ crossed the boundary φb = SEG·⌊φ/SEG⌋: solve φ(t) = φb for t (φ is a parabola)
    const pb = B6_SEG * Math.floor(phi / B6_SEG);
    const q = (m.end - pb) / m.travel;
    if (q >= 0 && q <= 1) {
      const tb = (1 - Math.sqrt(q)) * m.stop;
      const dt = tsc - tb;
      if (dt >= 0 && dt < 0.6) bend -= FLAP.PUSH * FLAP.RING * 2 * Math.exp(-dt * FLAP.DECAY) * Math.sin(dt * FLAP.FREQ + 0.6);
    }
    if (m.ts > m.stop) bend *= Math.exp(-(m.ts - m.stop) * 8); // the wheel has stopped: the flapper falls straight
    return bend;
  }

  /** The wheel, sharp (its own canvas, drawn once). */
  function b6WheelDraw(g) {
    for (let i = 0; i < 54; i++) {
      const s = B6_BY[B6_WHEEL[i]];
      const a0 = i * B6_SEG - Math.PI / 2;
      g.beginPath();
      g.moveTo(0, 0);
      g.arc(0, 0, BR, a0, a0 + B6_SEG);
      g.closePath();
      const gg = g.createRadialGradient(0, 0, 160, 0, 0, BR);
      gg.addColorStop(0, shade(s.col, 0.55));
      gg.addColorStop(1, s.col);
      g.fillStyle = gg;
      g.fill();
      g.lineWidth = 2;
      g.strokeStyle = "rgba(0,0,0,.45)";
      g.stroke();
      g.save();
      g.rotate((i + 0.5) * B6_SEG);
      const label = s.sym === "joker" ? "J" : s.sym === "logo" ? "★" : s.sym;
      txt(g, label, 0, -BR + 70, s.sym.length > 1 && label.length > 1 ? 30 : 38, s.sym === "logo" ? "#3a2c08" : "#ffffff", { align: "center", weight: 850 });
      g.restore();
    }
    // the pegs: turned brass studs on every divider, catching the lamp
    for (let i = 0; i < 54; i++) {
      const a = i * B6_SEG - Math.PI / 2;
      const x = Math.cos(a) * (BR - 12);
      const y = Math.sin(a) * (BR - 12);
      g.save();
      g.shadowColor = "rgba(0,0,0,.6)";
      g.shadowBlur = 4;
      g.shadowOffsetY = 2;
      circle(g, x, y, 7.5);
      const pg = g.createRadialGradient(x - 2.5, y - 3, 0.5, x, y, 7.5);
      pg.addColorStop(0, "#fff6d0");
      pg.addColorStop(0.45, "#e6c46a");
      pg.addColorStop(1, "#7a5418");
      g.fillStyle = pg;
      g.fill();
      g.restore();
    }
    circle(g, 0, 0, B6_HUB);
    const hg = g.createRadialGradient(-40, -50, 10, 0, 0, B6_HUB);
    hg.addColorStop(0, "#3a3046");
    hg.addColorStop(1, "#141018");
    g.fillStyle = hg;
    g.fill();
    g.lineWidth = 8;
    g.strokeStyle = "#d9b45a";
    g.stroke();
    for (let i = 0; i < 12; i++) {
      g.save();
      g.rotate((i / 12) * TAU);
      rr(g, -3, -165, 6, 60, 3);
      g.fillStyle = "rgba(217,180,90,.5)";
      g.fill();
      g.restore();
    }
  }
  function b6Wheel(S) {
    const key = `${wheelK()}`;
    if (S.fx.img && S.fx.img.key === key) return S.fx.img.c;
    const D = 2 * BR + 10;
    const m = makeCanvas(D, D, wheelK());
    m.g.translate(D / 2, D / 2);
    b6WheelDraw(m.g);
    S.fx.img = { key, c: m.c };
    return m.c;
  }
  /**
   * The wheel at speed: the sharp wheel smeared along its turn (the average of 12 copies over ~1.3 segments), drawn
   * once at half resolution — it is a blur, so nothing is lost — and cross-faded in by the wheel's speed.
   */
  const B6_BLUR_K = 0.5;
  function b6Blur(S) {
    if (S.fx.blur) return S.fx.blur;
    const D = 2 * BR + 10;
    const src = b6Wheel(S);
    const m = makeCanvas(D, D, B6_BLUR_K);
    const g = m.g;
    const n = 12;
    for (let i = 0; i < n; i++) {
      g.save();
      g.translate(D / 2, D / 2);
      g.rotate(((i / (n - 1)) - 0.5) * B6_SEG * 1.3);
      g.globalAlpha = 1 / (i + 1);
      g.drawImage(src, -D / 2, -D / 2, D, D);
      g.restore();
    }
    S.fx.blur = m.c;
    return m.c;
  }
  /** The winning segment lit at the top once the wheel has stopped: a small sprite turned with the wheel. */
  const B6_LIT = { w: 150, h: BR - B6_HUB + 40 };
  function b6LitDraw(g) {
    const cx = B6_LIT.w / 2;
    const cy = BR + 20; // the wheel's centre, below the sprite
    const a0 = -Math.PI / 2 - B6_SEG / 2;
    const a1 = -Math.PI / 2 + B6_SEG / 2;
    g.beginPath();
    g.arc(cx, cy, BR - 2, a0, a1);
    g.arc(cx, cy, B6_HUB + 4, a1, a0, true);
    g.closePath();
    g.save();
    g.shadowColor = "#fff2c0";
    g.shadowBlur = 18;
    g.lineWidth = 5;
    g.strokeStyle = "#fff2c0";
    g.stroke();
    g.restore();
    g.fillStyle = "rgba(255,246,214,.26)";
    g.fill();
  }

  const bigsix = makeScene({
    id: "casino-bigsix",
    app: "casino_bigsix",
    init(S) {
      S.fx = { phi: null };
    },
    // the wheel (pre-rendered once, spun by a CSS rotate), its motion-blurred twin, the lit segment and the flapper
    layers(S, root) {
      const k = wheelK();
      const D = 2 * BR + 10;
      S.L.wheel = layer(root, BX - D / 2, BY - D / 2, D, D, k, true);
      S.L.blur = layer(root, BX - D / 2, BY - D / 2, D, D, B6_BLUR_K, true);
      S.L.blur.c.style.display = "none";
      S.L.blur.cache = { display: "none" };
      S.L.lit = layer(root, BX - B6_LIT.w / 2, BY - BR - 20, B6_LIT.w, B6_LIT.h, k, true, true);
      S.L.lit.c.style.transformOrigin = `${B6_LIT.w / 2}px ${BR + 20}px`;
      S.L.lit.c.style.display = "none";
      S.L.lit.cache = { display: "none" };
      b6LitDraw(S.L.lit.g);
      // the flapper: a tapered leather tongue on a brass pivot, its tip reaching between the pegs
      S.L.clap = layer(root, BX - 30, BY - BR - 60, 60, 128, k, true, true);
      S.L.clap.c.style.transformOrigin = "30px 16px";
      const g = S.L.clap.g;
      g.save();
      g.translate(30, 16);
      g.shadowColor = "rgba(0,0,0,.55)";
      g.shadowBlur = 8;
      g.shadowOffsetY = 4;
      g.beginPath();
      g.moveTo(-15, 0);
      g.quadraticCurveTo(-13, 50, -3, 84);
      g.lineTo(3, 84);
      g.quadraticCurveTo(13, 50, 15, 0);
      g.closePath();
      const lg = g.createLinearGradient(-15, 0, 15, 0);
      lg.addColorStop(0, "#7a0f1c");
      lg.addColorStop(0.45, "#e0303f");
      lg.addColorStop(0.6, "#ff6070");
      lg.addColorStop(1, "#8c1422");
      g.fillStyle = lg;
      g.fill();
      g.shadowColor = "transparent";
      g.lineWidth = 1.5;
      g.strokeStyle = "rgba(255,210,150,.55)"; // a gold stitch down the edge
      g.setLineDash([4, 4]);
      g.beginPath();
      g.moveTo(-9, 8);
      g.quadraticCurveTo(-8, 48, -2, 76);
      g.moveTo(9, 8);
      g.quadraticCurveTo(8, 48, 2, 76);
      g.stroke();
      g.setLineDash([]);
      // the brass pivot cap
      circle(g, 0, 0, 14);
      const pg = g.createRadialGradient(-4, -5, 1, 0, 0, 14);
      pg.addColorStop(0, "#fff6d0");
      pg.addColorStop(0.5, "#e6c46a");
      pg.addColorStop(1, "#6a4712");
      g.fillStyle = pg;
      g.fill();
      circle(g, 0, 0, 4);
      g.fillStyle = "#4a3210";
      g.fill();
      g.restore();
      S.L.clap.show();
    },
    layersRedraw(S) {
      const l = S.L.wheel;
      l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
      l.g.clearRect(0, 0, l.w, l.h);
      l.g.drawImage(b6Wheel(S), 0, 0, l.w, l.h);
      l.show();
      S.fx.blurDrawn = false; // the blurred twin is made the first time the wheel runs fast
    },
    move(S) {
      const m = b6Now(S, S.T);
      const tf = `rotate(${((m.phi * 180) / Math.PI).toFixed(3)}deg)`;
      S.L.wheel.c.style.transform = tf;
      // motion blur by speed: blurred above 4.7 rad/s, sharp below 2.2; only the visible layer is in the tree
      const b = clamp((m.w - 2.2) / 2.5, 0, 1);
      if (b > 0) {
        if (!S.fx.blurDrawn) {
          const l = S.L.blur;
          l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
          l.g.clearRect(0, 0, l.w, l.h);
          l.g.drawImage(b6Blur(S), 0, 0, l.w, l.h);
          l.show();
          S.fx.blurDrawn = true;
        }
        moveLayer(S.L.blur, tf, b.toFixed(3));
      } else hideLayer(S.L.blur);
      setStyle(S.L.wheel.c, "visibility", b >= 1 ? "hidden" : "visible", (S.L.wheel.cache = S.L.wheel.cache || {}));
      // the flapper on the pegs
      const flap = b6Flap(m);
      const ft = `rotate(${((-flap * 180) / Math.PI).toFixed(2)}deg)`;
      if (S.fx.flapTf !== ft) S.L.clap.c.style.transform = S.fx.flapTf = ft;
      S.fx.stopped = m.ts != null && m.ts >= m.stop;
      S.fx.under = mod(Math.floor(mod(-m.phi, TAU) / B6_SEG), 54);
      const rv = revealOf(S, "bigsix");
      const seg = rv ? obj(rv.outcome).segment : null;
      // the winning segment lights up under the flapper as the wheel stops, and glows on through the result
      if (typeof seg === "number" && S.fx.stopped) {
        const a = m.ts - m.stop;
        const op = Math.min(1, a / 0.25) * (0.7 + 0.3 * Math.cos(a * 4.2));
        moveLayer(S.L.lit, `rotate(${(((m.phi + (seg + 0.5) * B6_SEG) * 180) / Math.PI).toFixed(3)}deg)`, op.toFixed(3));
      } else hideLayer(S.L.lit);
      if (typeof seg !== "number") stampMove(S, "stamp", 0, 0, null);
      else {
        const i = B6.findIndex((x) => x.sym === B6_WHEEL[seg]);
        const [x, y] = b6Tile(Math.max(0, i));
        stampPaint(S, "stamp", "WIN", S.th.accent);
        stampMove(S, "stamp", x + 196, y + 64, m.ts - m.stop, 104, -0.2);
      }
    },
    overlays(S, root) {
      stampLayers(S, root, "stamp");
    },
    key: (S) => (S.fx.stopped ? `stop${S.fx.under}` : ""),
    slowHz: (S) => (S.st.phase === "betting" && S.st.ends_in != null ? 1 : 0),
    bg(S, g) {
      const th = S.th;
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 1150, 480, 900, 36);
      // the wheel's housing
      circle(g, BX, BY, BR + 52);
      const wg = g.createRadialGradient(BX - 100, BY - 120, 60, BX, BY, BR + 52);
      wg.addColorStop(0, "#6a4022");
      wg.addColorStop(1, "#2a160a");
      g.fillStyle = wg;
      g.shadowColor = "rgba(0,0,0,.6)";
      g.shadowBlur = 40;
      g.fill();
      g.shadowBlur = 0;
      circle(g, BX, BY, BR + 6);
      g.lineWidth = 8;
      g.strokeStyle = "#d9b45a";
      g.stroke();
      txt(g, "BIG SIX", B6_BX, 92, 44, th.accent, { weight: 850, font: "serif", gold: goldOn(), spacing: 3 });
      txt(g, "THE MONEY WHEEL · 54 SEGMENTS", B6_BX + 2, 128, 22, INK2, { weight: 700 });
      B6.forEach((s, i) => {
        const [x, y] = b6Tile(i);
        feltBox(g, th, x, y, B6_TW, 140, { fill: "rgba(0,0,0,.22)" });
        rr(g, x + 14, y + 14, 84, 112, 14);
        g.fillStyle = s.col;
        g.fill();
        const label = s.sym === "joker" ? "JOKER" : s.sym === "logo" ? "LOGO" : s.sym;
        txt(g, label, x + 56, y + 88, label.length > 2 ? 20 : 54, s.sym === "logo" ? "#3a2c08" : "#fff", { align: "center", weight: 850 });
        txt(g, `PAYS ${s.pays}:1`, x + 112, y + 46, 24, INK1, { weight: 800 });
        txt(g, `${s.n} of 54`, x + 112, y + 76, 19, INK3, { weight: 700 });
      });
    },
    draw(S, g, t) {
      const st = S.st;
      const fx = S.fx;
      const th = S.th;
      // bulbs round the housing (lit, alternate, all on at the result)
      for (let i = 1; i < 36; i++) {
        const a = (i / 36) * TAU; // (none at 12 o'clock: the flapper's pivot sits there)
        const lit = st.phase === "result" || i % 2 === 0;
        circle(g, BX + Math.sin(a) * (BR + 30), BY - Math.cos(a) * (BR + 30), lit ? 8 : 6);
        g.fillStyle = lit ? "#fff2c0" : "rgba(255,220,140,.25)";
        g.fill();
      }
      const sheen = g.createRadialGradient(BX - 140, BY - 160, 20, BX, BY, BR);
      sheen.addColorStop(0, "rgba(255,255,255,.18)");
      sheen.addColorStop(1, "rgba(0,0,0,.15)");
      circle(g, BX, BY, BR);
      g.fillStyle = sheen;
      g.fill();
      // the hub: the symbol under the clapper once the wheel has stopped (as on the panel)
      const resSeg = obj(obj(st.result).outcome).segment;
      const landed = st.phase === "result" && typeof resSeg === "number" ? resSeg : null;
      const stopSeg = landed != null ? landed : fx.stopped ? fx.under : null;
      const sym = stopSeg != null ? B6_BY[B6_WHEEL[stopSeg]] : null;
      txt(g, sym ? (sym.sym === "joker" ? "JOKER" : sym.sym === "logo" ? "LOGO" : sym.sym) : "BIG SIX", BX, BY + (sym ? 30 : 14), sym ? (sym.sym.length > 2 ? 52 : 110) : 46, sym ? sym.col : th.accent, { align: "center", weight: 850, glow: sym ? sym.col : null });
      const showRes = landed != null;
      // headline
      drawHeadline(S, g, B6_BX, 150, 2 * B6_TW + B6_GAP, t, headline(S, t, (ph) => {
        if (ph === "spinning") return { title: "SPINNING…", sub: "Watch the flapper on the pegs", tone: th.accent_hi };
        if (ph === "result") {
          const s = B6_BY[B6_WHEEL[landed]];
          return { ...headline(S, t), title: `${s.sym === "joker" ? "JOKER" : s.sym === "logo" ? "LOGO" : s.sym} PAYS ${s.pays}:1`, tone: s.col };
        }
        return null;
      }), { size: 50 });
      const sb = obj(st.spot_bets);
      const winSym = showRes ? B6_WHEEL[landed] : null;
      B6.forEach((s, i) => {
        const [x, y] = b6Tile(i);
        const isWin = winSym === s.sym;
        if (isWin) glowBox(g, x, y, B6_TW, 140, s.col, 1);
        const tot = num(obj(st.totals)[s.id]);
        if (tot) txt(g, fmt(S, tot), x + 112, y + 118, 19, INK2, { font: "mono", weight: 700 });
        spotChips(S, g, s.id, sb[s.id], x + 202, y + 104, t, { r: 22, glow: isWin ? th.accent : null, dim: winSym != null && !isWin });
      });
      if (showRes) winnersCard(S, g, B6_BX + B6_TW + B6_GAP, 740, B6_TW, t, { instant: true, max: 2 });
    },
  });
  // the betting board: two columns of tiles right of the wheel, inside the felt (they used to run into the rail)
  const B6_BX = 962;
  const B6_TW = 250;
  const B6_GAP = 12;
  function b6Tile(i) {
    if (i === 6) return [B6_BX, 740];
    return [B6_BX + (i % 2) * (B6_TW + B6_GAP), 250 + Math.floor(i / 2) * 160];
  }

  // ================================================================================================ 7 UP 7 DOWN
  const PIPS = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]],
    5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] }; // fmt: skip
  /** A die (face 1–6, s px, rot rad), stamped from a sprite drawn once per size / face / glow. o: {glow} */
  const dieCache = new Map();
  function die(g, x, y, s, face, rot, o) {
    o = o || {};
    const k = chipK(g);
    const key = `${s}|${face}|${o.glow || ""}|${k}`;
    let sp = dieCache.get(key);
    if (!sp) {
      if (dieCache.size > 120) dieCache.clear();
      const D = Math.ceil(s * 1.6);
      const m = makeCanvas(D, D, k);
      dieRaw(m.g, D / 2, D / 2, s, face, 0, o);
      sp = { c: m.c, D };
      dieCache.set(key, sp);
    }
    g.save();
    g.translate(x, y);
    if (rot) g.rotate(rot);
    g.drawImage(sp.c, -sp.D / 2, -sp.D / 2, sp.D, sp.D);
    g.restore();
  }
  function dieRaw(g, x, y, s, face, rot, o) {
    o = o || {};
    g.save();
    g.translate(x, y);
    g.rotate(rot || 0);
    g.shadowColor = "rgba(0,0,0,.55)";
    g.shadowBlur = s * 0.25;
    g.shadowOffsetY = s * 0.08;
    rr(g, -s / 2, -s / 2, s, s, s * 0.2);
    const gr = g.createLinearGradient(-s / 2, -s / 2, s / 2, s / 2);
    gr.addColorStop(0, "#ff4a5a");
    gr.addColorStop(1, "#a8101f");
    g.fillStyle = gr;
    g.fill();
    g.shadowBlur = 0;
    g.shadowOffsetY = 0;
    rr(g, -s / 2 + s * 0.06, -s / 2 + s * 0.05, s * 0.88, s * 0.4, s * 0.16);
    g.fillStyle = "rgba(255,255,255,.14)";
    g.fill();
    if (o.glow) {
      rr(g, -s / 2, -s / 2, s, s, s * 0.2);
      g.lineWidth = 5;
      g.strokeStyle = o.glow;
      g.shadowColor = o.glow;
      g.shadowBlur = 24;
      g.stroke();
      g.shadowBlur = 0;
    }
    for (const [px, py] of PIPS[face] || PIPS[1]) {
      circle(g, px * s * 0.27, py * s * 0.27, s * 0.085);
      g.fillStyle = "#ffffff";
      g.fill();
    }
    g.restore();
  }

  const TRAY = { x: 70, y: 180, w: 900, h: 400 };
  // apps/casino_sevens.py dice_at, ported: panel px → stage px (one LED = SEV.SC px, the 12 px die = 188 px)
  const SEV = { REST: [[3, 1], [17, 1]], ROLL_Y: 10, DIE: 12, SC: 15.7, X0: 268.7, Y0: 128.8 };
  /** [{x, y, face, h}] in panel px for both dice, `sl` s after the lock (rv: the TV reveal). */
  function sevensDice(rv, sl) {
    const final = arr(obj(rv.outcome).dice);
    const u = clamp((sl - num(rv.lock_s, LOCK)) / num(rv.spin_s, 2.6), 0, 1);
    return [0, 1].map((i) => {
      const lag = 0.06 * i;
      const k = clamp((u - lag) / (1 - lag), 0, 1);
      const hop = 9 * Math.exp(-2.6 * k) * Math.abs(Math.cos(Math.PI * 2.5 * k));
      const ease = 1 - Math.pow(1 - k, 3);
      const x = SEV.REST[i][0] + (26 - 6 * i) * (1 - ease);
      const y = SEV.ROLL_Y - hop;
      const squash = hop < 0.8 && k < 0.92 && k > 0.05 ? SEV.DIE - 2 : SEV.DIE;
      const face = k >= 0.86 ? num(final[i], 1) : num(arr(arr(rv.faces)[i])[Math.floor(18 * (1 - (1 - k) * (1 - k)))], 1);
      return { x, y: y + (SEV.DIE - squash), face, h: squash, k };
    });
  }
  const restDice = (faces) => [0, 1].map((i) => ({ x: SEV.REST[i][0], y: SEV.ROLL_Y, face: num(faces[i], i ? 4 : 3), h: SEV.DIE, k: 1 }));
  const sevens = makeScene({
    id: "casino-sevens",
    app: "casino_sevens",
    init(S) {
      S.fx = { faces: [0, 0] };
    },
    layers(S, root) {
      const box = document.createElement("div");
      const bs = box.style;
      bs.position = "absolute";
      bs.left = `${TRAY.x}px`;
      bs.top = "0px";
      bs.width = `${TRAY.w}px`;
      bs.height = `${TRAY.y + TRAY.h}px`;
      bs.overflow = "hidden";
      bs.pointerEvents = "none";
      root.appendChild(box);
      const D = SEV.DIE * SEV.SC;
      S.L.dice = [0, 1].map(() => {
        const l = layer(box, 0, 0, D + 24, D + 24, wheelK(), true);
        l.c.style.transformOrigin = "0 0";
        return l;
      });
    },
    overlays(S, root) {
      stampLayers(S, root, "stamp");
    },
    move(S) {
      const st = S.st;
      const rv = revealOf(S, "sevens");
      const lastHist = arr(st.history).filter((h) => h.game === "sevens" && h.outcome).slice(-1)[0];
      let dice;
      let alpha = 1;
      if (rv) {
        const sl = sinceLockOf(rv, S.T);
        const lock = num(rv.lock_s, LOCK);
        if (sl < lock) {
          dice = restDice(arr(obj(lastHist && lastHist.outcome).dice));
          alpha = 1 - clamp(sl / 0.3, 0, 1); // the old dice are picked up during NO MORE BETS
        } else {
          dice = sevensDice(rv, sl);
          alpha = clamp((sl - lock) / 0.12, 0, 1);
        }
        const z = SEVENS.findIndex((x) => x.id === obj(rv.outcome).zone);
        stampPaint(S, "stamp", "WIN", S.th.accent);
        stampMove(S, "stamp", 60 + Math.max(0, z) * 478 + 380, 806, sl - lock - num(rv.spin_s, 2.6), 112, 0.16);
      } else {
        dice = restDice(arr(obj(lastHist && lastHist.outcome).dice));
        stampMove(S, "stamp", 0, 0, null);
      }
      dice.forEach((d, i) => {
        const l = S.L.dice[i];
        if (S.fx.faces[i] !== d.face) {
          S.fx.faces[i] = d.face;
          l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
          l.g.clearRect(0, 0, l.w, l.h);
          die(l.g, l.w / 2, l.h / 2, SEV.DIE * SEV.SC, d.face, 0);
          l.show();
        }
        const x = SEV.X0 + d.x * SEV.SC - TRAY.x - 12;
        const y = SEV.Y0 + d.y * SEV.SC - 12;
        // the die tumbles as it rolls (a cosmetic turn that unwinds to square as it settles)
        const spin = d.k < 1 ? (1 - d.k) * (1 - d.k) * (i ? -9 : 11) : 0;
        l.c.style.transformOrigin = `${(l.w / 2).toFixed(1)}px ${(l.h / 2).toFixed(1)}px`;
        l.c.style.transform = `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) rotate(${spin.toFixed(3)}rad) scale(1,${(d.h / SEV.DIE).toFixed(3)})`;
        l.c.style.opacity = alpha.toFixed(3);
      });
    },
    slowHz: (S) => (S.st.phase === "betting" && S.st.ends_in != null ? 1 : 0),
    bg(S, g) {
      const th = S.th;
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 760, 480, 1000, 36);
      rr(g, TRAY.x - 16, TRAY.y - 16, TRAY.w + 32, TRAY.h + 32, 34);
      const wg = g.createLinearGradient(0, TRAY.y - 16, 0, TRAY.y + TRAY.h + 16);
      wg.addColorStop(0, "#7a4a24");
      wg.addColorStop(1, "#3a2010");
      g.fillStyle = wg;
      g.fill();
      rr(g, TRAY.x, TRAY.y, TRAY.w, TRAY.h, 22);
      feltFill(g, { ...th, felt: shade(th.felt, 0.85) }, TRAY.x + TRAY.w / 2, TRAY.y + TRAY.h / 2, 600);
      txt(g, "7 UP 7 DOWN", TRAY.x + TRAY.w / 2, TRAY.y + TRAY.h / 2 + 30, 90, rgba(th.accent, 0.12), { align: "center", weight: 900, shadow: false });
      txt(g, "LAST ROLLS", 1020, 220, 20, INK3, { weight: 800, shadow: false });
      SEVENS.forEach((z, i) => {
        const x = 60 + i * 478;
        feltBox(g, th, x, 640, 456, 300, { fill: rgba(z.col, 0.16), stroke: z.col });
        txt(g, z.name, x + 30, 712, 52, "#fff", { weight: 900 });
        txt(g, z.sub, x + 30, 754, 26, INK2, { weight: 650 });
        txt(g, `PAYS ${i === 1 ? `${num(obj(S.st.rules).seven_pays, 4)} : 1` : z.pays}`, x + 30, 905, 28, th.accent, { weight: 850 });
      });
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const ph = st.phase;
      const cx = TRAY.x + TRAY.w / 2;
      const cy = TRAY.y + TRAY.h / 2;
      const out = obj(obj(st.result).outcome);
      const res = ph === "result" && Array.isArray(out.dice) ? out : null;
      if (res) txt(g, String(res.sum), cx, TRAY.y + 98, 110, "#fff", { align: "center", weight: 900, glow: (SEVENS.find((s) => s.id === res.zone) || SEVENS[0]).col });
      drawHeadline(S, g, 70, 40, 900, t, headline(S, t, (p) => {
        if (p === "spinning") return { title: "ROLLING…", sub: "Under, seven or over?", tone: th.accent_hi };
        if (p === "result" && res) {
          const z = SEVENS.find((s) => s.id === res.zone) || SEVENS[0];
          return { ...headline(S, t), title: `${res.sum} · ${z.name}`, tone: z.col };
        }
        return null;
      }), { size: 56 });
      // last rolls
      const hist = arr(st.history).filter((h) => h.game === "sevens" && h.outcome).slice(-8).reverse();
      hist.forEach((h, i) => {
        const o = obj(h.outcome);
        const y = 250 + i * 46;
        const d = arr(o.dice);
        if (d.length === 2) {
          die(g, 1040, y + 20, 36, d[0], 0);
          die(g, 1084, y + 20, 36, d[1], 0);
        }
        const z = SEVENS.find((s) => s.id === o.zone) || SEVENS[0];
        txt(g, String(o.sum), 1130, y + 34, 32, "#fff", { font: "mono", weight: 800 });
        pill(g, z.name, 1190, y + 22, 18, rgba(z.col, 0.85), "#fff");
      });
      const sb = obj(st.spot_bets);
      SEVENS.forEach((z, i) => {
        const x = 60 + i * 478;
        const isWin = res && res.zone === z.id;
        if (isWin) glowBox(g, x, 640, 456, 300, z.col, 1);
        const tot = num(obj(st.totals)[z.id]);
        if (tot) txt(g, `${fmt(S, tot)} on it`, x + 426, 712, 24, INK2, { align: "right", font: "mono", weight: 700 });
        spotChips(S, g, z.id, sb[z.id], x + 228, 820, t, { r: 34, glow: isWin ? th.accent : null, dim: res && !isWin });
      });
      if (res) winnersCard(S, g, 1020, 40, 480, t, { instant: true, max: 2 });
    },
  });

  // ================================================================================================ BACCARAT
  const BAC_SHOE = [1400, 160]; // the shoe sits right of the headline, by the banker
  const BAC_SLOTS = {
    player: { x: 80, w: 620, col: "#1f5fe0", name: "PLAYER" },
    banker: { x: 840, w: 620, col: "#d0182f", name: "BANKER" },
  };
  const BAC_BETS = [
    { id: "ppair", name: "P PAIR", x: 80, w: 220, col: "#1f5fe0", pays: "11 : 1" },
    { id: "player", name: "PLAYER", x: 300, w: 380, col: "#1f5fe0", pays: "1 : 1" },
    { id: "tie", name: "TIE", x: 680, w: 220, col: "#0e9a4c", pays: "8 : 1" },
    { id: "banker", name: "BANKER", x: 900, w: 380, col: "#d0182f", pays: "0.95 : 1" },
    { id: "bpair", name: "B PAIR", x: 1280, w: 220, col: "#d0182f", pays: "11 : 1" },
  ];
  function bacCardXY(side, i) {
    const s = BAC_SLOTS[side];
    if (i === 2) return [s.x + s.w - 120, 300, Math.PI / 2];
    return [s.x + 110 + i * 150, 300, 0];
  }
  /** casino/games/baccarat.py deal_times: when each card lands, seconds after the deal starts (lock + LOCK). */
  function bacDealTimes(o) {
    const out = [["player", 0, 0.3], ["banker", 0, 0.9], ["player", 1, 1.5], ["banker", 1, 2.1]];
    let t = 2.1;
    if (arr(o.player).length === 3) out.push(["player", 2, (t += 1.6)]);
    if (arr(o.banker).length === 3) out.push(["banker", 2, (t += 1.6)]);
    return out;
  }
  /** Seconds into the deal on the engine's clock (99 once the coup is settled), or null without a reveal. */
  function bacDealT(S) {
    const rv = revealOf(S, "baccarat");
    if (!rv) return null;
    return S.st.phase === "result" ? 99 : sinceLockOf(rv, S.T) - num(rv.lock_s, LOCK);
  }
  function bacWinSpots(out) {
    const w = String(out.winner || "");
    const s = new Set([w]);
    if (out.ppair) s.add("ppair");
    if (out.bpair) s.add("bpair");
    return s;
  }
  const baccarat = makeScene({
    id: "casino-baccarat",
    app: "casino_baccarat",
    bg(S, g) {
      const th = S.th;
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 760, 300, 1100, 36);
      for (const side of ["player", "banker"]) {
        const s = BAC_SLOTS[side];
        feltBox(g, th, s.x, 150, s.w, 300, { fill: rgba(s.col, 0.12), stroke: rgba(s.col, 0.9) });
        txt(g, s.name, s.x + s.w / 2, 190, 34, "#fff", { align: "center", weight: 900 });
        for (let i = 0; i < 3; i++) {
          const [x, y, rot] = bacCardXY(side, i);
          g.save();
          g.translate(x, y);
          g.rotate(rot);
          cardSlot(g, 0, 0, 118, 166, rgba("#ffffff", 0.25));
          g.restore();
        }
      }
      BAC_BETS.forEach((b) => {
        feltBox(g, th, b.x, 480, b.w, 200, { fill: rgba(b.col, 0.14), stroke: rgba(th.accent, 0.8), r: 8 });
        txt(g, b.name, b.x + b.w / 2, 528, b.w > 300 ? 40 : 30, "#fff", { align: "center", weight: 900 });
        let pays = b.pays;
        const r = obj(S.st.rules);
        if (b.id === "tie") pays = `${num(r.tie_pays, 8)} : 1`;
        if (b.id === "banker" && r.commission === "no_commission") pays = "1 : 1 (6 pays 1:2)";
        txt(g, pays, b.x + b.w / 2, 664, 22, th.accent, { align: "center", weight: 800 });
      });
      txt(g, "BEAD PLATE", 80, 724, 18, INK3, { weight: 800, shadow: false });
      txt(g, "BIG ROAD", 560, 724, 18, INK3, { weight: 800, shadow: false });
      for (const [x0, cols] of [[80, 12], [560, 26]]) {
        for (let r = 0; r < 6; r++)
          for (let c = 0; c < cols; c++) {
            g.beginPath();
            g.rect(x0 + c * 36, 736 + r * 36, 36, 36);
            g.lineWidth = 1;
            g.strokeStyle = "rgba(255,255,255,.1)";
            g.stroke();
          }
      }
      // the shoe
      rr(g, BAC_SHOE[0] - 60, BAC_SHOE[1] - 110, 120, 90, 14);
      g.fillStyle = "#1a1a20";
      g.fill();
      g.lineWidth = 3;
      g.strokeStyle = th.accent;
      g.stroke();
      txt(g, "SHOE", BAC_SHOE[0], BAC_SHOE[1] - 56, 22, th.accent, { align: "center", weight: 850 });
    },
    overlays(S, root) {
      stampLayers(S, root, "stamp");
    },
    // the coup is dealt on the panel's clock (deal_times); the table layer redraws as each card lands
    key: (S) => {
      const rv = revealOf(S, "baccarat");
      const td = bacDealT(S);
      return rv && td != null ? bacDealTimes(obj(rv.outcome)).filter((c) => td >= c[2]).length : "";
    },
    slowHz: (S) => (S.st.phase === "betting" && S.st.ends_in != null ? 1 : revealOf(S, "baccarat") ? 0 : 2),
    move(S) {
      const rv = revealOf(S, "baccarat");
      const o = rv ? obj(rv.outcome) : null;
      if (!o || !o.winner) return stampMove(S, "stamp", 0, 0, null);
      const times = bacDealTimes(o);
      const td = bacDealT(S);
      const b = BAC_BETS.find((x) => x.id === o.winner) || BAC_BETS[1];
      stampPaint(S, "stamp", o.winner === "tie" ? "TIE" : "WIN", S.th.accent);
      stampMove(S, "stamp", b.x + b.w / 2, 600, (S.st.phase === "result" ? 99 : td) - (times[times.length - 1][2] + 0.6), 116, -0.15);
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const ph = st.phase;
      const res = ph === "result" ? obj(obj(st.result).outcome) : null;
      const rv = revealOf(S, "baccarat");
      const td = bacDealT(S);
      const cards = { player: [], banker: [] };
      const ages = {};
      if (rv && td != null) {
        const o = obj(rv.outcome);
        for (const [side, i, at] of bacDealTimes(o))
          if (td >= at) {
            cards[side][i] = arr(o[side])[i];
            ages[`${side}${i}`] = td - at;
          }
      } else if (res) {
        cards.player = arr(res.player);
        cards.banker = arr(res.banker);
      } else if (ph === "dealing") {
        cards.player = arr(obj(st.cards).player);
        cards.banker = arr(obj(st.cards).banker);
      }
      const totals = {};
      for (const side of ["player", "banker"]) {
        const shownCodes = [];
        cards[side].forEach((code, i) => {
          if (!code) return;
          const [x, y, rot] = bacCardXY(side, i);
          const age = ages[`${side}${i}`];
          const f = age != null ? flyAge(S, age, BAC_SHOE[0], BAC_SHOE[1] - 60, x, y, 0.5) : cardFly(S, `${side}${i}`, BAC_SHOE[0], BAC_SHOE[1] - 60, x, y, t, 0.6);
          if (f.flip >= 0.5) shownCodes.push(code);
          drawCard(S, g, code, f.x, f.y, 118, 166, { rot: rot + f.rot, flip: f.flip });
        });
        totals[side] = baccaratTotal(shownCodes);
        const s = BAC_SLOTS[side];
        if (shownCodes.length) {
          const win = res && res.winner === side;
          circle(g, side === "player" ? s.x + s.w - 30 : s.x + 30, 180, 44);
          g.fillStyle = win ? th.accent : "rgba(0,0,0,.6)";
          g.fill();
          g.lineWidth = 3;
          g.strokeStyle = s.col;
          g.stroke();
          txt(g, String(totals[side]), side === "player" ? s.x + s.w - 30 : s.x + 30, 198, 50, win ? th.ink : "#fff", { align: "center", weight: 900, shadow: false });
        }
      }
      if (res && res.winner) {
        for (const side of ["player", "banker"]) if (res.winner === side || res.winner === "tie") glowBox(g, BAC_SLOTS[side].x, 150, BAC_SLOTS[side].w, 300, res.winner === "tie" ? "#3ddc84" : BAC_SLOTS[side].col, 1);
      }
      drawHeadline(S, g, 760, 40, 900, t, headline(S, t, (p) => {
        if (p === "dealing") return { title: "THE COUP IS DEALT", sub: `Player ${totals.player} · Banker ${totals.banker}`, tone: th.accent_hi };
        if (p === "result" && res) {
          const w = res.winner === "tie" ? "TIE" : `${String(res.winner).toUpperCase()} WINS`;
          const extra = [res.natural ? "NATURAL" : "", res.ppair ? "PLAYER PAIR" : "", res.bpair ? "BANKER PAIR" : ""].filter(Boolean).join(" · ");
          return { title: `${w} ${res.p} – ${res.b}`, sub: extra || headline(S, t).sub, tone: res.winner === "tie" ? "#3ddc84" : BAC_SLOTS[res.winner] ? shade(BAC_SLOTS[res.winner].col, 1.4) : th.accent };
        }
        return null;
      }), { size: 50, align: "center" });
      // the bets
      const sb = obj(st.spot_bets);
      const wins = res ? bacWinSpots(res) : new Set();
      BAC_BETS.forEach((b) => {
        const isWin = wins.has(b.id) || (res && res.winner === "tie" && (b.id === "player" || b.id === "banker"));
        if (res && wins.has(b.id)) glowBox(g, b.x, 480, b.w, 200, th.accent, 1, 8);
        const tot = num(obj(st.totals)[b.id]);
        if (tot) txt(g, fmt(S, tot), b.x + b.w / 2, 560, 22, INK2, { align: "center", font: "mono", weight: 700 });
        spotChips(S, g, b.id, sb[b.id], b.x + b.w / 2, 610, t, { r: 28, glow: res && wins.has(b.id) ? th.accent : null, sweepAt: res && !isWin ? 1.5 : null, to: [BAC_SHOE[0], 100] });
      });
      // roads
      const hist = arr(st.history).filter((h) => h.game === "baccarat" && h.outcome).map((h) => obj(h.outcome));
      const bead = hist.slice(-72);
      bead.forEach((o, i) => {
        const c = Math.floor(i / 6);
        const r = i % 6;
        const col = o.winner === "player" ? "#1f5fe0" : o.winner === "banker" ? "#d0182f" : "#0e9a4c";
        circle(g, 80 + c * 36 + 18, 736 + r * 36 + 18, 15);
        g.fillStyle = col;
        g.fill();
        txt(g, o.winner === "player" ? "P" : o.winner === "banker" ? "B" : "T", 80 + c * 36 + 18, 736 + r * 36 + 25, 18, "#fff", { align: "center", weight: 850, shadow: false });
      });
      bigRoad(hist).forEach(({ c, r, w, ties }) => {
        if (c >= 26) return;
        const x = 560 + c * 36 + 18;
        const y = 736 + r * 36 + 18;
        circle(g, x, y, 13);
        g.lineWidth = 4;
        g.strokeStyle = w === "player" ? "#4a86ff" : "#ff4a5e";
        g.stroke();
        if (ties) {
          g.beginPath();
          g.moveTo(x - 12, y + 12);
          g.lineTo(x + 12, y - 12);
          g.strokeStyle = "#3ddc84";
          g.lineWidth = 3;
          g.stroke();
        }
      });
      const count = (w) => hist.filter((o) => o.winner === w).length;
      txt(g, `P ${count("player")}  ·  B ${count("banker")}  ·  T ${count("tie")}`, 1500, 724, 20, INK2, { align: "right", weight: 800, shadow: false });
      if (res) winnersCard(S, g, 1080, 150, 380, t, { delay: 2.4, max: 3 });
    },
  });

  /** The big road: a new column when the winner changes, down then right when a column is full; ties mark. */
  function bigRoad(hist) {
    const out = [];
    let c = -1;
    let r = 0;
    let last = null;
    for (const o of hist) {
      if (o.winner === "tie") {
        if (out.length) out[out.length - 1].ties += 1;
        continue;
      }
      if (o.winner !== last) {
        c = out.length ? Math.max(...out.filter((e) => e.r === 0).map((e) => e.c)) + 1 : 0;
        r = 0;
      } else if (r < 5) r += 1;
      else c += 1;
      out.push({ c, r, w: o.winner, ties: 0 });
      last = o.winner;
    }
    return out;
  }

  // ================================================================================================ ANDAR BAHAR
  const AB_ROW = { andar: 270, bahar: 540 };
  const AB_SHOE = [760, 120];
  // casino/games/andarbahar.py deal_pace / DEAL_LEAD and the panel's FLY: card j lands at LEAD + j·pace
  const AB_LEAD = 0.9;
  const AB_FLY = 0.25;
  const abPace = (n) => Math.max(0.18, Math.min(0.6, 9 / Math.max(1, n)));
  /** The deal on the panel's clock: {t (s into the deal), k (cards dealt), n, done} or null without a reveal. */
  function abDeal(S) {
    const rv = revealOf(S, "andarbahar");
    if (!rv) return null;
    const o = obj(rv.outcome);
    const n = num(o.count, arr(o.cards).length);
    if (S.st.phase === "result") return { o, t: 99, k: n, n, done: true };
    const t = sinceLockOf(rv, S.T) - num(rv.lock_s, LOCK);
    const pace = abPace(n);
    const k = t < AB_LEAD ? 0 : Math.min(n, 1 + Math.floor((t - AB_LEAD) / pace));
    return { o, t, k, n, done: k >= n && t >= AB_LEAD + (n - 1) * pace + AB_FLY };
  }
  function abCardX(i, n) {
    const step = Math.min(70, (1020 - 110) / Math.max(1, n - 1));
    return 470 + 55 + i * step;
  }
  const andarbahar = makeScene({
    id: "casino-andarbahar",
    app: "casino_andarbahar",
    bg(S, g) {
      const th = S.th;
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 760, 400, 1100, 36);
      feltBox(g, th, 70, 170, 330, 460, { fill: "rgba(0,0,0,.2)" });
      txt(g, "JOKER", 235, 220, 34, th.accent, { align: "center", weight: 900 });
      cardSlot(g, 235, 400, 200, 280, rgba("#ffffff", 0.25));
      for (const side of ["andar", "bahar"]) {
        const y = AB_ROW[side];
        feltBox(g, th, 430, y - 110, 1080, 220, { fill: rgba(TONE[side], 0.12), stroke: rgba(TONE[side], 0.8) });
        txt(g, side.toUpperCase(), 450, y - 118 + 0, 24, TONE[side], { weight: 900 });
      }
      txt(g, "ANDAR BAHAR", 70, 120, 40, th.accent, { weight: 900 });
    },
    overlays(S, root) {
      stampLayers(S, root, "stamp");
    },
    key: (S) => {
      const d = abDeal(S);
      return d ? `${d.k}|${d.done}|${d.t < 0.5}` : "";
    },
    slowHz: (S) => (S.st.phase === "betting" && S.st.ends_in != null ? 1 : revealOf(S, "andarbahar") ? 0 : 2),
    move(S) {
      const d = abDeal(S);
      if (!d) return stampMove(S, "stamp", 0, 0, null);
      const w = String(d.o.winner);
      const pace = abPace(d.n);
      stampPaint(S, "stamp", "WIN", S.th.accent);
      stampMove(S, "stamp", w === "andar" ? 400 : 860, 790, d.t - (AB_LEAD + (d.n - 1) * pace + AB_FLY), 120, 0.14);
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const ph = st.phase;
      const d = abDeal(S);
      const out = ph === "result" ? obj(obj(st.result).outcome) : null;
      const deal = d ? d.o : ph === "dealing" ? obj(st.deal) : null;
      const joker = out ? out.joker : deal ? deal.joker : null;
      const first = (out || deal || {}).first || obj(st.rules).first || "andar";
      const cards = out ? arr(out.cards) : d ? arr(d.o.cards).slice(0, d.k) : deal ? arr(deal.cards) : [];
      const matched = out ? true : d ? d.done : deal ? !!deal.matched : false;
      if (joker) {
        const f = d ? flyAge(S, d.t, 235, 400, 235, 400, 0.5) : cardFly(S, "joker", AB_SHOE[0], AB_SHOE[1], 235, 400, t, 0.7);
        drawCard(S, g, joker, f.x, f.y, 200, 280, { flip: f.flip, glow: rgba(th.accent, 0.7) });
      }
      const other = first === "andar" ? "bahar" : "andar";
      const rows = { andar: [], bahar: [] };
      cards.forEach((c, i) => rows[i % 2 === 0 ? first : other].push({ c, i }));
      for (const side of ["andar", "bahar"]) {
        const list = rows[side];
        list.forEach(({ c, i }, j) => {
          const x = abCardX(j, Math.max(list.length, 8));
          const f = d ? flyAge(S, d.t - (AB_LEAD + i * abPace(d.n)), AB_SHOE[0], AB_SHOE[1], x, AB_ROW[side], AB_FLY + 0.15) : cardFly(S, `ab${i}`, AB_SHOE[0], AB_SHOE[1], x, AB_ROW[side], t, 0.45);
          const isMatch = matched && i === cards.length - 1;
          drawCard(S, g, c, f.x, f.y, 110, 154, { flip: f.flip, rot: f.rot, glow: isMatch && f.flip >= 1 ? th.accent : null });
        });
      }
      const winner = out ? out.winner : matched && cards.length ? (cards.length % 2 === 1 ? first : other) : null;
      if (winner && (out || matched)) glowBox(g, 430, AB_ROW[winner] - 110, 1080, 220, TONE[winner], 1);
      if (cards.length) txt(g, `${cards.length} ${cards.length === 1 ? "CARD" : "CARDS"}`, 235, 600, 30, INK1, { align: "center", font: "mono", weight: 800 });
      drawHeadline(S, g, 430, 20, 1080, t, headline(S, t, (p) => {
        if (p === "dealing") return matched ? { title: `${String(winner).toUpperCase()} MATCHES!`, sub: "", tone: TONE[winner] } : { title: "DEALING…", sub: `First card to ${first === "andar" ? "Andar" : "Bahar"} · find the joker's ${obj(st.deal).match === "card" ? "twin" : "rank"}`, tone: th.accent_hi };
        if (p === "result" && out) return { ...headline(S, t), title: `${String(out.winner).toUpperCase()} WINS · ${out.count} CARDS`, tone: TONE[out.winner] };
        return null;
      }), { size: 46 });
      // bets
      const spots = arr(st.spots);
      const sb = obj(st.spot_bets);
      const main = [{ id: "andar", x: 70, w: 440 }, { id: "bahar", x: 530, w: 440 }];
      const winSpots = new Set();
      if (out) {
        winSpots.add(out.winner);
        for (const s of spots) if (s.kind === "count" && arr(s.numbers).includes(out.count)) winSpots.add(s.id);
      }
      main.forEach((m) => {
        const sp = spots.find((s) => s.id === m.id) || {};
        feltBox(g, th, m.x, 700, m.w, 250, { fill: rgba(TONE[m.id], 0.14), stroke: TONE[m.id] });
        txt(g, m.id.toUpperCase(), m.x + 24, 752, 44, "#fff", { weight: 900 });
        txt(g, `PAYS ${sp.pays || "1:1"}`, m.x + 24, 930, 24, th.accent, { weight: 850 });
        const isWin = winSpots.has(m.id);
        if (isWin) glowBox(g, m.x, 700, m.w, 250, TONE[m.id], 0.6 + 0.4 * Math.sin(t * 6));
        spotChips(S, g, m.id, sb[m.id], m.x + m.w / 2 + 60, 840, t, { r: 32, glow: isWin ? th.accent : null, sweepAt: out && !isWin ? 1.5 : null, to: AB_SHOE });
      });
      const bands = spots.filter((s) => s.kind === "count");
      bands.forEach((s, i) => {
        const x = 990 + (i % 4) * 130;
        const y = 700 + Math.floor(i / 4) * 128;
        feltBox(g, th, x, y, 120, 116, { fill: "rgba(0,0,0,.2)", r: 12, lw: 2 });
        txt(g, String(s.label || "").replace(" cards", ""), x + 60, y + 32, 22, "#fff", { align: "center", weight: 850 });
        txt(g, s.pays || "", x + 60, y + 104, 18, th.accent, { align: "center", weight: 800 });
        const isWin = winSpots.has(s.id);
        if (isWin) glowBox(g, x, y, 120, 116, th.accent, 0.6 + 0.4 * Math.sin(t * 6), 12);
        spotChips(S, g, s.id, sb[s.id], x + 60, y + 64, t, { r: 18, glow: isWin ? th.accent : null, sweepAt: out && !isWin ? 1.5 : null, to: AB_SHOE });
      });
      if (!bands.length) txt(g, "Count side bets are off", 1240, 820, 24, INK3, { align: "center", weight: 650 });
      if (out) winnersCard(S, g, 70, 170, 330, t, { delay: 2.0, max: 3 });
    },
  });

  // ================================================================================================ BLACKJACK
  const BJ_C = [760, 40];
  const BJ_R = 700;
  const BJ_SHOE = [1330, 120];
  function bjSeatXY(i, n) {
    const a = ((155 - (130 * (i + 0.5)) / Math.max(1, n)) * Math.PI) / 180;
    return [BJ_C[0] + Math.cos(a) * BJ_R, BJ_C[1] + Math.sin(a) * BJ_R];
  }
  function arcText(g, s, cx, cy, r, mid, size, color, spacing) {
    const chars = String(s).split("");
    const step = (size * (spacing || 0.62)) / r;
    let a = mid + (step * (chars.length - 1)) / 2;
    for (const ch of chars) {
      g.save();
      g.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      g.rotate(a - Math.PI / 2);
      txt(g, ch, 0, 0, size, color, { align: "center", weight: 850, shadow: false });
      g.restore();
      a -= step;
    }
  }
  function bjSeats(S) {
    const st = S.st;
    const table = obj(st.table);
    const live = ["dealing", "action", "result", "locked"].includes(st.phase) && arr(table.seats).length;
    if (live) return arr(table.seats);
    const main = arr(obj(st.spot_bets).main);
    const seats = S.players.filter((p) => p.online || main.some((e) => String(e.seat) === String(p.seat)));
    return seats.map((p) => {
      const e = main.find((x) => String(x.seat) === String(p.seat));
      return { seat: p.seat, name: p.name, color: p.color, hands: [], bet: e ? num(e.amount) : 0 };
    });
  }
  const blackjack = makeScene({
    id: "casino-blackjack",
    app: "casino_blackjack",
    // the felt as bg() draws it: a flat top and the big arc round the seats
    feltClip: () => {
      const R = BJ_R + 180;
      const a1 = Math.atan2(360 - BJ_C[1], RAIL_X - 40 - BJ_C[0]);
      const a2 = Math.atan2(360 - BJ_C[1], 40 - BJ_C[0]);
      const p = (a) => `${(BJ_C[0] + Math.cos(a) * R).toFixed(1)} ${(BJ_C[1] + Math.sin(a) * R).toFixed(1)}`;
      return `path("M 40 18 L ${RAIL_X - 40} 18 L ${RAIL_X - 40} 360 L ${p(a1)} A ${R} ${R} 0 0 1 ${p(a2)} Z")`;
    },
    bg(S, g) {
      const th = S.th;
      g.beginPath();
      g.moveTo(40, 18);
      g.lineTo(RAIL_X - 40, 18);
      g.lineTo(RAIL_X - 40, 360);
      g.arc(BJ_C[0], BJ_C[1], BJ_R + 180, Math.atan2(360 - BJ_C[1], RAIL_X - 40 - BJ_C[0]), Math.atan2(360 - BJ_C[1], 40 - BJ_C[0]));
      g.closePath();
      luxTable(g, th, 760, 200, 1100, 44);
      const r = obj(S.st.rules);
      arcText(g, `BLACKJACK PAYS ${r.blackjack_pays || "3:2"}`.replace(":", " TO "), BJ_C[0], BJ_C[1], 420, Math.PI / 2, 40, th.accent, 0.72);
      arcText(g, `DEALER ${r.soft17 === "hit" ? "HITS" : "STANDS ON"} SOFT 17 · INSURANCE PAYS 2 TO 1`, BJ_C[0], BJ_C[1], 372, Math.PI / 2, 22, rgba("#ffffff", 0.55), 0.66);
      g.beginPath();
      g.arc(BJ_C[0], BJ_C[1], 470, Math.PI * 0.17, Math.PI * 0.83);
      g.lineWidth = 3;
      g.strokeStyle = rgba(th.accent, 0.5);
      g.stroke();
      // the shoe and the discard tray
      rr(g, BJ_SHOE[0] - 70, BJ_SHOE[1] - 60, 140, 110, 16);
      g.fillStyle = "#16161c";
      g.fill();
      g.lineWidth = 3;
      g.strokeStyle = th.accent;
      g.stroke();
      rr(g, 120, 70, 120, 100, 14);
      g.fillStyle = "rgba(0,0,0,.35)";
      g.fill();
      txt(g, "DISCARD", 180, 130, 18, INK3, { align: "center", weight: 800, shadow: false });
    },
    turnSeat(S) {
      const turn = obj(obj(S.st.table).turn);
      return turn.seat != null ? turn.seat : null;
    },
    railInfo(S, p) {
      const seat = arr(obj(S.st.table).seats).find((s) => String(s.seat) === String(p.seat));
      if (seat && seat.net != null && S.st.phase === "result") return { text: `${seat.net >= 0 ? "WON" : "LOST"} ${signed(S, seat.net)}`, color: seat.net > 0 ? OK : seat.net < 0 ? BAD : INK2 };
      if (seat && arr(seat.hands).length) {
        const h = seat.hands[0];
        return { text: `${h.bj ? "BLACKJACK" : h.status === "bust" ? "BUST" : `HAND ${h.total}`} · BET ${fmt(S, arr(seat.hands).reduce((a, x) => a + num(x.bet), 0))}`, color: INK2 };
      }
      return railInfoDefault(S, p);
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const table = obj(st.table);
      const shoe = obj(table.shoe);
      txt(g, `${num(shoe.decks, 6)} DECKS`, BJ_SHOE[0], BJ_SHOE[1] - 8, 20, th.accent, { align: "center", weight: 850, shadow: false });
      txt(g, `${num(shoe.left, 312)} LEFT`, BJ_SHOE[0], BJ_SHOE[1] + 26, 20, INK2, { align: "center", weight: 750, shadow: false });
      if (shoe.cut) pill(g, "CUT CARD OUT", BJ_SHOE[0], BJ_SHOE[1] + 76, 16, "#d0182f", "#fff", { align: "center" });
      // dealer
      const dealer = obj(table.dealer);
      const dc = arr(dealer.cards);
      dc.forEach((c, i) => {
        const x = 760 - ((dc.length - 1) * 96) / 2 + i * 96;
        const f = cardFly(S, `d${i}`, BJ_SHOE[0], BJ_SHOE[1], x, 170, t, 0.5);
        drawCard(S, g, c === "??" ? "back" : c, f.x, f.y, 110, 154, { down: c === "??", flip: c === "??" ? null : f.flip, rot: f.rot });
      });
      if (dc.length) {
        const bx = 760 + ((dc.length - 1) * 96) / 2 + 110;
        const label = dealer.bj ? "BJ" : `${dealer.total}${dealer.soft ? "*" : ""}`;
        circle(g, bx, 120, 38);
        g.fillStyle = dealer.total > 21 ? BAD : "rgba(0,0,0,.65)";
        g.fill();
        g.lineWidth = 3;
        g.strokeStyle = th.accent;
        g.stroke();
        txt(g, label, bx, 134, 36, "#fff", { align: "center", weight: 900, shadow: false });
        txt(g, "DEALER", 760, 275, 20, INK2, { align: "center", weight: 800, shadow: false });
      }
      // seats
      const seats = bjSeats(S);
      const n = seats.length;
      const turn = obj(table.turn);
      const sb = obj(st.spot_bets);
      seats.forEach((seat, i) => {
        const [x, y] = bjSeatXY(i, Math.max(n, 3));
        const p = { ...playerOf(S, seat.seat), color: seat.color || seatColor(S, seat.seat), name: seat.name };
        const isTurn = turn.seat != null && String(turn.seat) === String(seat.seat);
        // betting circle
        circle(g, x, y, 50);
        g.lineWidth = 4;
        g.strokeStyle = isTurn ? th.accent : rgba("#ffffff", 0.45);
        g.stroke();
        if (isTurn) {
          const tc = S.fx.turn || (S.fx.turn = new Countdown());
          tc.observe(`${seat.seat}|${turn.hand}`, turn.ends_in, S.ctx.stateAt || t);
          hudRing(S, `turn${seat.seat}`, x, y, 62, { left: tc.left(t), span: num(obj(st.house).turn_seconds, 20), color: th.accent, low: BAD, lowBelow: 5, label: false, width: 7 });
        }
        const hands = arr(seat.hands);
        const bet = hands.length ? hands.reduce((a, h) => a + num(h.bet), 0) : num(seat.bet);
        const entries = arr(sb.main).filter((e) => String(e.seat) === String(seat.seat));
        if (entries.length) spotChips(S, g, `main`, entries.map((e) => ({ ...e, amount: bet || e.amount })), x, y, t, { r: 30 });
        else if (bet) stack(S, g, x, y, 30, bet, p.color);
        // the hands, toward the dealer
        const dx = BJ_C[0] - x;
        const dy = BJ_C[1] - y;
        const dl = Math.hypot(dx, dy) || 1;
        hands.forEach((h, hi) => {
          const off = (hi - (hands.length - 1) / 2) * 120;
          const hx = x + (dx / dl) * 170 + off;
          const hy = y + (dy / dl) * 170;
          const cs = arr(h.cards);
          cs.forEach((c, ci) => {
            const cx = hx - (cs.length - 1) * 13 + ci * 26;
            const cy = hy - ci * 8;
            const f = cardFly(S, `s${seat.seat}h${hi}c${ci}`, BJ_SHOE[0], BJ_SHOE[1], cx, cy, t, 0.5);
            drawCard(S, g, c, f.x, f.y, 84, 118, { flip: f.flip, rot: (h.doubled && ci === 2 ? Math.PI / 2 : 0) + f.rot, dim: h.status === "bust" || h.status === "surrender" ? 0.35 : 0 });
          });
          if (cs.length) {
            const tag = h.bj ? "BLACKJACK" : h.status === "bust" ? `BUST ${h.total}` : h.status === "surrender" ? "SURRENDER" : `${h.soft ? `${h.total - 10}/` : ""}${h.total}`;
            const col = h.bj ? th.accent : h.status === "bust" ? BAD : "rgba(0,0,0,.75)";
            const isHand = isTurn && num(turn.hand) === hi;
            pill(g, tag, hx, hy - 96 - (cs.length - 1) * 8, 22, col, h.bj ? th.ink : "#fff", { align: "center", stroke: isHand ? th.accent : null });
            if (h.doubled) pill(g, "DOUBLE", hx, hy + 82, 16, rgba(th.accent, 0.9), th.ink, { align: "center" });
          }
        });
        if (num(seat.insurance)) pill(g, `INSURED ${fmt(S, seat.insurance)}`, x, y - 70, 16, "#1f5fe0", "#fff", { align: "center" });
        // the name plate
        avatar(S, g, x - 70, y + 86, 22, p, { glow: isTurn });
        txt(g, p.name || `P${seat.seat}`, x - 40, y + 95, 26, p.color, { weight: 800, maxW: 150 });
        if (seat.net != null && st.phase === "result") {
          const k = easeOut((S.clk.since(t) - 0.3) / 0.4);
          pill(g, seat.net > 0 ? `WIN ${signed(S, seat.net)}` : seat.net < 0 ? `LOSE ${fmt(S, -seat.net)}` : "PUSH", x, y + 140 - (1 - k) * 20, 22, seat.net > 0 ? OK : seat.net < 0 ? "rgba(255,77,94,.9)" : "#6a6a78", seat.net > 0 ? "#05210f" : "#fff", { align: "center" });
        }
      });
      if (!n) txt(g, "Waiting for players — scan the code to sit down", 760, 640, 32, INK2, { align: "center", weight: 650 });
      drawHeadline(S, g, 70, 210, 560, t, headline(S, t, (p) => {
        if (p === "dealing" || p === "action") {
          const stage = String(table.stage || "");
          if (stage === "insurance") {
            const ic = S.fx.ins || (S.fx.ins = new Countdown());
            ic.observe(`ins${st.round}`, table.insurance_in, S.ctx.stateAt || t);
            const left = ic.left(t);
            return { title: "INSURANCE?", sub: "The dealer shows an ace", tone: "#4a86ff", ring: left != null ? { frac: left / 12, label: Math.ceil(left - 1e-6), color: "#4a86ff", left, span: 12 } : null };
          }
          if (turn.seat != null) {
            const who = playerOf(S, turn.seat);
            return { title: `${who.name || `P${turn.seat}`} TO PLAY`, sub: "Hit, stand, double or split", tone: seatColor(S, turn.seat) };
          }
          if (stage === "dealer") return { title: "DEALER PLAYS", sub: `Dealer ${obj(st.rules).soft17 === "hit" ? "hits" : "stands on"} soft 17`, tone: th.accent_hi };
          return { title: "DEALING…", sub: "", tone: th.accent_hi };
        }
        if (p === "result") return { ...headline(S, t), title: dealer.bj ? "DEALER BLACKJACK" : dealer.total > 21 ? `DEALER BUSTS ${dealer.total}` : `DEALER ${dealer.total || ""}` };
        return null;
      }), { size: 44, ringR: 40 });
    },
  });

  // ================================================================================================ POKER TABLES (hold'em, teen patti)
  // The oval sits a little high so every seat, its name plate and its cards stay on the stage (the bottom seat's plate
  // used to fall off the screen): seats ring the felt at (rx + 70, ry + 44).
  const PK = { cx: 760, cy: 476, rx: 560, ry: 290 };
  const PK_SEAT = [70, 44];
  function pokerSeatXY(i, n) {
    const a = Math.PI / 2 + (i * TAU) / Math.max(1, n);
    return [PK.cx + Math.cos(a) * (PK.rx + PK_SEAT[0]), PK.cy + Math.sin(a) * (PK.ry + PK_SEAT[1]), a];
  }
  /** A seat's name plate (name, stack, last move): under the avatar, or over it on the far side. [x, y, w, h] */
  const PLATE_H = 84;
  function pokerPlate(i, n) {
    const [x, y, a] = pokerSeatXY(i, n);
    return Math.sin(a) > -0.35 ? [x - 110, y + 56, 220, PLATE_H] : [x - 110, y - 56 - PLATE_H, 220, PLATE_H];
  }
  /** Where seat i's card c (of ncards) rests: toward the felt's centre; `big` for a face-up hand at a show. */
  function pokerCardXY(i, n, c, ncards, big) {
    const [x, y] = pokerSeatXY(i, n);
    const dx = PK.cx - x;
    const dy = PK.cy - y;
    const d = Math.hypot(dx, dy) || 1;
    const off = c - (ncards - 1) / 2;
    const reach = big ? 125 + 60 * Math.abs(dx / d) : 125; // a face-up spread is wider: clear of the avatar at the side seats
    return [x + (dx / d) * reach + off * (big ? 64 : 30), y + (dy / d) * reach, off * (big ? 0.08 : 0.12)];
  }
  function pokerSeats(S) {
    const st = S.st;
    const t = obj(st.table);
    if (arr(t.seats).length && st.phase !== "betting" && st.phase !== "idle") return { live: true, seats: arr(t.seats) };
    const sitting = new Set(arr(st.sitting).map(String));
    return {
      live: false,
      seats: S.players.filter((p) => p.online).map((p) => ({ seat: p.seat, name: p.name, color: p.color, stack: p.credits, sitting: sitting.has(String(p.seat)) })),
    };
  }
  /**
   * The table's engraved name: across the top of the felt when no seat sits there, else none (the header carries the
   * table's name too) — it used to sit under the bottom seat's cards and chips.
   */
  function pokerTitleFree(n) {
    for (let i = 0; i < n; i++) {
      const a = mod(Math.PI / 2 + (i * TAU) / n, TAU);
      if (Math.abs(a - 1.5 * Math.PI) < 0.75) return false;
    }
    return true;
  }
  function pokerBg(S, g, title) {
    const th = S.th;
    // the racetrack: a wide padded leather rail (the players' elbows) round the lacquered wood and the felt
    g.beginPath();
    g.ellipse(PK.cx, PK.cy, PK.rx + 44, PK.ry + 44, 0, 0, TAU);
    softStroke(g, 0, 60, "#000", 0.85, 0, 22, 7);
    g.fillStyle = "#120a07";
    g.fill();
    g.beginPath();
    g.ellipse(PK.cx, PK.cy, PK.rx + 30, PK.ry + 30, 0, 0, TAU);
    const lg = g.createLinearGradient(0, PK.cy - PK.ry - 50, 0, PK.cy + PK.ry + 50);
    lg.addColorStop(0, "#3a221a");
    lg.addColorStop(0.5, "#1c0f0b");
    lg.addColorStop(1, "#0c0605");
    g.lineWidth = 34;
    g.strokeStyle = lg;
    g.stroke();
    g.lineWidth = 2;
    g.strokeStyle = "rgba(255,220,180,.18)";
    g.stroke();
    g.beginPath();
    g.ellipse(PK.cx, PK.cy, PK.rx, PK.ry, 0, 0, TAU);
    luxTable(g, th, PK.cx, PK.cy - 60, PK.rx, 28);
    g.beginPath();
    g.ellipse(PK.cx, PK.cy, PK.rx - 70, PK.ry - 60, 0, 0, TAU);
    g.lineWidth = 2;
    g.strokeStyle = rgba(th.accent, 0.3);
    g.setLineDash([2, 7]);
    g.stroke();
    g.setLineDash([]);
    if (pokerTitleFree(pokerSeats(S).seats.length)) txt(g, title, PK.cx, PK.cy - 170, 42, rgba(th.accent, 0.22), { align: "center", weight: 700, font: "serif", emboss: true, spacing: 6 });
  }

  // ------------------------------------------------------------------------------------------------ the deal and the show
  // Turn games send no TV reveal, but their timers are public (status.clock): the hand is dealt from the lock — the
  // panel's shuffle second (LOCK), then the game's deal beat (casino/games/_pvp.py deal_beat, 2 s) — and a show turns
  // the hands over from the finish (reveal_at − the 3.2 s end beat). Every card's moment is a pure function of the
  // shared clock, so every screen deals and turns the same card in the same frame. The cards are backs until the engine
  // makes them public (status.table.showdown). Cards on the move are pooled sprites (transforms only); the table layer
  // redraws once when the deal or the show is over.
  const DEAL = { LEAD: 0.1, FLY: 0.34, SPAN: 1.75, STEP: 0.22 };
  const SHOW = { BEAT: 3.2, LEAD: 0.25, SEAT: 0.35, CARD: 0.14, GROW: 0.2, TURN: 0.42, GLOW: 0.15 };
  const CARD_S = [66, 92]; // a hand face down
  const CARD_B = [92, 128]; // a hand face up
  /** Seconds after the lock when card c (dealing round) of the j-th seat in deal order (of n seats) leaves the deck. */
  function dealAt(c, j, n, ncards) {
    const step = Math.min(DEAL.STEP, DEAL.SPAN / Math.max(1, ncards * n));
    return LOCK + DEAL.LEAD + (c * n + j) * step;
  }
  /** Seconds after the lock when the last card lands. */
  const dealEnd = (n, ncards) => dealAt(ncards - 1, Math.max(0, n - 1), Math.max(1, n), ncards) + DEAL.FLY;
  /** Each seat's place in the deal (index in `seats` → order): the seat after the dealer first, the dealer last. */
  function dealOrder(n, dealerIdx) {
    const out = [];
    for (let i = 0; i < n; i++) out.push(mod(i - (dealerIdx < 0 ? -1 : dealerIdx) - 1, Math.max(1, n)));
    return out;
  }
  /** Where the deck sits: on the felt in front of the dealer, to their left (clear of the pot and their cards). */
  function deckXY(n, dealerIdx) {
    if (dealerIdx < 0 || !n) return [PK.cx + 230, PK.cy - 60];
    const [x, y] = pokerSeatXY(dealerIdx, n);
    const dx = PK.cx - x;
    const dy = PK.cy - y;
    const d = Math.hypot(dx, dy) || 1;
    return [x + (dx / d) * 200 - (dy / d) * 170, y + (dy / d) * 200 + (dx / d) * 170];
  }
  /** The show's timeline (s after the show starts) for `ns` hands of `ncards`: {end, glow}. */
  function showTimes(ns, ncards) {
    const end = SHOW.LEAD + Math.max(0, ns - 1) * SHOW.SEAT + Math.max(0, ncards - 1) * SHOW.CARD + SHOW.TURN;
    return { end, glow: end + SHOW.GLOW };
  }
  /** How far card c of the si-th shown hand has turned (0 = back up, 1 = face up), `age` s into the show. */
  const showFlip = (age, si, c) => clamp((age - (SHOW.LEAD + si * SHOW.SEAT + c * SHOW.CARD)) / SHOW.TURN, 0, 1);
  /** When the show began (engine clock): the finish, i.e. the reveal deadline − the end beat; null without a show. */
  function showAnchor(st) {
    const tb = obj(st.table);
    const ck = obj(st.clock);
    if (!tb.finished || !Object.keys(obj(tb.showdown)).length) return null;
    if (typeof ck.reveal_at === "number") return ck.reveal_at - SHOW.BEAT;
    if (st.phase === "result" && typeof ck.phase_at === "number") return ck.phase_at - SHOW.BEAT;
    return null;
  }
  /** The engine's clock is known (a live TV); tests without one see every hand at rest. */
  const synced = (S) => !!(S.ctx && typeof S.ctx.serverNow === "function");

  /**
   * This frame's deal / show state of a poker table: {deal: {since, end} | null, show: {age, end, glow, seats} | null}.
   * Pure function of the status and the shared clock (S.T).
   */
  function pokerMotion(S, ncards, dealerIdx, withShow) {
    const st = S.st;
    const { live, seats } = pokerSeats(S);
    const n = seats.length;
    const out = { deal: null, show: null, seats, n, ncards, dealerIdx };
    if (!live || !n || !synced(S)) return out;
    const lockAt = obj(st.clock).lock_at;
    if (typeof lockAt === "number" && (st.phase === "locked" || st.phase === "dealing" || st.phase === "action")) {
      const since = S.T - lockAt;
      const end = dealEnd(n, ncards);
      if (since > -2 && since < end) out.deal = { since, end };
    }
    const at = withShow ? showAnchor(st) : null;
    if (at != null) {
      const shown = obj(obj(st.table).showdown);
      const order = seats.map((s, i) => ({ s, i })).filter((x) => arr(shown[String(x.s.seat)]).length);
      const tm = showTimes(order.length, ncards);
      const age = S.T - at;
      if (age > -1 && age < tm.glow) out.show = { age, end: tm.end, glow: tm.glow, order };
    }
    return out;
  }

  /** The card sprites: a pool of small plain canvases over the table, moved by transform / opacity. */
  function cardSprite(S, i, key, w, h, paint) {
    const pool = S.cardPool || (S.cardPool = []);
    let sp = pool[i];
    if (!sp || sp.w !== w || sp.h !== h) {
      if (sp) sp.l.c.remove();
      sp = { l: layer(S.cardBox, 0, 0, w + 8, h + 8, chipLayerK(), true, true), key: null, w, h };
      sp.l.c.style.display = "none";
      sp.l.cache = { display: "none" };
      pool[i] = sp;
    }
    if (sp.key !== key) {
      sp.key = key;
      const g = sp.l.g;
      g.setTransform(sp.l.k, 0, 0, sp.l.k, 0, 0);
      g.clearRect(0, 0, w + 8, h + 8);
      paint(g);
    }
    return sp;
  }
  function cardSpritesHideFrom(S, i) {
    for (const sp of (S.cardPool || []).slice(i)) if (sp) hideLayer(sp.l);
  }
  const cardBack = (S) => shade(S.th.accent_deep === CLASSIC.accent_deep ? "#8f1c2c" : S.th.felt3, 1.25);

  /** Every frame: place the cards in flight (the deal) and the cards turning (the show). */
  function pokerFrame(S, m) {
    let used = 0;
    const back = cardBack(S);
    if (m.deal) {
      const order = dealOrder(m.n, m.dealerIdx);
      const [dx, dy] = deckXY(m.n, m.dealerIdx);
      const [w, h] = CARD_S;
      m.seats.forEach((seat, i) => {
        for (let c = 0; c < m.ncards; c++) {
          const u = (m.deal.since - dealAt(c, order[i], m.n, m.ncards)) / DEAL.FLY;
          if (u < 0) continue;
          const [x, y, rot] = pokerCardXY(i, m.n, c, m.ncards, false);
          const e = easeOut(u);
          const k = clamp(u, 0, 1);
          const px = lerp(dx, x, e);
          const py = lerp(dy, y, e) - Math.sin(k * Math.PI) * 26;
          const r = rot + (1 - e) * (hash01(`${seat.seat}|${c}`) - 0.5) * 2.4; // a flick of the wrist, settling square
          const sc = 1 + 0.12 * Math.sin(k * Math.PI);
          const sp = cardSprite(S, used++, `back|${back}|${S.k}`, w, h, (g) => g.drawImage(cardImage("back", w, h, S.k, back), 0, 0, w + 8, h + 8));
          moveLayer(sp.l, `translate(${(px - w / 2 - 4).toFixed(1)}px,${(py - h / 2 - 4).toFixed(1)}px) rotate(${r.toFixed(3)}rad) scale(${sc.toFixed(3)})`, "1");
        }
      });
    }
    if (m.show) {
      const shown = obj(obj(S.st.table).showdown);
      const [w, h] = CARD_B;
      m.show.order.forEach(({ s, i }, si) => {
        const codes = arr(shown[String(s.seat)]);
        for (let c = 0; c < m.ncards; c++) {
          const f = showFlip(m.show.age, si, c);
          const start = SHOW.LEAD + si * SHOW.SEAT + c * SHOW.CARD;
          const g0 = clamp((m.show.age - (start - SHOW.GROW)) / SHOW.GROW, 0, 1); // slide out to the face-up spread
          const [x0, y0, r0] = pokerCardXY(i, m.n, c, m.ncards, false);
          const [x1, y1, r1] = pokerCardXY(i, m.n, c, m.ncards, true);
          const e = easeOut(g0);
          const face = f >= 0.5;
          const code = codes[c];
          const sp = cardSprite(S, used++, face ? `f|${code}|${S.k}` : `b|${back}|${S.k}`, w, h, (g) =>
            g.drawImage(face ? cardImage(code, w, h, S.k, null) : cardImage("back", w, h, S.k, back), 0, 0, w + 8, h + 8));
          const sx = Math.max(0.02, Math.abs(Math.cos(f * Math.PI)));
          const lift = 1 + 0.09 * Math.sin(f * Math.PI);
          const base = lerp(CARD_S[0] / w, 1, e);
          const px = lerp(x0, x1, e);
          const py = lerp(y0, y1, e) - 14 * Math.sin(f * Math.PI);
          moveLayer(sp.l, `translate(${(px - w / 2 - 4).toFixed(1)}px,${(py - h / 2 - 4).toFixed(1)}px) rotate(${lerp(r0, r1, e).toFixed(3)}rad) scale(${(base * sx * lift).toFixed(3)},${(base * lift).toFixed(3)})`, "1");
        }
      });
    }
    cardSpritesHideFrom(S, used);
  }

  /** The table layer's key for a poker table: it redraws when the deal or the show changes stage, not per frame. */
  function pokerKey(S, m) {
    const st = S.st;
    let k = m.deal ? (m.deal.since < 0 ? "d0" : "d1") : "";
    if (m.show) k += m.show.age < 0 ? "|s0" : m.show.age < m.show.end ? "|s1" : "|s2";
    if (st.phase === "betting" || st.phase === "idle") {
      const left = leftTo(S, "ends_at", S.clk.ends, S.t);
      if (left != null) k += `|${Math.ceil(left - 1e-6)}`; // the lobby's countdown digit
    }
    const fl = obj(obj(st.table).flash);
    if (fl.age != null) k += num(fl.age) + (S.t - (S.ctx.stateAt || S.t)) < 2.6 ? "|f" : "";
    return k;
  }

  /** One seat round the oval: avatar, name plate with the stack, hole cards (backs, or the show), bet chips. */
  function pokerSeat(S, g, t, seat, i, n, o) {
    const th = S.th;
    const [x, y, a] = pokerSeatXY(i, n);
    const p = { ...playerOf(S, seat.seat), color: seat.color || seatColor(S, seat.seat), name: seat.name };
    const out = !!seat.folded || seat.sitting === false;
    const alpha = out ? 0.45 : 1;
    const towardX = PK.cx - x;
    const towardY = PK.cy - y;
    const dl = Math.hypot(towardX, towardY) || 1;
    const ux = towardX / dl;
    const uy = towardY / dl;
    // cards (none while the deal or the show has them in flight as sprites)
    const shown = o.showdown ? arr(o.showdown[String(seat.seat)]) : [];
    const ncards = o.ncards;
    const mo = o.motion;
    const sprites = mo && (mo.deal || (mo.show && shown.length && mo.show.age < mo.show.end));
    if (o.live && !seat.folded && !sprites) {
      const winner = o.winners && o.winners.has(String(seat.seat));
      const glowing = o.glowShow && shown.length;
      for (let c = 0; c < ncards; c++) {
        const [cx, cy, rot] = pokerCardXY(i, n, c, ncards, !!shown.length);
        const code = shown[c];
        if (code) {
          // the winning hand lifts and glows in the table's accent; the others dim (teen patti); hold'em lights its best five
          const lit = o.best ? o.best.has(code) : glowing && winner;
          const dim = glowing && !winner && !o.best ? 0.32 : 0;
          const ff = o.flipSynced ? { flip: 1 } : cardFly(S, `sd${seat.seat}c${c}`, cx, cy, cx, cy, t, 0.5);
          drawCard(S, g, code, cx, cy - (lit ? 12 : 0), CARD_B[0], CARD_B[1], { flip: ff.flip, rot, glow: lit ? th.accent : null, dim });
        } else {
          const f = o.synced ? { x: cx, y: cy, rot: 0, flip: 1 } : cardFly(S, `h${seat.seat}c${c}`, PK.cx, PK.cy, cx, cy, t, 0.45);
          drawCard(S, g, "back", f.x, f.y, CARD_S[0], CARD_S[1], { down: true, rot: rot + f.rot, alpha: f.flip < 1 ? 0.6 + 0.4 * f.flip : 1 });
        }
      }
      // the hand's name under a shown hand: gold for the winner
      const hand = o.hands && o.hands[String(seat.seat)];
      if (shown.length && hand && glowing) {
        const [cx, cy] = pokerCardXY(i, n, (ncards - 1) / 2, ncards, true);
        const d = CARD_B[1] / 2 + 26; // on the felt side of the cards, clear of the avatar
        pill(g, String(hand).toUpperCase(), cx + ux * d, cy + uy * d, 20, winner ? th.accent : "rgba(0,0,0,.72)", winner ? th.ink : INK2, { align: "center", weight: 850 });
      }
    }
    // the bet in front (gone to the pot once the hand is decided)
    if (num(seat.bet) > 0 && !o.finished) {
      const bx = x + ux * 225;
      const by = y + uy * 200;
      stack(S, g, bx, by, 24, num(seat.bet), p.color);
      txt(g, fmt(S, seat.bet), bx + 32, by + 9, 24, INK1, { font: "mono", weight: 800 });
    }
    // avatar + plate
    const winner = o.winners && o.winners.has(String(seat.seat));
    if (seat.turn) {
      const tc = S.fx.turnCd || (S.fx.turnCd = new Countdown());
      const tb = obj(S.st.table);
      tc.observe(`${seat.seat}|${arr(tb.log).length}|${tb.hand}`, tb.turn_in, S.ctx.stateAt || t);
      hudRing(S, `turn${seat.seat}`, x, y, 58, { left: tc.left(t), span: num(tb.turn_span, 20), color: th.accent, low: BAD, lowBelow: 5, label: false, width: 8 });
    }
    if (winner) {
      // a steady gold ring (it used to pulse at the table layer's 4 Hz — a stutter)
      const rad = 64;
      glowFx(g, `wring|${rad}`, x - rad - 3, y - rad - 3, 2 * rad + 6, 2 * rad + 6, th.accent, 30, (m) => {
        circle(m, x, y, rad);
        m.lineWidth = 6;
        m.strokeStyle = "#000";
        m.stroke();
      });
      circle(g, x, y, rad);
      g.strokeStyle = th.accent;
      g.lineWidth = 6;
      g.stroke();
    }
    avatar(S, g, x, y, 44, p, { alpha, glow: seat.turn || winner });
    const [plx, ply, plw, plh] = pokerPlate(i, n);
    rr(g, plx, ply, plw, plh, 14);
    // the plate: the gallery's leather in the dark, ivory with a gold hairline in the daylight salon
    g.fillStyle = seat.turn ? rgba(th.accent, P.light ? 0.18 : 0.25) : P.light ? "rgba(255,253,248,.94)" : "rgba(8,8,12,.82)";
    g.fill();
    g.lineWidth = 2;
    g.strokeStyle = seat.turn ? th.accent : P.light ? "rgba(184,137,42,.65)" : rgba(p.color, 0.7);
    g.stroke();
    txt(g, p.name || `P${seat.seat}`, x, ply + 28, 24, inkOf(p.color), { align: "center", weight: 800, maxW: 200, alpha, shadow: !P.light });
    txt(g, seat.stack != null ? fmt(S, seat.stack) : "", x, ply + 54, 22, P.light ? P.ink1 : INK1, { align: "center", font: "mono", weight: 700, alpha, shadow: !P.light });
    // markers and the last action
    const tags = o.tags ? o.tags(seat) : [];
    tags.forEach((tg, k) => {
      const tx = x + (k % 2 ? -1 : 1) * 56;
      const ty = y - 40 + Math.floor(k / 2) * 30;
      pill(g, tg.text, tx, ty, 16, tg.bg, tg.fg || "#fff", { align: "center" });
    });
    const fl = obj(obj(S.st.table).flash);
    const age = fl.age != null ? num(fl.age) + (t - (S.ctx.stateAt || t)) : 99;
    // the plate's third line: the latest move lit in the accent for a moment, then the last move, quietly (both on the
    // plate, clear of the cards on the felt)
    if (String(fl.seat) === String(seat.seat) && age < 2.6) {
      const word = fl.text + (num(fl.amount) && !/FOLD|PACK|CHECK|SEEN/.test(fl.text) ? ` ${fmt(S, fl.amount)}` : "");
      pill(g, word, x, ply + plh - 15, 17, th.accent, th.ink, { align: "center", weight: 850 });
    } else if (seat.last && o.live && !(o.finished && S.st.phase === "result")) {
      txt(g, String(seat.last), x, ply + plh - 9, 16, P.light ? P.ink2 : INK2, { align: "center", weight: 800, spacing: 1, shadow: false, alpha });
    }
    if (seat.folded) pill(g, o.foldWord || "FOLDED", x, y, 18, "rgba(10,10,14,.86)", INK2, { align: "center", weight: 850 });
  }

  function pokerLobby(S, g, t, needs) {
    const st = S.st;
    const th = S.th;
    const n = arr(st.sitting).length;
    const left = leftTo(S, "ends_at", S.clk.ends, t);
    if (left != null) {
      txt(g, "NEXT HAND IN", PK.cx, PK.cy - 40, 30, INK2, { align: "center", weight: 800 });
      txt(g, String(Math.ceil(left - 1e-6)), PK.cx, PK.cy + 60, 110, th.accent, { align: "center", font: "mono", weight: 800, glow: rgba(th.accent, 0.5) });
    } else {
      txt(g, n >= 2 ? "DEALING SOON" : "WAITING FOR PLAYERS", PK.cx, PK.cy, 46, th.accent, { align: "center", weight: 900 });
      txt(g, `${n} in · at least two to deal · ${needs}`, PK.cx, PK.cy + 50, 26, INK2, { align: "center", weight: 650 });
    }
  }
  /** The deck on the felt while the hand is shuffled and dealt (a few offset backs). */
  function pokerDeck(S, g, m) {
    const [x, y] = deckXY(m.n, m.dealerIdx);
    const back = cardBack(S);
    for (let i = 0; i < 4; i++) drawCard(S, g, "back", x - i * 1.5, y - i * 2.5, CARD_S[0], CARD_S[1], { down: true, back, rot: -0.12 });
  }

  const pokerClip = () => `ellipse(${PK.rx}px ${PK.ry}px at ${PK.cx}px ${PK.cy}px)`;
  /** What both poker tables share: the oval, the deal / show sprites and the redraw rule. */
  function pokerDef(def, ncards, dealerOf, withShow) {
    const m = (S) => S.fx.m || (S.fx.m = pokerMotion(S, ncards, -1, withShow));
    return Object.assign({
      feltClip: pokerClip,
      bgKey: (S) => String(pokerSeats(S).seats.length), // the engraved title depends on where the seats are
      overlays(S, root) {
        S.cardBox = document.createElement("div");
        Object.assign(S.cardBox.style, { position: "absolute", left: "0px", top: "0px", width: "0px", height: "0px", pointerEvents: "none" });
        root.appendChild(S.cardBox);
      },
      move(S) {
        const { seats } = pokerSeats(S);
        S.fx.m = pokerMotion(S, ncards, dealerOf(S, seats), withShow);
        pokerFrame(S, S.fx.m);
      },
      key: (S) => pokerKey(S, m(S)),
      bannerY: 340, // the moment's banner and ticker clear of the bottom seat's hand
      slowHz: () => 0, // the turn clocks sweep in their own canvases; the table redraws on change only
    }, def);
  }
  const holdem = makeScene(pokerDef({
    id: "casino-holdem",
    app: "casino_holdem",
    bg(S, g) {
      pokerBg(S, g, "TEXAS HOLD'EM");
    },
    turnSeat: (S) => obj(S.st.table).turn_seat,
    railInfo(S, p) {
      const seat = arr(obj(S.st.table).seats).find((s) => String(s.seat) === String(p.seat));
      if (S.st.phase === "result") {
        const w = winners(S).find((x) => String(x.seat) === String(p.seat));
        if (w) return { text: `WON ${signed(S, num(w.net))}`, color: P.light ? "#18794e" : OK };
      }
      if (seat && S.st.phase !== "betting") return { text: seat.folded ? "FOLDED" : seat.allin ? "ALL-IN" : `IN · ${fmt(S, seat.total)} IN THE POT`, color: seat.folded ? INK3 : INK2 };
      return { text: arr(S.st.sitting).some((s) => String(s) === String(p.seat)) ? "DEALT IN NEXT HAND" : "SITTING OUT", color: INK3 };
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const tb = obj(st.table);
      const { live, seats } = pokerSeats(S);
      const m = S.fx.m || pokerMotion(S, 2, -1, false);
      const result = st.phase === "result" || tb.finished;
      const winSet = new Set(arr(tb.winners).map((w) => String(w.seat)));
      const best = new Set();
      if (result) for (const w of arr(tb.winners)) for (const c of arr(w.best)) best.add(c);
      // the board
      const board = live ? arr(tb.board) : [];
      for (let i = 0; i < 5; i++) {
        const x = PK.cx - 2 * 116 + i * 116;
        cardSlot(g, x, PK.cy, 104, 146, rgba("#ffffff", 0.18));
        if (board[i]) {
          const f = cardFly(S, `b${i}`, PK.cx, PK.cy - 260, x, PK.cy, t, 0.5 + i * 0.05);
          drawCard(S, g, board[i], f.x, f.y, 104, 146, { flip: f.flip, glow: best.has(board[i]) ? th.accent : null, dim: result && best.size && !best.has(board[i]) ? 0.35 : 0 });
        }
      }
      if (m.deal) pokerDeck(S, g, m);
      if (live) {
        const pots = arr(tb.pots);
        const pot = num(tb.pot);
        if (pot > 0) stack(S, g, PK.cx - 90, PK.cy - 125, 26, pot, th.accent);
        txt(g, `POT ${fmt(S, pot)}`, PK.cx - 54, PK.cy - 114, 34, INK1, { font: "mono", weight: 800 });
        if (pots.length > 1) txt(g, pots.map((p, i) => `${i ? `Side ${i}` : "Main"} ${fmt(S, p.amount)}`).join(" · "), PK.cx, PK.cy + 116, 22, INK2, { align: "center", weight: 700 });
      } else pokerLobby(S, g, t, `blinds ${arr(tb.blinds).join("/") || "–"}`);
      const showdown = obj(tb.showdown);
      seats.forEach((s, i) => {
        pokerSeat(S, g, t, s, i, seats.length, {
          live, ncards: 2, showdown, best, finished: !!tb.finished, winners: result ? winSet : null, motion: m, synced: synced(S),
          tags: (seat) => {
            const out = [];
            if (live && String(tb.button_seat) === String(seat.seat)) out.push({ text: "D", bg: "#f6f0e0", fg: "#111" });
            if (live && String(tb.sb_seat) === String(seat.seat)) out.push({ text: "SB", bg: "#1f5fe0" });
            if (live && String(tb.bb_seat) === String(seat.seat)) out.push({ text: "BB", bg: "#d0182f" });
            if (seat.allin) out.push({ text: "ALL-IN", bg: "#ff7419" });
            if (!live && !seat.sitting) out.push({ text: "OUT", bg: "#44444f" });
            return out;
          },
        }); // fmt: skip
      });
      // the headline and the log
      const street = { preflop: "PRE-FLOP", flop: "THE FLOP", turn: "THE TURN", river: "THE RIVER" }[tb.street] || "";
      drawHeadline(S, g, 40, 20, 470, t, headline(S, t, (p) => {
        if (p === "betting") return { title: "NEXT HAND", sub: `Blinds ${arr(tb.blinds).join(" / ")} · hand #${num(tb.hand) + 1}`, tone: th.accent };
        if (p === "locked" || p === "dealing" || p === "action") {
          if (tb.finished) return { title: "SHOWDOWN", sub: street, tone: th.accent };
          const who = tb.turn_seat != null ? playerOf(S, tb.turn_seat) : null;
          return { title: street || "DEALING", sub: who ? `${who.name || `P${tb.turn_seat}`} to act · to call ${fmt(S, tb.cur_bet)}` : "Dealing…", tone: th.accent_hi };
        }
        if (p === "result") {
          const w = arr(tb.winners)[0];
          return { title: w ? `${w.name} WINS ${fmt(S, w.won)}` : "HAND OVER", sub: w && w.hand ? String(w.hand).toUpperCase() : "Everyone else folded", tone: th.accent };
        }
        return null;
      }), { size: 44, room: true });
      txt(g, `HAND #${num(tb.hand)} · BLINDS ${arr(tb.blinds).join("/")}`, 1500, 50, 22, roomInk(INK2), { align: "right", weight: 800, shadow: !P.light });
      arr(tb.log).slice(-5).forEach((line, i, all) => txt(g, line, 40, 960 - (all.length - 1 - i) * 30, 22, roomInk(i === all.length - 1 ? INK1 : INK3), { weight: 650, shadow: !P.light }));
    },
  }, 2, (S, seats) => seats.findIndex((s) => String(s.seat) === String(obj(S.st.table).button_seat)), false));

  const teenpatti = makeScene(pokerDef({
    id: "casino-teenpatti",
    app: "casino_teenpatti",
    bg(S, g) {
      pokerBg(S, g, "TEEN PATTI");
    },
    turnSeat: (S) => obj(S.st.table).turn_seat,
    railInfo(S, p) {
      const seat = arr(obj(S.st.table).seats).find((s) => String(s.seat) === String(p.seat));
      if (S.st.phase === "result") {
        const w = winners(S).find((x) => String(x.seat) === String(p.seat));
        if (w) return { text: `WON ${signed(S, num(w.net))}`, color: P.light ? "#18794e" : OK };
      }
      if (seat && S.st.phase !== "betting") return { text: seat.folded ? "PACKED" : `${seat.seen ? "SEEN" : "BLIND"} · ${fmt(S, seat.total)} IN`, color: seat.folded ? INK3 : INK2 };
      return { text: arr(S.st.sitting).some((s) => String(s) === String(p.seat)) ? "DEALT IN NEXT HAND" : "SITTING OUT", color: INK3 };
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const tb = obj(st.table);
      const { live, seats } = pokerSeats(S);
      const m = S.fx.m || pokerMotion(S, 3, -1, true);
      const result = st.phase === "result" || tb.finished;
      const winSet = new Set(arr(tb.winners).map((w) => String(w.seat)));
      // the winning hand glows once every hand of the show has turned (at once on a screen without the clock)
      const glowShow = !!tb.finished && (!m.show || m.show.age >= m.show.glow - SHOW.GLOW);
      if (m.deal || st.phase === "locked") pokerDeck(S, g, m);
      if (live) {
        if (num(tb.pot) > 0) stack(S, g, PK.cx - 80, PK.cy - 20, 30, num(tb.pot), th.accent);
        txt(g, `POT ${fmt(S, tb.pot)}`, PK.cx - 38, PK.cy - 6, 40, INK1, { font: "mono", weight: 800 });
        txt(g, `BOOT ${fmt(S, tb.boot)} · STAKE ${fmt(S, tb.stake)}`, PK.cx, PK.cy + 44, 24, INK2, { align: "center", weight: 750 });
      } else pokerLobby(S, g, t, `boot ${fmt(S, num(st.buy_in))}`);
      seats.forEach((s, i) => {
        pokerSeat(S, g, t, s, i, seats.length, {
          live, ncards: 3, showdown: obj(tb.showdown), best: null, finished: !!tb.finished, winners: glowShow ? winSet : null,
          motion: m, synced: synced(S), flipSynced: synced(S), glowShow, hands: obj(tb.hands), foldWord: "PACKED",
          tags: (seat) => {
            const out = [];
            if (live && seat.dealer) out.push({ text: "D", bg: "#f6f0e0", fg: "#111" });
            if (live && !seat.folded) out.push(seat.seen ? { text: "SEEN", bg: "#1f5fe0" } : { text: "BLIND", bg: "#44444f" });
            if (seat.allin) out.push({ text: "ALL-IN", bg: "#ff7419" });
            if (!live && !seat.sitting) out.push({ text: "OUT", bg: "#44444f" });
            return out;
          },
        }); // fmt: skip
      });
      // events: side shows and shows
      const ss = tb.sideshow;
      const ev = obj(tb.event);
      let banner = null;
      if (ss) banner = `${playerOf(S, ss.from).name || "?"} asks ${playerOf(S, ss.to).name || "?"} for a SIDESHOW · ${num(ss.in)}s`;
      else if (ev.kind === "sideshow") banner = `SIDESHOW: ${playerOf(S, ev.loser).name || "?"} packs`;
      else if (ev.kind === "refused") banner = `${playerOf(S, ev.with).name || "?"} refused the sideshow`;
      else if (ev.kind === "show") banner = !glowShow ? "SHOW!" : ev.tie ? "SHOW — a tie: the asker loses" : `SHOW — ${playerOf(S, ev.winner).name || "?"} wins it`; // the winner only once the hands have turned
      if (banner && live && st.phase !== "result") pill(g, banner, PK.cx, PK.cy - 120, 26, rgba(th.accent, 0.92), th.ink, { align: "center" });
      drawHeadline(S, g, 40, 20, 470, t, headline(S, t, (p) => {
        if (p === "betting") return { title: "NEXT HAND", sub: `Boot ${fmt(S, num(st.buy_in))} · hand #${num(tb.hand) + 1}`, tone: th.accent };
        if (p === "locked" || p === "dealing" || p === "action") {
          if (tb.finished) return { title: "SHOW", sub: "The hands turn over", tone: th.accent };
          if (m.deal || p === "locked") return { title: "DEALING", sub: "Three cards each, face down", tone: th.accent_hi };
          const who = tb.turn_seat != null ? playerOf(S, tb.turn_seat) : null;
          return { title: who ? `${who.name || `P${tb.turn_seat}`} TO ACT` : "DEALING", sub: "Chaal, raise, show or pack", tone: who ? seatColor(S, tb.turn_seat) : th.accent_hi };
        }
        if (p === "result") {
          const w = arr(tb.winners)[0];
          return { title: w ? `${w.name} WINS ${fmt(S, w.won)}` : "HAND OVER", sub: w && w.hand ? String(w.hand).toUpperCase() : "Everyone else packed", tone: th.accent };
        }
        return null;
      }), { size: 44, room: true });
      txt(g, `HAND #${num(tb.hand)}`, 1500, 50, 22, roomInk(INK2), { align: "right", weight: 800, shadow: !P.light });
      arr(tb.log).slice(-5).forEach((line, i, all) => txt(g, line, 40, 960 - (all.length - 1 - i) * 30, 22, roomInk(i === all.length - 1 ? INK1 : INK3), { weight: 650, shadow: !P.light }));
    },
  }, 3, (S, seats) => seats.findIndex((s) => s.dealer), true));

  // ================================================================================================ HOUSIE
  // The 1–90 board on the left (inside the felt), the draw on the right: a brass wire cage that tumbles its balls as a
  // call comes, the drawn ball rolling down a rail into the cradle, the number stamped onto the board, the prizes
  // under it — and a ribbon for every verified claim. Timing is the engine's: the next call (clock.call_at), the call
  // just made (clock.called_at) and the latest claim (clock.claim_at), on the shared clock, so every screen drops
  // the same ball in the same frame. The number itself is only ever the one the engine has called (status.housie).
  const HB = { x: 62, y: 166, cw: 76, ch: 80 };
  const HZ = 878; // the right-hand zone: x from here to the felt's edge (≈ 1476)
  const CAGE = { x: 1010, y: 296, r: 126 };
  const HERO = { x: 1338, y: 286, r: 100 };
  const RAIL = { x0: 1102, y0: 402, x1: 1236, y1: 440 };
  const HOUSIE_T = { SPIN0: 1.4, SPIN1: 1.0, TURNS: 3, EXIT: 0.3, ROLL: 0.95, HOP: 1.3, STAMP: 1.55, CLAIM: 3.6 };
  const TUMBLE = 9;
  function housieCell(n) {
    const i = n - 1;
    return [HB.x + (i % 10) * HB.cw, HB.y + Math.floor(i / 10) * HB.ch];
  }
  /** A housie ball (number n, radius r), stamped from a sprite drawn once per number / size. */
  const ballCache = new Map();
  function ball(g, x, y, r, n, color) {
    const k = chipK(g);
    const key = `${r}|${n}|${color}|${k}`;
    let sp = ballCache.get(key);
    if (!sp) {
      if (ballCache.size > 200) ballCache.clear();
      const D = Math.ceil(r * 2.8);
      const m = makeCanvas(D, D, k);
      ballRaw(m.g, D / 2, D / 2, r, n, color);
      sp = { c: m.c, D };
      ballCache.set(key, sp);
    }
    g.drawImage(sp.c, x - sp.D / 2, y - sp.D / 2, sp.D, sp.D);
  }
  function ballRaw(g, x, y, r, n, color) {
    g.save();
    g.shadowColor = "rgba(0,0,0,.6)";
    g.shadowBlur = r * 0.4;
    g.shadowOffsetY = r * 0.1;
    circle(g, x, y, r);
    const gr = g.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
    gr.addColorStop(0, shade(color, 1.5));
    gr.addColorStop(0.6, color);
    gr.addColorStop(1, shade(color, 0.5));
    g.fillStyle = gr;
    g.fill();
    g.restore();
    if (n == null) return; // a tumbling ball: its number faces away
    circle(g, x, y, r * 0.62);
    g.fillStyle = "#fbf8f1";
    g.fill();
    txt(g, String(n), x, y + r * 0.22, r * (n >= 10 ? 0.6 : 0.72), "#15151c", { align: "center", weight: 900, shadow: false });
  }
  const housieColor = (n) => ["#e0263c", "#ff7419", "#e0a800", "#3ddc84", "#33d1ff", "#1f6fff", "#a64dff", "#ff3f78", "#12b35a"][Math.min(8, Math.floor(n / 10))];

  /**
   * The cage's turn (radians) at engine time T: at rest between calls; around each call it winds up over SPIN0 s,
   * the ball drops at the call, and it runs down over SPIN1 s — TURNS whole turns per call (a smootherstep), so it
   * always comes to rest square. `calls` are the call moments near T (the last one made, the next one due).
   * → {a, w}: the angle and its speed (rad/s).
   */
  function cageTurn(T, calls) {
    const span = HOUSIE_T.SPIN0 + HOUSIE_T.SPIN1;
    for (const c of calls) {
      if (typeof c !== "number") continue;
      const u = (T - c + HOUSIE_T.SPIN0) / span;
      if (u <= 0 || u >= 1) continue;
      const s = u * u * u * (u * (u * 6 - 15) + 10);
      const ds = (30 * u * u * (u - 1) * (u - 1)) / span;
      return { a: TAU * HOUSIE_T.TURNS * s, w: TAU * HOUSIE_T.TURNS * ds };
    }
    return { a: 0, w: 0 };
  }
  /**
   * The drawn ball `age` s after its call: out of the cage's mouth, down the rail (rolling), a hop into the cradle
   * where it grows to the hero size. → {x, y, s (scale of the hero sprite), rot, op} or null before the call.
   */
  function heroPath(age) {
    if (age == null || age < 0) return null;
    const T = HOUSIE_T;
    const small = 24 / HERO.r;
    if (age < T.EXIT) {
      const u = easeIn(age / T.EXIT);
      return { x: lerp(CAGE.x + 30, RAIL.x0, u), y: lerp(CAGE.y + 40, RAIL.y0, u), s: small, rot: u * 2, op: clamp(age / 0.08, 0, 1) };
    }
    if (age < T.ROLL) {
      const u = (age - T.EXIT) / (T.ROLL - T.EXIT);
      const e = u * (0.6 + 0.4 * u); // it gathers speed down the slope
      const x = lerp(RAIL.x0, RAIL.x1, e);
      const y = lerp(RAIL.y0, RAIL.y1, e) - Math.abs(Math.sin(u * Math.PI * 3)) * 6 * (1 - u);
      return { x, y, s: small, rot: 2 + Math.hypot(x - RAIL.x0, y - RAIL.y0) / 24, op: 1 };
    }
    const r0 = 2 + Math.hypot(RAIL.x1 - RAIL.x0, RAIL.y1 - RAIL.y0) / 24;
    const u = clamp((age - T.ROLL) / (T.HOP - T.ROLL), 0, 1);
    const e = easeOut(u);
    const back = easeOutBack(u);
    return {
      x: lerp(RAIL.x1, HERO.x, e),
      y: lerp(RAIL.y1, HERO.y, e) - Math.sin(u * Math.PI) * 70,
      s: lerp(small, 1, back),
      rot: wrapPi(r0) * (1 - e), // it spins square as it settles: the number reads upright
      op: 1,
    };
  }
  /** The engine's call / claim moments as ages on this screen (synced clock, else local fallbacks). */
  function housieAges(S) {
    const ck = obj(S.st.clock);
    const on = synced(S);
    const callAge = on && typeof ck.called_at === "number" ? S.T - ck.called_at : S.fx.callAt != null ? S.t - S.fx.callAt : null;
    const claimAge = on && typeof ck.claim_at === "number" ? S.T - ck.claim_at : S.fx.claimAt != null ? S.t - S.fx.claimAt : null;
    return { callAge, claimAge };
  }
  /** The claim ribbon's tier: lines are big, the full house is the jackpot. */
  const claimTier = (prize) => (prize === "full" ? "jackpot" : prize === "top" || prize === "middle" || prize === "bottom" ? "big" : "win");
  const RIB = { w: 820, h: 210 };
  function ribbonPaint(S, name, who, color, prize) {
    const L = S.L.claim;
    const key = `${name}|${who}|${color}|${prize}`;
    if (L.key === key) return;
    L.key = key;
    const T = TIERS[claimTier(prize)];
    const l = L.rib;
    const g = l.g;
    g.setTransform(l.k, 0, 0, l.k, 0, 0);
    g.clearRect(0, 0, RIB.w, RIB.h);
    const cx = RIB.w / 2;
    const cy = 88;
    g.save();
    g.beginPath();
    g.moveTo(80, cy - 62);
    g.lineTo(RIB.w - 80, cy - 62);
    g.lineTo(RIB.w - 34, cy);
    g.lineTo(RIB.w - 80, cy + 62);
    g.lineTo(80, cy + 62);
    g.lineTo(34, cy);
    g.closePath();
    softStroke(g, 0, 24, "#000", 0.7, 0, 10, 5);
    const rb = g.createLinearGradient(0, cy - 62, 0, cy + 62);
    rb.addColorStop(0, shade(T.c[3], 1.6));
    rb.addColorStop(0.5, T.c[3]);
    rb.addColorStop(1, shade(T.c[3], 0.6));
    g.fillStyle = rb;
    g.fill();
    g.lineWidth = 4;
    g.strokeStyle = T.c[1];
    g.stroke();
    g.restore();
    const word = `${String(name).toUpperCase()}!`;
    g.save();
    g.font = `italic 900 84px ${FONT}`;
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.lineJoin = "round";
    g.strokeStyle = T.glow;
    for (let i = 3; i >= 1; i--) {
      g.globalAlpha = 0.12;
      g.lineWidth = 10 + i * 12;
      g.strokeText(word, cx, cy, RIB.w - 150);
    }
    g.globalAlpha = 1;
    g.lineWidth = 12;
    g.strokeStyle = shade(T.c[3], 0.7);
    g.strokeText(word, cx, cy, RIB.w - 150);
    g.lineWidth = 5;
    g.strokeStyle = T.c[0];
    g.strokeText(word, cx, cy, RIB.w - 150);
    const mg = g.createLinearGradient(0, cy - 42, 0, cy + 42);
    mg.addColorStop(0, T.c[0]);
    mg.addColorStop(0.45, T.c[1]);
    mg.addColorStop(0.55, T.c[2]);
    mg.addColorStop(1, T.c[1]);
    g.fillStyle = mg;
    g.fillText(word, cx, cy, RIB.w - 150);
    g.restore();
    // who claimed it, on a dark lozenge in their colour
    const sub = `${who || "?"} claims it`;
    g.font = `850 30px ${FONT}`;
    const sw = Math.min(RIB.w - 200, (g.measureText(sub).width || sub.length * 16) + 56);
    rr(g, cx - sw / 2, cy + 70, sw, 46, 23);
    g.fillStyle = "rgba(10,10,14,.92)";
    g.fill();
    g.lineWidth = 2;
    g.strokeStyle = color || T.c[1];
    g.stroke();
    txt(g, sub, cx, cy + 104, 30, color || INK1, { align: "center", weight: 850, shadow: false, maxW: sw - 30 });
    l.show();
  }

  const housie = makeScene({
    id: "casino-housie",
    app: "casino_housie",
    ingest(S, st, t) {
      const h = obj(st.housie);
      const called = num(h.called);
      if (S.fx.called !== called) {
        if (called > num(S.fx.called) && !S.firstIngest) S.fx.callAt = t;
        S.fx.called = called;
      }
      // call_in is exact to 0.1 s: the next call is due at stateAt + call_in
      S.fx.nextCall = typeof h.call_in === "number" ? t + h.call_in : null;
      // the latest claim (fallback without clock.claim_at: its age when the state was built)
      const fl = obj(h.flash);
      const fk = fl.name ? `${fl.prize}|${fl.seat}` : "";
      if (fk !== S.fx.claimKey) {
        S.fx.claimKey = fk;
        S.fx.claimAt = fl.name ? t - num(fl.age) : null;
      }
    },
    // the cage: its tumbling balls under the turning wire drum; the drawn ball (two sprites: the one arriving, the
    // one leaving the cradle); the claim ribbon over the board
    layers(S, root) {
      const k = wheelK();
      const D = Math.ceil(17 * 2.8);
      S.fx.tumble = [];
      for (let i = 0; i < TUMBLE; i++) {
        const l = layer(root, 0, 0, D, D, k, true, true);
        ballRaw(l.g, D / 2, D / 2, 17, null, housieColor(1 + Math.floor(hash01(`tb${i}`) * 89)));
        S.fx.tumble.push(l);
      }
      const W = 2 * CAGE.r + 16;
      S.L.drum = layer(root, CAGE.x - W / 2, CAGE.y - W / 2, W, W, k, true, true);
      const g = S.L.drum.g;
      g.save();
      g.translate(W / 2, W / 2);
      const brass = (lw, a) => {
        g.lineWidth = lw;
        g.strokeStyle = `rgba(230,196,106,${a})`;
      };
      // the wire drum: two rims, spokes, a lattice of wires (seen face on, it turns about its axle)
      g.shadowColor = "rgba(0,0,0,.5)";
      g.shadowBlur = 3;
      g.shadowOffsetY = 1;
      brass(7, 1);
      circle(g, 0, 0, CAGE.r);
      g.stroke();
      brass(3, 0.8);
      circle(g, 0, 0, CAGE.r - 14);
      g.stroke();
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        brass(i % 3 ? 2 : 4, i % 3 ? 0.55 : 0.95);
        g.beginPath();
        g.moveTo(Math.cos(a) * 16, Math.sin(a) * 16);
        g.lineTo(Math.cos(a) * CAGE.r, Math.sin(a) * CAGE.r);
        g.stroke();
      }
      brass(1.5, 0.35);
      for (const rr0 of [42, 70, 98]) {
        circle(g, 0, 0, rr0);
        g.stroke();
      }
      // the hatch the balls leave by, and the hub
      brass(5, 1);
      g.beginPath();
      g.arc(0, 0, CAGE.r, -0.2, 0.2);
      g.stroke();
      g.shadowBlur = 0;
      circle(g, 0, 0, 16);
      const hg = g.createRadialGradient(-5, -6, 1, 0, 0, 16);
      hg.addColorStop(0, "#fff6d0");
      hg.addColorStop(0.5, "#e6c46a");
      hg.addColorStop(1, "#6a4712");
      g.fillStyle = hg;
      g.fill();
      g.restore();
      const H = 2 * HERO.r + 40;
      S.L.hero = [0, 1].map(() => {
        const l = layer(root, 0, 0, H, H, k, true, true);
        l.c.style.display = "none";
        l.cache = { display: "none" };
        return l;
      });
      S.L.heroN = [null, null];
    },
    overlays(S, root) {
      stampLayers(S, root, "dab");
      const rib = layer(root, 0, 0, RIB.w, RIB.h, Math.min(tableK(), 1.25), true);
      rib.c.style.display = "none";
      rib.cache = { display: "none" };
      const burst = layer(root, 0, 0, BURST, BURST, 1, false);
      burst.c.style.display = "none";
      S.L.claim = { rib, burst, key: null };
    },
    move(S) {
      const st = S.st;
      const h = obj(st.housie);
      const ck = obj(st.clock);
      const calls = arr(h.calls);
      const last = calls[calls.length - 1];
      const { callAge, claimAge } = housieAges(S);
      const playing = st.phase === "dealing" || st.phase === "result";
      // the cage: winds up toward the next call, drops the ball at the call, runs down
      const cg = synced(S)
        ? cageTurn(S.T, [ck.called_at, ck.call_at])
        : cageTurn(S.t, [S.fx.callAt, S.fx.nextCall]);
      const spin = playing ? cg : { a: 0, w: 0 };
      const dtf = `rotate(${spin.a.toFixed(3)}rad)`;
      if (S.fx.drumTf !== dtf) S.L.drum.c.style.transform = S.fx.drumTf = dtf;
      const kk = clamp(spin.w / 6, 0, 1); // 0: the balls lie in a heap; 1: they ride the drum
      const D = Math.ceil(17 * 2.8);
      S.fx.tumble.forEach((l, i) => {
        const h1 = hash01(`tb${i}a`);
        const h2 = hash01(`tb${i}b`);
        const pile = [CAGE.x + (i - (TUMBLE - 1) / 2) * 22 + (i % 2) * 6, CAGE.y + CAGE.r - 34 - (i % 3) * 18 - Math.abs(i - 4) * -3];
        const a = spin.a * (0.75 + 0.25 * h1) + h2 * TAU;
        const rad = CAGE.r * (0.35 + 0.42 * h1) + 8 * Math.sin(spin.a * 1.7 + i);
        const orbit = [CAGE.x + Math.cos(a) * rad, CAGE.y + Math.sin(a) * rad];
        const x = lerp(pile[0], orbit[0], kk);
        const y = lerp(pile[1], orbit[1], kk);
        moveLayer(l, `translate(${(x - D / 2).toFixed(1)}px,${(y - D / 2).toFixed(1)}px)`, "1");
      });
      // the drawn ball, and the one before it leaving the cradle
      const idx = calls.length % 2;
      const cur = S.L.hero[idx];
      const old = S.L.hero[1 - idx];
      const H = 2 * HERO.r + 40;
      const paintHero = (l, slot, n) => {
        if (S.L.heroN[slot] === n) return;
        S.L.heroN[slot] = n;
        l.g.setTransform(l.k, 0, 0, l.k, 0, 0);
        l.g.clearRect(0, 0, H, H);
        if (n != null) ballRaw(l.g, H / 2, H / 2, HERO.r, n, housieColor(n));
      };
      const p = playing && last != null ? heroPath(callAge == null ? 9 : callAge) : null;
      if (p) {
        paintHero(cur, idx, last);
        moveLayer(cur, `translate(${(p.x - H / 2).toFixed(1)}px,${(p.y - H / 2).toFixed(1)}px) rotate(${p.rot.toFixed(3)}rad) scale(${p.s.toFixed(3)})`, p.op.toFixed(3));
      } else hideLayer(cur);
      const prev = calls[calls.length - 2];
      const ou = callAge == null ? 1 : clamp(callAge / 0.35, 0, 1);
      if (p && prev != null && ou < 1) {
        paintHero(old, 1 - idx, prev);
        moveLayer(old, `translate(${(HERO.x - H / 2).toFixed(1)}px,${(HERO.y - H / 2 + 40 * ou).toFixed(1)}px) scale(${(1 - 0.4 * ou).toFixed(3)})`, (1 - ou).toFixed(3));
      } else hideLayer(old);
      // the number stamped on the board
      S.fx.stamped = callAge == null || callAge >= HOUSIE_T.STAMP;
      if (playing && last != null && callAge != null && callAge < 30) {
        const [x, y] = housieCell(last);
        stampPaint(S, "dab", String(last), housieColor(last));
        stampMove(S, "dab", x + HB.cw / 2, y + HB.ch / 2, callAge - HOUSIE_T.STAMP, 84, -0.12);
      } else stampMove(S, "dab", 0, 0, null);
      // a verified claim: the ribbon slams onto the board, sparks fly, it lifts away
      const fl = obj(h.flash);
      const C = S.L.claim;
      const ca = fl.name && claimAge != null ? claimAge : null;
      S.fx.claimOn = ca != null && ca >= 0 && ca < HOUSIE_T.CLAIM + 0.6;
      if (S.fx.claimOn) {
        ribbonPaint(S, fl.name, fl.who, fl.color, fl.prize);
        const cx = HB.x + 5 * HB.cw;
        const cy = HB.y + 4.5 * HB.ch;
        const u = clamp(ca / 0.32, 0, 1);
        const out = clamp((ca - HOUSIE_T.CLAIM) / 0.5, 0, 1);
        const sc = (u < 1 ? 1.6 - 0.6 * easeOutBack(u) : 1 + 0.02 * Math.sin((ca - 0.32) * 5)) * (1 - 0.15 * out);
        moveLayer(C.rib, `translate(${(cx - RIB.w / 2).toFixed(1)}px,${(cy - RIB.h / 2).toFixed(1)}px) scale(${sc.toFixed(3)})`, (clamp(u * 3, 0, 1) * (1 - out)).toFixed(3));
        burstDraw(S, "claim", cx, cy - 20, ca - 0.12, fl.color || S.th.accent_hi || S.th.accent);
      } else {
        hideLayer(C.rib);
        burstDraw(S, "claim", 0, 0, null);
      }
    },
    key: (S) => `${S.fx.stamped ? 1 : 0}${S.fx.claimOn ? 1 : 0}${S.st.phase === "betting" ? `|${Math.ceil(num(leftTo(S, "ends_at", S.clk.ends, S.t), -1) - 1e-6)}` : ""}${S.st.phase !== "dealing" || obj(S.st.housie).called ? "" : `|${num(obj(S.st.housie).first_in)}`}`,
    slowHz: () => 0, // the call countdown sweeps in its own canvas; the board redraws per call and per claim
    bg(S, g) {
      const th = S.th;
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 760, 480, 1100, 36);
      // the board: a dark inlaid panel with the numbers printed on it
      rr(g, HB.x - 10, HB.y - 10, 10 * HB.cw + 20, 9 * HB.ch + 20, 18);
      g.fillStyle = "rgba(0,0,0,.35)";
      g.fill();
      g.lineWidth = 2;
      g.strokeStyle = rgba(th.accent, 0.35);
      g.stroke();
      for (let n = 1; n <= 90; n++) {
        const [x, y] = housieCell(n);
        rr(g, x + 4, y + 4, HB.cw - 8, HB.ch - 8, 12);
        g.fillStyle = "rgba(255,255,255,.05)";
        g.fill();
        txt(g, String(n), x + HB.cw / 2, y + HB.ch / 2 + 12, 32, "rgba(255,255,255,.28)", { align: "center", weight: 800, shadow: false });
      }
      txt(g, "HOUSIE", HB.x - 4, 128, 46, th.accent, { weight: 700, font: "serif", gold: goldOn(), spacing: 4 });
      // the cage's stand: two brass legs from the axle to a base, the drum's dark inside, the rail and the cradle
      const brass = (lw) => {
        const gr = g.createLinearGradient(0, CAGE.y - CAGE.r, 0, 460);
        gr.addColorStop(0, "#f2d68a");
        gr.addColorStop(0.5, "#b8892a");
        gr.addColorStop(1, "#6a4712");
        g.lineWidth = lw;
        g.strokeStyle = gr;
      };
      g.save();
      g.lineCap = "round";
      g.beginPath();
      g.ellipse(CAGE.x, 462, 150, 14, 0, 0, TAU);
      g.fillStyle = "rgba(0,0,0,.35)";
      g.fill();
      brass(12);
      g.beginPath();
      g.moveTo(CAGE.x, CAGE.y);
      g.lineTo(CAGE.x - 104, 454);
      g.moveTo(CAGE.x, CAGE.y);
      g.lineTo(CAGE.x + 104, 454);
      g.stroke();
      brass(14);
      g.beginPath();
      g.moveTo(CAGE.x - 132, 456);
      g.lineTo(CAGE.x + 132, 456);
      g.stroke();
      circle(g, CAGE.x, CAGE.y, CAGE.r - 2);
      const dg = g.createRadialGradient(CAGE.x - 30, CAGE.y - 40, 10, CAGE.x, CAGE.y, CAGE.r);
      dg.addColorStop(0, "rgba(255,255,255,.10)");
      dg.addColorStop(1, "rgba(0,0,0,.45)");
      g.fillStyle = dg;
      g.fill();
      // the rail: a pair of brass rods from the hatch down to the cradle
      brass(5);
      for (const o of [-9, 9]) {
        g.beginPath();
        g.moveTo(RAIL.x0 - 6, RAIL.y0 + 14 + o * 0.3 + o);
        g.lineTo(RAIL.x1 + 18, RAIL.y1 + 14 + o * 0.3 + o);
        g.stroke();
      }
      // the cradle: a brass cup on a short pedestal under the hero ball
      brass(10);
      g.beginPath();
      g.ellipse(HERO.x, HERO.y + HERO.r - 6, 70, 14, 0, 0, Math.PI);
      g.stroke();
      brass(16);
      g.beginPath();
      g.moveTo(HERO.x, HERO.y + HERO.r + 8);
      g.lineTo(HERO.x, HERO.y + HERO.r + 40);
      g.moveTo(HERO.x - 56, HERO.y + HERO.r + 44);
      g.lineTo(HERO.x + 56, HERO.y + HERO.r + 44);
      g.stroke();
      g.restore();
      txt(g, "PRIZES", HZ, 588, 20, INK3, { weight: 800, shadow: false, spacing: 2 });
    },
    railInfo(S, p) {
      const b = arr(obj(S.st.housie).buyers).find((x) => String(x.seat) === String(p.seat));
      const won = arr(obj(S.st.housie).prizes).filter((pr) => arr(pr.winners).some((w) => String(w.seat) === String(p.seat)));
      if (won.length) return { text: `WON ${won.map((w) => w.name).join(", ")}`, color: OK };
      if (b) return { text: `${b.n} ${b.n === 1 ? "TICKET" : "TICKETS"}`, color: S.th.accent_hi };
      return { text: "", color: INK3 };
    },
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const h = obj(st.housie);
      const calls = arr(h.calls);
      const last = calls[calls.length - 1];
      const ph = st.phase;
      const playing = ph === "dealing" || ph === "result";
      // the newest number is on the board once the stamp has hit it
      const onBoard = new Set(S.fx.stamped || !playing ? calls : calls.slice(0, -1));
      txt(g, `${onBoard.size} / 90 CALLED`, HB.x + 10 * HB.cw, 128, 26, INK2, { align: "right", font: "mono", weight: 750 });
      for (const n of onBoard) {
        const [x, y] = housieCell(n);
        const isLast = n === last;
        if (isLast) {
          glowFx(g, `hcell|${HB.cw}|${HB.ch}`, x + 4, y + 4, HB.cw - 8, HB.ch - 8, th.accent, 24, (m) => {
            rr(m, x + 4, y + 4, HB.cw - 8, HB.ch - 8, 12);
            m.fillStyle = "#000";
            m.fill();
          });
        }
        rr(g, x + 4, y + 4, HB.cw - 8, HB.ch - 8, 12);
        g.fillStyle = isLast ? th.accent : rgba(housieColor(n), 0.85);
        g.fill();
        txt(g, String(n), x + HB.cw / 2, y + HB.ch / 2 + 12, 34, isLast ? th.ink : "#fff", { align: "center", weight: 900, shadow: false });
      }
      // the right-hand zone under the cage: the call's name, the last few balls — or the buy-in / waiting headline
      const capY = 520;
      if (playing && last != null) {
        if (S.fx.stamped && ph === "dealing") txt(g, HOUSIE_NAMES[last] || `Number ${last}`, HERO.x, HERO.y + HERO.r + 86, 28, th.accent_hi, { align: "center", weight: 750, maxW: 300 });
        // (no countdown ring round the ball: the cage winding up is the cue — and a big ring redrawn with its glow
        // every frame cost a TV stick more than the whole draw)
        const prev = calls.slice(0, -1).slice(-7).reverse();
        if (ph === "dealing") prev.forEach((n, i) => ball(g, HZ + 30 + i * 80, capY + 20, 28, n, housieColor(n)));
        else {
          const ws = winners(S);
          const line = ws.length ? `WINNERS  ${ws.slice(0, 3).map((w) => `${w.name || `P${w.seat}`} ${signed(S, num(w.net))}`).join("  ·  ")}` : "No full house: unclaimed prizes went back to the tickets";
          txt(g, line, HZ, capY + 30, 24, ws.length ? th.accent_hi : INK2, { weight: 800, maxW: 1476 - HZ });
        }
      } else if (ph === "dealing") {
        drawHeadline(S, g, HZ, capY - 42, 1476 - HZ, t, { title: h.first_in != null ? `FIRST CALL IN ${h.first_in}` : "LOOK AT YOUR TICKETS", sub: "The cage turns as each number comes", tone: th.accent }, { size: 44 });
      } else {
        drawHeadline(S, g, HZ, capY - 46, 1476 - HZ, t, headline(S, t, (p) => {
          if (p === "betting") {
            const left = leftTo(S, "ends_at", S.clk.ends, t);
            const span = num(obj(st.rules).buy_seconds, 45);
            return { title: "BUY TICKETS", sub: `${fmt(S, h.price)} a ticket · up to ${num(h.max, 1)} each`, tone: th.accent, ring: left != null ? { frac: left / span, label: Math.ceil(left - 1e-6), color: left < 6 ? BAD : th.accent, left, span, base: th.accent, low: BAD, lowBelow: 6 } : null };
          }
          if (p === "locked") return { title: "TICKETS ARE DEALT", sub: "Check your numbers", tone: th.accent };
          return null;
        }), { size: 44 });
      }
      if (!playing || last == null) {
        // the pot in the cradle's place
        txt(g, "POT", HERO.x, HERO.y - 50, 22, INK3, { align: "center", weight: 800, shadow: false, spacing: 2 });
        txt(g, fmt(S, h.pot), HERO.x, HERO.y + 22, 72, INK1, { align: "center", font: "mono", weight: 800 });
        txt(g, `${num(h.sold)} tickets sold`, HERO.x, HERO.y + 62, 24, INK2, { align: "center", weight: 650 });
      }
      // prizes: a row each — lit while its claim is celebrated, the winners' names once it is won
      const fl = obj(h.flash);
      arr(h.prizes).forEach((pr, i) => {
        const y = 604 + i * 50;
        const won = pr.state === "won" || pr.state === "claimed";
        const hot = S.fx.claimOn && fl.prize === pr.id;
        if (hot) glowBox(g, HZ, y, 1476 - HZ, 44, th.accent, 1, 10);
        rr(g, HZ, y, 1476 - HZ, 44, 10);
        g.fillStyle = hot ? rgba(th.accent, 0.32) : won ? rgba(th.accent, 0.18) : "rgba(0,0,0,.28)";
        g.fill();
        txt(g, pr.name, HZ + 16, y + 31, 24, won ? th.accent_hi : INK1, { weight: 800 });
        txt(g, fmt(S, pr.amount), HZ + 290, y + 31, 24, INK1, { align: "right", font: "mono", weight: 750 });
        const ws = arr(pr.winners);
        if (ws.length) {
          let x = HZ + 312;
          ws.slice(0, 3).forEach((w) => {
            circle(g, x + 10, y + 22, 10);
            g.fillStyle = w.color || seatColor(S, w.seat);
            g.fill();
            txt(g, w.name || `P${w.seat}`, x + 26, y + 30, 20, w.color || INK1, { weight: 750, maxW: 60 });
            x += 92;
          });
        } else txt(g, pr.state === "open" ? "OPEN" : "", 1460, y + 30, 18, INK3, { align: "right", weight: 800 });
      });
      arr(h.bogeys).filter((b) => num(b.age) < 6).slice(-1).forEach((b) => pill(g, `BOGEY! ${b.name} — false ${b.prize} claim`, HB.x + 380, 936, 22, "rgba(255,77,94,.92)", "#fff", { align: "center" }));
    },
  });

  // ================================================================================================ SLOTS
  const SL = { x: 360, y: 60, w: 820, h: 880, cell: 170, rx: 425, ry: 300 };
  function slotSprite(S, ch, px) {
    const m = obj(S.st.machine);
    const key = `${m.theme}|${ch}|${px}|${S.k}`;
    S.fx.sprites = S.fx.sprites || new Map();
    let c = S.fx.sprites.get(key);
    if (c) return c;
    const sp = obj(m.sprites).symbols ? m.sprites : obj(S.fx.lastSprites);
    const rows = arr(obj(sp.symbols)[ch]);
    const pal = arr(sp.palette);
    const n = Math.max(1, rows.length) || 1;
    const side = rows.length ? n * px : 8 * px; // no pixel art: the symbol's letter on a cell of the usual size
    const mm = makeCanvas(side, side, S.k);
    rows.forEach((row, j) => {
      for (let i = 0; i < row.length; i++) {
        const v = row[i];
        if (v === ".") continue;
        const col = pal[parseInt(v, 36)];
        if (!col) continue;
        mm.g.save();
        mm.g.shadowColor = col;
        mm.g.shadowBlur = px * 0.5;
        rr(mm.g, i * px + 1, j * px + 1, px - 2, px - 2, px * 0.28);
        mm.g.fillStyle = col;
        mm.g.fill();
        mm.g.restore();
      }
    });
    if (!rows.length && ch !== "_") txt(mm.g, ch, side / 2, side / 2 + side * 0.18, side * 0.5, "#fff", { align: "center", weight: 900 });
    S.fx.sprites.set(key, mm.c);
    return mm.c;
  }
  const slots = makeScene({
    id: "casino-slots",
    app: "casino_slots",
    init(S) {
      S.fx = { pos: [null, null, null], spinT: null };
    },
    ingest(S, st, t) {
      const p = st.playing;
      const fx = S.fx;
      const sp = obj(obj(st.machine).sprites);
      if (sp.symbols) fx.lastSprites = sp;
      if (!p || p.id !== fx.winId) fx.winAt = null;
      if (p && p.win != null && fx.winAt == null) {
        fx.winAt = t;
        fx.winId = p.id;
      }
    },
    // the three reels: small canvases of their own, repainted only while they turn
    layers(S, root) {
      S.L.reels = [0, 1, 2].map((i) => layer(root, SL.rx + i * 230, SL.ry, 210, 3 * SL.cell, S.k, false));
    },
    layersRedraw(S) {
      S.fx.pos = [null, null, null];
    },
    /** The reels on the panel's clock: reel_pos(stop, n, t, i) with the playing spin's stops from tv.reveal. */
    move(S) {
      const st = S.st;
      const fx = S.fx;
      const strips = arr(obj(st.machine).strips).map(String);
      const p = st.playing;
      const rv = revealOf(S, "slots");
      const live = rv && p && rv.spin === p.id;
      const spinT = live ? (rv.paused ? num(rv.t) : S.T - (num(rv.at) - num(rv.t))) : null;
      fx.spinT = spinT;
      const recent = arr(st.recent);
      const last = !p && recent.length ? arr(recent[0].stops) : null;
      for (let i = 0; i < 3; i++) {
        const strip = strips[i] || "";
        const n = Math.max(1, strip.length);
        let pos = 0;
        if (live) pos = reelPos(num(arr(rv.stops)[i]), n, spinT, i);
        else if (p) pos = arr(p.stops)[i] != null ? p.stops[i] : num(fx.pos[i]);
        else if (last && last[i] != null) pos = last[i];
        const prev = fx.pos[i];
        if (prev != null && Math.abs(pos - prev) < 1e-4 && fx.strip !== undefined) continue;
        const moving = prev != null && Math.abs(pos - prev) > 0.08;
        fx.pos[i] = pos;
        const l = S.L.reels[i];
        const g = l.g;
        g.setTransform(l.k, 0, 0, l.k, 0, 0);
        g.clearRect(0, 0, l.w, l.h);
        const base = Math.floor(pos);
        const frac = pos - base;
        for (let r = -2; r <= 2; r++) {
          const ch = strip[mod(base + r, n)] || "_";
          if (ch === "_") continue;
          const y = (1 + r - frac) * SL.cell + SL.cell / 2;
          const sp = slotSprite(S, ch, 20);
          if (moving) {
            // motion blur: the symbol smeared along the reel (three fading copies), drawn into the reel's own canvas
            const v = clamp(Math.abs(pos - prev) * SL.cell * 0.5, 0, 60);
            for (const [dy, al] of [[-v, 0.18], [-v / 2, 0.3], [v / 2, 0.3]]) {
              g.globalAlpha = al;
              g.drawImage(sp, 105 - 70, y - 70 + dy, 140, 140);
            }
          }
          g.globalAlpha = moving ? 0.7 : 1;
          g.drawImage(sp, 105 - 70, y - 70, 140, 140);
        }
        g.globalAlpha = 1;
        l.show();
      }
      fx.strip = strips.join("|");
    },
    key: (S) => `${S.st.playing ? S.st.playing.id : "-"}|${S.fx.spinT != null && S.fx.spinT > SLOT_STOPS[2]}`,
    slowHz: (S) => (S.fx.spinT != null && S.fx.spinT <= SLOT_STOPS[2] ? 0 : 4),
    bgKey: (S) => String(obj(S.st.machine).theme || ""),
    bg(S, g) {
      const th = S.th;
      const m = obj(S.st.machine);
      rr(g, 18, 18, RAIL_X - 34, SH - 36, 60);
      luxTable(g, th, 760, 480, 1100, 36);
      // the cabinet
      rr(g, SL.x, SL.y, SL.w, SL.h, 48);
      const cg = g.createLinearGradient(SL.x, 0, SL.x + SL.w, 0);
      cg.addColorStop(0, "#1a1a22");
      cg.addColorStop(0.5, "#3a3a46");
      cg.addColorStop(1, "#16161c");
      g.fillStyle = cg;
      g.shadowColor = "rgba(0,0,0,.7)";
      g.shadowBlur = 50;
      g.fill();
      g.shadowBlur = 0;
      g.lineWidth = 6;
      g.strokeStyle = th.accent;
      g.stroke();
      rr(g, SL.x + 40, SL.y + 30, SL.w - 80, 150, 30);
      const mg = g.createLinearGradient(0, SL.y + 30, 0, SL.y + 180);
      mg.addColorStop(0, shade(th.accent, 0.5));
      mg.addColorStop(1, th.accent_deep);
      g.fillStyle = mg;
      g.fill();
      txt(g, String(m.name || "SLOTS").toUpperCase(), SL.x + SL.w / 2, SL.y + 128, 64, th.accent_hi, { align: "center", weight: 900, glow: th.accent });
      rr(g, SL.rx - 20, SL.ry - 20, 3 * 230 + 40 - 40, 3 * SL.cell + 40, 22);
      g.fillStyle = "#08080b";
      g.fill();
      for (let i = 0; i < 3; i++) {
        rr(g, SL.rx + i * 230, SL.ry, 210, 3 * SL.cell, 14);
        const rg = g.createLinearGradient(0, SL.ry, 0, SL.ry + 3 * SL.cell);
        rg.addColorStop(0, "#9a9aa4");
        rg.addColorStop(0.18, "#f4f1ea");
        rg.addColorStop(0.82, "#f4f1ea");
        rg.addColorStop(1, "#9a9aa4");
        g.fillStyle = rg;
        g.fill();
      }
      for (let l = 1; l <= 5; l++) {
        const y = SL.ry + [1.5, 0.5, 2.5, 0.2, 2.8][l - 1] * SL.cell;
        pill(g, String(l), SL.rx - 44, y, 18, rgba(LINE_COLORS[l - 1], 0.9), "#111", { align: "center" });
      }
      // the lever
      rr(g, SL.x + SL.w + 6, 380, 26, 200, 12);
      g.fillStyle = "#2a2a32";
      g.fill();
      // pay table
      txt(g, "PAYS (× BET PER LINE)", 40, 92, 20, INK3, { weight: 800, shadow: false });
      const three = obj(m.three);
      Object.keys(three).forEach((ch, i) => {
        const y = 120 + i * 82;
        for (let k = 0; k < 3; k++) g.drawImage(slotSprite(S, ch, 8), 40 + k * 64, y, 56, 56);
        txt(g, `× ${three[ch]}`, 240, y + 40, 30, INK1, { font: "mono", weight: 800 });
      });
      const gy = 120 + Object.keys(three).length * 82;
      arr(m.groups).forEach((gr, i) => txt(g, `${gr[0]}  × ${gr[2]}`, 40, gy + 20 + i * 34, 24, INK2, { weight: 700 }));
      const lead = obj(m.lead);
      Object.keys(lead).forEach((k, i) => txt(g, `${k} × ${obj(m.names)[m.lead_symbol] || m.lead_symbol}  × ${lead[k]}`, 40, gy + 20 + (arr(m.groups).length + i) * 34, 24, INK2, { weight: 700 }));
      txt(g, `RTP ${(num(m.rtp) * 100).toFixed(2)} % · HIT ${(num(m.hit) * 100).toFixed(0)} %`, 40, 940, 22, th.accent, { weight: 800 });
      txt(g, "UP NEXT", 1220, 92, 20, INK3, { weight: 800, shadow: false });
      txt(g, "RECENT SPINS", 1220, 520, 20, INK3, { weight: 800, shadow: false });
    },
    railInfo(S, p) {
      const st = S.st;
      if (st.playing && String(st.playing.seat) === String(p.seat)) return { text: st.playing.win != null ? (st.playing.win ? `WON ${fmt(S, st.playing.win)}` : "NO WIN") : "SPINNING", color: S.th.accent_hi };
      if (arr(st.queue).some((q) => String(q.seat) === String(p.seat))) return { text: "IN THE QUEUE", color: INK2 };
      const r = arr(st.recent).find((q) => String(q.seat) === String(p.seat));
      if (r && r.win) return { text: `LAST WIN ${fmt(S, r.win)}`, color: OK };
      return { text: "", color: INK3 };
    },
    turnSeat: (S) => (S.st.playing ? S.st.playing.seat : null),
    draw(S, g, t) {
      const st = S.st;
      const th = S.th;
      const fx = S.fx;
      const m = obj(st.machine);
      const strips = arr(m.strips).map(String);
      const p = st.playing;
      const recent = arr(st.recent);
      const spinT = fx.spinT;
      // the glass over the reels (the reels turn in their own layers below)
      for (let i = 0; i < 3; i++) {
        const x = SL.rx + i * 230;
        const shadeG = g.createLinearGradient(0, SL.ry, 0, SL.ry + 3 * SL.cell);
        shadeG.addColorStop(0, "rgba(0,0,0,.45)");
        shadeG.addColorStop(0.2, "rgba(0,0,0,0)");
        shadeG.addColorStop(0.8, "rgba(0,0,0,0)");
        shadeG.addColorStop(1, "rgba(0,0,0,.45)");
        g.fillStyle = shadeG;
        g.fillRect(x, SL.ry, 210, 3 * SL.cell);
      }
      // winning lines
      const winLines = p && p.win != null ? arr(p.wins) : [];
      if (winLines.length && spinT != null && spinT > SLOT_STOPS[2]) {
        winLines.forEach((w, k) => {
          const li = num(w.line, 1) - 1;
          const rows = SLOT_LINES[li] || SLOT_LINES[0];
          const on = Math.floor(t * 2.5) % winLines.length === k || winLines.length === 1;
          g.save();
          g.globalAlpha = on ? 1 : 0.35;
          const path = (m) => {
            m.beginPath();
            rows.forEach((row, i) => {
              const x = SL.rx + i * 230 + 105;
              const y = SL.ry + row * SL.cell + SL.cell / 2;
              if (i) m.lineTo(x, y);
              else m.moveTo(x - 120, y);
            });
            m.lineTo(SL.rx + 2 * 230 + 225, SL.ry + rows[2] * SL.cell + SL.cell / 2);
            m.lineWidth = 8;
          };
          const color = LINE_COLORS[li] || th.accent;
          glowFx(g, `line|${rows.join(",")}`, SL.rx - 19, SL.ry - 4, 2 * 230 + 248, 3 * SL.cell + 8, color, 20, (m) => {
            path(m);
            m.strokeStyle = "#000";
            m.stroke();
          });
          path(g);
          g.strokeStyle = color;
          g.stroke();
          g.restore();
        });
      }
      // the lever knob (pulled at the start of a spin)
      const pull = 0;
      circle(g, SL.x + SL.w + 19, 360 + pull * 220, 30);
      g.fillStyle = "#d0182f";
      g.fill();
      // the credit panel
      rr(g, SL.x + 60, 840, SL.w - 120, 76, 14);
      g.fillStyle = "#050507";
      g.fill();
      if (p) {
        txt(g, p.name || `P${p.seat}`, SL.x + 84, 890, 32, p.color || seatColor(S, p.seat), { weight: 850, maxW: 260 });
        txt(g, `BET ${fmt(S, p.bet)} × ${num(p.lines, 1)} = ${fmt(S, p.stake)}`, SL.x + SL.w / 2 + 10, 890, 26, INK2, { align: "center", font: "mono", weight: 700 });
        if (p.win != null) txt(g, p.win ? `WIN ${fmt(S, p.win)}` : "NO WIN", SL.x + SL.w - 84, 892, 34, p.win ? OK : INK3, { align: "right", font: "mono", weight: 850, glow: p.win ? OK : null });
      } else txt(g, arr(st.queue).length ? "NEXT SPIN COMING UP" : "PULL THE LEVER ON YOUR PHONE", SL.x + SL.w / 2, 890, 30, th.accent, { align: "center", weight: 850, alpha: 0.7 + 0.3 * Math.sin(t * 3) });
      // big win
      if (p && p.win && p.win >= 20 * num(p.stake, 1) && fx.winAt != null) {
        const k = easeOut((t - fx.winAt) / 0.4);
        bulbs(g, SL.x + 10, SL.y + 10, SL.w - 20, SL.h - 20, t, th.accent, 60);
        txt(g, "BIG WIN!", SL.x + SL.w / 2, SL.ry + 1.5 * SL.cell + 30, 120 * k, th.accent_hi, { align: "center", weight: 900, glow: th.accent });
      } else if (p && p.win && fx.winAt != null) bulbs(g, SL.x + 10, SL.y + 10, SL.w - 20, SL.h - 20, t, th.accent, 40);
      // queue and recent
      arr(st.queue).slice(0, 5).forEach((q, i) => {
        const y = 112 + i * 76;
        avatar(S, g, 1250, y + 30, 24, { ...playerOf(S, q.seat), color: q.color });
        txt(g, q.name || `P${q.seat}`, 1286, y + 30, 26, q.color || INK1, { weight: 800, maxW: 170 });
        txt(g, `${fmt(S, q.stake)} stake`, 1286, y + 58, 20, INK3, { weight: 650 });
      });
      if (!arr(st.queue).length) txt(g, "Nobody waiting", 1220, 140, 24, INK3, { weight: 650 });
      recent.slice(0, 5).forEach((q, i) => {
        const y = 540 + i * 76;
        avatar(S, g, 1250, y + 30, 24, { ...playerOf(S, q.seat), color: q.color });
        txt(g, q.name || `P${q.seat}`, 1286, y + 30, 26, q.color || INK1, { weight: 800, maxW: 170 });
        txt(g, q.win ? `won ${fmt(S, q.win)}` : "no win", 1286, y + 58, 20, q.win ? OK : INK3, { weight: 700 });
      });
    },
  });

  // ================================================================================================ menu previews
  // The TV options menu's Dolly and Chips rows (tv.js) show the real thing: the dolly sprites and chip sets drawn
  // here, once per menu, in small canvases sized to their CSS box.
  function sizePreview(canvas, k) {
    const w = canvas.clientWidth || num(Number.parseFloat(canvas.style.width), 0) || 60;
    const h = canvas.clientHeight || num(Number.parseFloat(canvas.style.height), 0) || 60;
    const kk = clamp(num(k, 1), 1, 3);
    canvas.width = Math.max(1, Math.round(w * kk));
    canvas.height = Math.max(1, Math.round(h * kk));
    const g = canvas.getContext("2d");
    g.setTransform(kk, 0, 0, kk, 0, 0);
    g.clearRect(0, 0, w, h);
    return { g, w, h, k: kk };
  }
  /** A dolly of style `id`, standing in the canvas (the menu's Dolly row). */
  function previewDolly(canvas, id, k) {
    const { g, w, h } = sizePreview(canvas, k);
    const s = Math.min(h / (DOLLY_H - 12), w / DOLLY_W);
    g.save();
    g.translate(w / 2 - (DOLLY_W * s) / 2, h - (DOLLY_BASE + 16) * s);
    g.scale(s, s);
    // a little shadow pool under the base
    const sr = g.createRadialGradient(DOLLY_W / 2, DOLLY_BASE + 8, 2, DOLLY_W / 2, DOLLY_BASE + 8, 44);
    sr.addColorStop(0, "rgba(0,0,0,.35)");
    sr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = sr;
    g.beginPath();
    g.ellipse(DOLLY_W / 2, DOLLY_BASE + 8, 44, 10, 0, 0, TAU);
    g.fill();
    dollyBody(g, DOLLY_STYLES[id] ? id : "classic_gold");
    g.restore();
  }
  /** Three chips (25 · 500 · 5K) of chip set `set`, overlapping (the menu's Chips row). */
  function previewChips(canvas, set, k) {
    const { g, w, h } = sizePreview(canvas, k);
    const was = CHIPSET;
    CHIPSET = CHIP_SETS.includes(set) ? set : "clay";
    try {
      const r = Math.min(h * 0.4, w / 5.2);
      const picks = [LADDER[2], LADDER[4], LADDER[7]];
      picks.forEach((c, i) => chip(g, w / 2 + (i - 1) * r * 1.45, h / 2, r, c[2], c[1], { edge: c[3] }));
    } finally {
      CHIPSET = was;
    }
  }

  // ================================================================================================ register
  const SCENES = [roulette, blackjack, baccarat, slots, holdem, teenpatti, andarbahar, bigsix, sevens, housie];
  const API = {
    SCENES, Countdown, PhaseTracker, lockTime, parseCard, baccaratTotal, rouletteCovers, rouletteBoard, rouletteSpotXY,
    rouletteCenter, reelPos, bigRoad, hash01, hexRgb, shade, wrapPi, bjSeatXY, pokerSeatXY, EU_WHEEL, US_WHEEL,
    B6_WHEEL, B6, wheelStep, rouletteBallRel, panelR, b6Phi, b6Flap, B6_SEG, b6Tile, sevensDice, bacDealTimes, abPace, serverClock, sigOf,
    R_CX, R_CY, BX, BY, SEV, LADDER, RACK_MAX, chipRack, rackOf, breakInto, shortChip, chipStyle, pyRound,
    cageTurn, heroPath, HOUSIE_T, HERO, CAGE, housieCell, claimTier, dealAt, dealEnd, dealOrder, showTimes, showFlip, showAnchor, pokerPlate, pokerCardXY, DEAL, SHOW, PK,
    winTier, tickerAt, MOMENT, TIERS, dollyPath, DOLLY_STYLES, DOLLY_REST, DOLLY_AFTER, odoPos, Odo, chipSetOf, CHIP_SETS,
    THEME_CHIP_SET, railSeat, previewDolly, previewChips, ROOMS,
  }; // fmt: skip
  if (TV) {
    TV.casino = API;
    if (typeof TV.registerScene === "function") for (const s of SCENES) TV.registerScene(s);
  }
})();
